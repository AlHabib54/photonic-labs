# -*- coding: utf-8 -*-
"""
تدريب نموذج NeoAMONA Enterprise على بيانات NSL-KDD
مع معالجة تلقائية للأعمدة الفئوية
"""

import numpy as np
import pandas as pd
from sklearn.datasets import fetch_kddcup99
from sklearn.preprocessing import LabelEncoder
from neoamona_core import NeoAMONACore

# 1. تحميل البيانات
print("📥 تحميل بيانات NSL-KDD...")
data = fetch_kddcup99(subset='SA', percent10=True, random_state=42)
X_raw = data.data
y_raw = data.target

# 2. تحويل التصنيفات إلى ثنائي (طبيعي = 0، هجوم = 1)
y = np.array([0 if label == b'normal.' else 1 for label in y_raw])
print(f"📊 التوزيع: طبيعي={np.sum(y==0)}, هجوم={np.sum(y==1)}")

# 3. تحويل X_raw إلى DataFrame بأسماء الأعمدة الصحيحة
column_names = [
    'duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes',
    'land', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins', 'logged_in',
    'num_compromised', 'root_shell', 'su_attempted', 'num_root', 'num_file_creations',
    'num_shells', 'num_access_files', 'num_outbound_cmds', 'is_host_login',
    'is_guest_login', 'count', 'srv_count', 'serror_rate', 'srv_serror_rate',
    'rerror_rate', 'srv_rerror_rate', 'same_srv_rate', 'diff_srv_rate',
    'srv_diff_host_rate', 'dst_host_count', 'dst_host_srv_count',
    'dst_host_same_srv_rate', 'dst_host_diff_srv_rate',
    'dst_host_same_src_port_rate', 'dst_host_srv_diff_host_rate',
    'dst_host_serror_rate', 'dst_host_srv_serror_rate',
    'dst_host_rerror_rate', 'dst_host_srv_rerror_rate'
]

df = pd.DataFrame(X_raw, columns=column_names)

# 4. ترميز الأعمدة الفئوية (protocol_type, service, flag)
categorical_cols = ['protocol_type', 'service', 'flag']
print("🔄 ترميز الأعمدة الفئوية...")
for col in categorical_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    print(f"   - {col}: تم ترميزه إلى {len(le.classes_)} فئة")

# 5. تحويل جميع البيانات إلى أرقام
X = df.values.astype(float)
print(f"✅ البيانات جاهزة: {X.shape[0]} عينة, {X.shape[1]} ميزة")

# 6. تدريب نموذج NeoAMONA
print("\n🧠 بدء تدريب NeoAMONA Core...")
model = NeoAMONACore()
model.fit(X, y)

# 7. حفظ النموذج
model.save("neoamona_core_model.pkl")
print("✅ تم حفظ النموذج في neoamona_core_model.pkl")