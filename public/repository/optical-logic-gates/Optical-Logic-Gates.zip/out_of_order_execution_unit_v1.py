#!/usr/bin/env python3

# ==========================================================
# OUT OF ORDER EXECUTION UNIT V1
# ==========================================================


class OutOfOrderExecutionUnitV1:

    def __init__(self):

        self.queue = []

        self.next_id = 0

        self.issued_count = 0

        self.completed_count = 0

    # ------------------------------------------------------
    # ADD INSTRUCTION
    # ------------------------------------------------------

    def add_instruction(
        self,
        instruction,
        destination,
        sources
    ):

        entry = {

            "id": self.next_id,
            "instruction": instruction,
            "destination": destination,
            "sources": list(sources),
            "ready": False,
            "issued": False,
            "completed": False
        }

        self.queue.append(entry)

        self.next_id += 1

        return entry["id"]

    # ------------------------------------------------------
    # MARK READY
    # ------------------------------------------------------

    def mark_ready(
        self,
        instruction_id
    ):

        for entry in self.queue:

            if entry["id"] == instruction_id:

                entry["ready"] = True

                return True

        return False

    # ------------------------------------------------------
    # ISSUE NEXT READY INSTRUCTION
    # ------------------------------------------------------

    def issue_next(self):

        ready_entries = []

        for entry in self.queue:

            if (
                entry["ready"]
                and not entry["issued"]
                and not entry["completed"]
            ):

                ready_entries.append(entry)

        if not ready_entries:

            return None

        ready_entries.sort(
            key=lambda x: x["id"]
        )

        issued = ready_entries[0]

        issued["issued"] = True

        self.issued_count += 1

        return issued

    # ------------------------------------------------------
    # COMPLETE
    # ------------------------------------------------------

    def complete(
        self,
        instruction_id
    ):

        for entry in self.queue:

            if entry["id"] == instruction_id:

                entry["completed"] = True

                self.completed_count += 1

                return True

        return False

    # ------------------------------------------------------
    # REMOVE COMPLETED
    # ------------------------------------------------------

    def cleanup(self):

        before = len(self.queue)

        self.queue = [

            entry
            for entry in self.queue
            if not entry["completed"]
        ]

        removed = before - len(self.queue)

        return removed

    # ------------------------------------------------------
    # STATUS
    # ------------------------------------------------------

    def status(self):

        queued = len(self.queue)

        issued = 0

        completed = 0

        for entry in self.queue:

            if entry["issued"]:
                issued += 1

            if entry["completed"]:
                completed += 1

        return {

            "queued": queued,
            "issued": issued,
            "completed": completed,
            "total_issued": self.issued_count,
            "total_completed": self.completed_count
        }

    # ------------------------------------------------------
    # HISTORY DUMP
    # ------------------------------------------------------

    def dump(self):

        return list(self.queue)


# ==========================================================
# SELF TEST
# ==========================================================

if __name__ == "__main__":

    print("=" * 60)
    print("OUT OF ORDER EXECUTION UNIT V1")
    print("=" * 60)

    passed = 0
    failed = 0

    ooo = OutOfOrderExecutionUnitV1()

    # ------------------------------------------------------
    # TEST 1
    # ------------------------------------------------------

    add_id = ooo.add_instruction(
        "ADD",
        "R0",
        ["R1", "R2"]
    )

    result = len(ooo.queue) == 1

    print("\nTEST 1 - ADD")
    print("PASS =", result)

    if result:
        passed += 1
    else:
        failed += 1

    # ------------------------------------------------------
    # TEST 2
    # ------------------------------------------------------

    mul_id = ooo.add_instruction(
        "MUL",
        "R3",
        ["R4", "R5"]
    )

    sub_id = ooo.add_instruction(
        "SUB",
        "R6",
        ["R7", "R8"]
    )

    result = len(ooo.queue) == 3

    print("\nTEST 2 - QUEUE")
    print("PASS =", result)

    if result:
        passed += 1
    else:
        failed += 1

    # ------------------------------------------------------
    # TEST 3
    # ------------------------------------------------------

    ooo.mark_ready(sub_id)

    ready = False

    for entry in ooo.queue:

        if entry["id"] == sub_id:

            ready = entry["ready"]

    print("\nTEST 3 - READY")
    print("PASS =", ready)

    if ready:
        passed += 1
    else:
        failed += 1

    # ------------------------------------------------------
    # TEST 4
    # ------------------------------------------------------

    issued = ooo.issue_next()

    result = (
        issued is not None
        and issued["instruction"] == "SUB"
    )

    print("\nTEST 4 - ISSUE")
    print(
        "ISSUED =",
        issued["instruction"]
        if issued
        else None
    )
    print("PASS =", result)

    if result:
        passed += 1
    else:
        failed += 1

    # ------------------------------------------------------
    # TEST 5
    # ------------------------------------------------------

    ooo.complete(sub_id)

    removed = ooo.cleanup()

    result = removed == 1

    print("\nTEST 5 - COMPLETE")
    print("PASS =", result)

    if result:
        passed += 1
    else:
        failed += 1

    # ------------------------------------------------------
    # REPORT
    # ------------------------------------------------------

    print("\n" + "=" * 60)
    print("OUT OF ORDER EXECUTION UNIT V1 REPORT")
    print("=" * 60)

    print("PASSED =", passed)
    print("FAILED =", failed)
    print("TOTAL TESTS =", passed + failed)

    if failed == 0:

        print("FINAL STATUS = VERIFIED")

    else:

        print("FINAL STATUS = FAILED")
