# -*- coding: utf-8 -*-
"""
NeoAMONA Enterprise Server - Commercial Edition v3.0
مع واجهة حديثة ونظام تحذير/ترقية
"""

import pickle
import numpy as np
import pandas as pd
import json
import time
import uuid
from fastapi import FastAPI, UploadFile, File, HTTPException, Header, Form
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from collections import Counter
import uvicorn
import os
import warnings
warnings.filterwarnings('ignore')

from neoamona_core import NeoAMONACore

# ============================================================
# 1. نظام الاشتراكات
# ============================================================

TIER_LIMITS = {
    "free": {
        "name": "Freemium",
        "max_rows_per_upload": 1000,
        "daily_api_requests": 10,
        "allow_threshold_tuning": False,
        "allow_download_report": False,
        "price": "$0 / month",
        "color": "free"
    },
    "basic": {
        "name": "Basic",
        "max_rows_per_upload": 10000,
        "daily_api_requests": 100,
        "allow_threshold_tuning": False,
        "allow_download_report": True,
        "price": "$299 / month",
        "color": "basic"
    },
    "pro": {
        "name": "Professional",
        "max_rows_per_upload": 100000,
        "daily_api_requests": 1000,
        "allow_threshold_tuning": True,
        "allow_download_report": True,
        "price": "$999 / month",
        "color": "pro"
    },
    "enterprise": {
        "name": "Enterprise",
        "max_rows_per_upload": float('inf'),
        "daily_api_requests": float('inf'),
        "allow_threshold_tuning": True,
        "allow_download_report": True,
        "price": "Contact Sales",
        "color": "enterprise"
    }
}

# قاعدة بيانات المفاتيح التجريبية
MOCK_API_KEYS = {
    "free_key_123": {"tier": "free", "expires": None},
    "basic_key_456": {"tier": "basic", "expires": None},
    "pro_key_789": {"tier": "pro", "expires": None},
    "enterprise_key_000": {"tier": "enterprise", "expires": None}
}

request_counter = {tier: 0 for tier in TIER_LIMITS.keys()}

# ============================================================
# 2. تهيئة الخادم
# ============================================================

app = FastAPI(
    title="NeoAMONA Enterprise API",
    description="AI-Powered Cybersecurity Detection Platform",
    version="4.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================
# 3. تحميل النموذج
# ============================================================

MODEL_PATH = "models/neoamona_core_model.pkl"
model: NeoAMONACore = None

@app.on_event("startup")
async def load_model():
    global model
    try:
        # تأكد من وجود المجلد
        os.makedirs("models", exist_ok=True)
        if not os.path.exists(MODEL_PATH):
            print(f"⚠️  Model not found at {MODEL_PATH}. Please train it first.")
            return
        model = NeoAMONACore.load(MODEL_PATH)
        print(f"✅ Model loaded: {MODEL_PATH}")
        print(f"   - Active nodes: {model.active_nodes}")
        print(f"   - Threshold: {model.best_threshold:.3f}")
    except Exception as e:
        print(f"❌ Error loading model: {e}")

# ============================================================
# 4. دوال المساعدة
# ============================================================

def validate_tier(api_key: str) -> str:
    if api_key not in MOCK_API_KEYS:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return MOCK_API_KEYS[api_key]["tier"]

def get_limits(tier: str) -> dict:
    return TIER_LIMITS[tier]

def check_limits(tier: str, requested_rows: int = 0):
    limits = get_limits(tier)
    
    if request_counter[tier] >= limits["daily_api_requests"]:
        raise HTTPException(
            status_code=429,
            detail=f"Daily request limit exceeded ({limits['daily_api_requests']}) for tier {tier}"
        )
    
    if requested_rows > limits["max_rows_per_upload"]:
        raise HTTPException(
            status_code=403,
            detail=f"Row limit exceeded. Your tier allows {limits['max_rows_per_upload']} rows, but {requested_rows} were uploaded."
        )
    
    request_counter[tier] += 1
    return True

def clean_and_prepare_data(df: pd.DataFrame, target_column: str = None):
    try:
        y = None
        if target_column and target_column in df.columns:
            y_raw = df[target_column].values
            if len(np.unique(y_raw)) == 2:
                y = np.array([0 if str(v).strip().upper() == 'BENIGN' or v == 0 else 1 for v in y_raw])
            else:
                most_common = Counter(y_raw).most_common(1)[0][0]
                y = np.array([0 if v == most_common else 1 for v in y_raw])
            X_raw = df.drop(columns=[target_column]).values
        else:
            X_raw = df.values

        X_cleaned = []
        for i in range(X_raw.shape[1]):
            col = X_raw[:, i]
            col_numeric = pd.to_numeric(col, errors='coerce')
            mean_val = np.nanmean(col_numeric)
            if np.isnan(mean_val):
                mean_val = 0.0
            col_filled = np.where(np.isnan(col_numeric), mean_val, col_numeric)
            X_cleaned.append(col_filled.astype(float))
        
        X_final = np.column_stack(X_cleaned)
        X_final = np.nan_to_num(X_final, nan=0.0, posinf=1e6, neginf=-1e6)
        return X_final, y
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Data cleaning error: {str(e)}")

# ============================================================
# 5. نقاط النهاية (Endpoints)
# ============================================================

@app.get("/", response_class=HTMLResponse)
async def root():
    """الصفحة الرئيسية"""
    with open("frontend/index.html", "r", encoding="utf-8") as f:
        return f.read()

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard():
    """لوحة التحكم"""
    with open("frontend/dashboard.html", "r", encoding="utf-8") as f:
        return f.read()

@app.get("/health")
async def health():
    return {"status": "healthy", "model_loaded": model is not None}

@app.get("/api/pricing")
async def pricing():
    return {"tiers": TIER_LIMITS}

@app.post("/api/subscribe")
async def subscribe(plan: str = Form(...), payment_token: str = Form(...)):
    if plan not in TIER_LIMITS:
        raise HTTPException(status_code=400, detail="Invalid plan")
    
    if not payment_token.startswith("demo_"):
        raise HTTPException(status_code=402, detail="Payment failed. Use 'demo_payment' for testing.")
    
    new_key = f"{plan}_key_{uuid.uuid4().hex[:8]}"
    MOCK_API_KEYS[new_key] = {"tier": plan, "expires": None}
    
    return {
        "status": "success",
        "message": f"Upgraded to {TIER_LIMITS[plan]['name']}",
        "api_key": new_key,
        "tier": plan,
        "limits": TIER_LIMITS[plan]
    }

@app.post("/api/predict")
async def predict(
    features: List[float],
    threshold: Optional[float] = None,
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    tier = validate_tier(x_api_key)
    limits = get_limits(tier)
    check_limits(tier)
    
    if threshold is not None and not limits["allow_threshold_tuning"]:
        raise HTTPException(
            status_code=403,
            detail=f"Threshold tuning not allowed for tier {tier}"
        )
    
    if threshold is None:
        threshold = model.best_threshold
    
    features_np = np.array(features).reshape(1, -1)
    proba = model.predict_proba(features_np)[0]
    pred = int(proba >= threshold)
    
    return {
        "prediction": "Attack" if pred == 1 else "Normal",
        "probability": float(proba),
        "threshold_used": float(threshold),
        "tier": tier,
        "remaining_requests": int(limits["daily_api_requests"] - request_counter[tier])
    }

@app.post("/api/upload")
async def upload_file(
    file: UploadFile = File(...),
    target_column: Optional[str] = None,
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    tier = validate_tier(x_api_key)
    limits = get_limits(tier)
    
    contents = await file.read()
    df = pd.read_csv(io.BytesIO(contents))
    if df.empty:
        raise HTTPException(status_code=400, detail="File is empty")
    
    check_limits(tier, requested_rows=df.shape[0])
    
    X, y_true = clean_and_prepare_data(df, target_column)
    proba = model.predict_proba(X)
    y_pred = (proba >= model.best_threshold).astype(int)
    
    attacks = int(np.sum(y_pred))
    normal_count = len(y_pred) - attacks
    
    confusion = None
    if y_true is not None:
        from sklearn.metrics import confusion_matrix
        cm = confusion_matrix(y_true, y_pred)
        confusion = {
            "true_negatives": int(cm[0, 0]),
            "false_positives": int(cm[0, 1]),
            "false_negatives": int(cm[1, 0]),
            "true_positives": int(cm[1, 1])
        }
    
    summary = {
        "total": X.shape[0],
        "features_count": X.shape[1],
        "attacks_detected": attacks,
        "normal_count": normal_count,
        "attack_ratio": f"{attacks / X.shape[0] * 100:.2f}%"
    }
    if confusion:
        summary["confusion_matrix"] = confusion
    
    download_url = None
    if limits["allow_download_report"]:
        results_df = df.copy()
        results_df['prediction'] = ['Attack' if p == 1 else 'Normal' for p in y_pred]
        results_df['probability'] = proba
        output_path = f"predictions_{int(time.time())}.csv"
        results_df.to_csv(output_path, index=False)
        download_url = f"/download/{output_path}"
    
    return {
        "status": "success",
        "tier": tier,
        "total_rows": X.shape[0],
        "attacks_detected": attacks,
        "normal_count": normal_count,
        "prediction_summary": summary,
        "remaining_requests": int(limits["daily_api_requests"] - request_counter[tier]),
        "download_url": download_url
    }

@app.get("/download/{filename}")
async def download_file(filename: str, x_api_key: str = Header(...)):
    tier = validate_tier(x_api_key)
    limits = get_limits(tier)
    if not limits["allow_download_report"]:
        raise HTTPException(status_code=403, detail="Download not allowed for your tier")
    return FileResponse(filename, media_type="text/csv", filename=filename)

# ============================================================
# 6. تشغيل الخادم
# ============================================================

if __name__ == "__main__":
    print("="*70)
    print("🚀 NeoAMONA Enterprise Server - Commercial Edition v3.0")
    print("="*70)
    print("📌 Available Tiers:")
    for tier, info in TIER_LIMITS.items():
        print(f"   - {tier.upper()}: {info['name']} - {info['price']}")
    print("="*70)
    uvicorn.run(
        "neoamona_server:app",
        host="0.0.0.0",
        port=8080,
        reload=False
    )