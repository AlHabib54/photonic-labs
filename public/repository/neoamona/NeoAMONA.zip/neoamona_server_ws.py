# -*- coding: utf-8 -*-
"""
NeoAMONA Enterprise Server v5.2 - مع دعم WebSocket للبث المباشر
"""

import pickle
import numpy as np
import pandas as pd
import io
import os
import time
import logging
import json
import asyncio
from typing import List, Optional, Set
from fastapi import FastAPI, UploadFile, File, HTTPException, Header, Form, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from sklearn.preprocessing import LabelEncoder
import uvicorn
import warnings
warnings.filterwarnings('ignore')

from neoamona_core import NeoAMONACore

# ============================================================
# 1. إعداد التسجيل
# ============================================================
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("NeoAMONA")

# ============================================================
# 2. نظام الاشتراكات
# ============================================================
TIER_LIMITS = {
    "free": {"max_rows": 1000, "name": "Freemium"},
    "pro": {"max_rows": 100000, "name": "Professional"},
    "enterprise": {"max_rows": float('inf'), "name": "Enterprise"}
}
MOCK_API_KEYS = {
    "free_key_123": "free",
    "pro_key_789": "pro",
    "enterprise_key_000": "enterprise"
}

app = FastAPI(title="NeoAMONA Enterprise")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ============================================================
# 3. إدارة اتصالات WebSocket
# ============================================================
class ConnectionManager:
    def __init__(self):
        self.active_connections: Set[WebSocket] = set()

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.add(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.discard(websocket)

    async def broadcast(self, message: dict):
        """بث الرسالة لجميع العملاء المتصلين"""
        if not self.active_connections:
            return
        disconnected = set()
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except:
                disconnected.add(connection)
        for conn in disconnected:
            self.disconnect(conn)

manager = ConnectionManager()

# ============================================================
# 4. تحميل النموذج
# ============================================================
MODEL_PATH = "models/neoamona_core_model.pkl"
model = None

@app.on_event("startup")
async def load_model():
    global model
    if os.path.exists(MODEL_PATH):
        try:
            model = NeoAMONACore.load(MODEL_PATH)
            logger.info(f"✅ Model loaded from {MODEL_PATH}")
        except Exception as e:
            logger.error(f"❌ Failed to load model: {e}")

# ============================================================
# 5. دوال معالجة البيانات (مبسطة)
# ============================================================
def validate_key(api_key: str) -> str:
    if api_key not in MOCK_API_KEYS:
        raise HTTPException(401, detail="Invalid API key")
    return MOCK_API_KEYS[api_key]

def adapt_to_41_features(X):
    if X.ndim == 1:
        X = X.reshape(1, -1)
    target = 41
    current = X.shape[1]
    if current < target:
        return np.pad(X, ((0,0), (0, target-current)), 'constant')
    elif current > target:
        return X[:, :target]
    return X

def clean_data_smart(df, target_col=None):
    if target_col and target_col in df.columns:
        y_raw = df[target_col].values
        y = np.array([0 if str(v).strip().upper() in ['BENIGN','NORMAL','0'] else 1 for v in y_raw])
        X_raw = df.drop(columns=[target_col])
    else:
        X_raw = df.copy()
        y = None
    X_clean = []
    for col in X_raw.columns:
        col_numeric = pd.to_numeric(X_raw[col], errors='coerce')
        mean_val = np.nanmean(col_numeric)
        if np.isnan(mean_val):
            mean_val = 0.0
        col_filled = np.nan_to_num(col_numeric, nan=mean_val)
        col_filled = np.clip(col_filled, -1e6, 1e6)
        X_clean.append(col_filled.astype(float))
    X_final = np.column_stack(X_clean)
    X_final = adapt_to_41_features(X_final)
    X_final = np.nan_to_num(X_final, nan=0.0)
    return X_final, y

# ============================================================
# 6. WebSocket Endpoint (للبث المباشر)
# ============================================================
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            # استقبال الرسائل من عميل البث (neoamona_streaming_ws.py)
            data = await websocket.receive_json()
            # إعادة بث الرسالة لجميع العملاء المتصلين (مثل واجهة الويب)
            await manager.broadcast(data)
            logger.info(f"📡 Broadcast: {data.get('label', 'N/A')} - {data.get('flow', '')}")
    except WebSocketDisconnect:
        manager.disconnect(websocket)
        logger.info("🔌 WebSocket disconnected")

# ============================================================
# 7. نقاط النهاية HTTP (ملخص)
# ============================================================
@app.get("/", response_class=HTMLResponse)
async def root():
    return HTML_PAGE  # نفس HTML السابق مع إضافة WebSocket

@app.post("/api/upload")
async def upload_file(file: UploadFile, target_column: Optional[str] = None, mode: str = Form('normal'), x_api_key: str = Header(...)):
    # ... (نفس الكود السابق)
    return {"status": "ok", "mode": mode}

@app.post("/api/predict")
async def predict(features: List[float], x_api_key: str = Header(...)):
    # ... (نفس الكود السابق)
    return {"prediction": "Normal" if pred == 0 else "Attack", "probability": float(proba)}

# ============================================================
# 8. HTML مع WebSocket (جزء من dashboard)
# ============================================================
HTML_PAGE = """<!DOCTYPE html>
<html>
<head><title>NeoAMONA Live</title>
<style> body { font-family: Arial; background: #0f172a; color: #e2e8f0; padding: 20px; }
.card { background: #1e293b; padding: 20px; border-radius: 12px; margin: 10px 0; }
.log { background: #0f172a; padding: 10px; border-radius: 8px; max-height: 400px; overflow-y: auto; }
.alert { padding: 8px 12px; border-radius: 6px; margin: 4px 0; border-left: 4px solid #22c55e; }
.alert.attack { border-left-color: #ef4444; background: rgba(239,68,68,0.1); }
.alert.normal { border-left-color: #22c55e; background: rgba(34,197,94,0.1); }
</style></head>
<body>
<div class="card">
    <h2>📡 Live Stream Alerts</h2>
    <div id="logContainer" class="log"><div class="text-muted">Waiting for connection...</div></div>
</div>
<script>
let ws;
function connectWebSocket() {
    ws = new WebSocket("ws://localhost:8080/ws");
    ws.onopen = () => {
        document.getElementById('logContainer').innerHTML = '<div class="text-muted">✅ Connected to server</div>';
    };
    ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        const container = document.getElementById('logContainer');
        const entry = document.createElement('div');
        const time = new Date().toLocaleTimeString();
        const cls = data.prediction === 'Attack' ? 'attack' : 'normal';
        entry.className = 'alert ' + cls;
        entry.innerHTML = `<span style="color:#94a3b8;">[${time}]</span> <strong>${data.flow || 'N/A'}</strong> → ${data.prediction} (prob=${data.probability?.toFixed(3) || '?'})`;
        container.prepend(entry);
        if (container.children.length > 100) container.removeChild(container.lastChild);
    };
    ws.onclose = () => {
        document.getElementById('logContainer').innerHTML = '<div class="text-muted">❌ Disconnected. Reconnecting...</div>';
        setTimeout(connectWebSocket, 3000);
    };
}
connectWebSocket();
</script>
</body>
</html>"""

# ============================================================
# 9. تشغيل الخادم
# ============================================================
if __name__ == "__main__":
    print("="*60)
    print("🚀 NeoAMONA Enterprise Server v5.2 (with WebSocket)")
    print("="*60)
    uvicorn.run("neoamona_server_ws:app", host="0.0.0.0", port=8080, reload=False)