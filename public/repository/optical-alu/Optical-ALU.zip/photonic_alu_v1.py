# ==========================================================
# photonic_alu_v1.py
# وحدة الحساب الضوئي — تستقبل نبضتين وتُعيد نبضة نتيجة
# ==========================================================

from copy import deepcopy
from photonic_pulse_v1  import PhotonicPulseV1
from photonic_channel_v1 import DATA_MAX


# ==========================================================
# OPCODES الضوئية
# ==========================================================

PHOTON_OPCODES = {
    "10000001": "PHOTON_ADD",
    "10000010": "PHOTON_SUB",
    "10000011": "PHOTON_MUL",
    "10000100": "PHOTON_DIV",
    "10000101": "PHOTON_AND",
    "10000110": "PHOTON_OR",
    "10000111": "PHOTON_XOR",
    "10001000": "PHOTON_MAX",
    "10001001": "PHOTON_MIN",
    "10001010": "PHOTON_SUM",
    "10001011": "PHOTON_DOT",
}


# ==========================================================
# PHOTONIC ALU V1
# ==========================================================

class PhotonicALUV1:

    """
    وحدة الحساب الضوئي.

    تستقبل نبضتين A و B ← تُطبّق عملية على جميع قنواتهما
    في آنٍ واحد ← تُعيد نبضة نتيجة C.

    الفرق عن ALU التقليدي:
      ALU تقليدي  : عملية واحدة في كل دورة
      PhotonicALU : N عملية في كل دورة (N = عدد القنوات)
    """

    def __init__(self):

        # إحصاءات التنفيذ
        self.total_cycles       = 0
        self.total_ops          = 0
        self.total_overflows    = 0
        self.op_counts          = {op: 0 for op in PHOTON_OPCODES.values()}

        # الفلاغز
        self.flags = {
            "Z": 0,   # جميع النتائج = 0
            "C": 0,   # وجود carry في أي قناة
            "O": 0,   # overflow
            "N": 0,   # نتيجة سالبة (SUB)
        }

        # سجل العمليات
        self.history = []

    # ======================================================
    # EXECUTE — تنفيذ عملية
    # ======================================================

    def execute(self, pulse_a, pulse_b, operation):

        """
        تنفيذ عملية ضوئية على نبضتين.
        يُعيد نبضة النتيجة + ملخص كامل.
        """

        if operation not in PHOTON_OPCODES.values():
            raise ValueError(f"عملية ضوئية غير معروفة: {operation}")

        if pulse_a.n_channels != pulse_b.n_channels:
            raise ValueError(
                f"عدد القنوات غير متطابق: "
                f"{pulse_a.n_channels} vs {pulse_b.n_channels}"
            )

        n = pulse_a.n_channels

        # --------------------------------------------------
        # العمليات المباشرة (نبضة → نبضة)
        # --------------------------------------------------

        if operation in [
            "PHOTON_ADD", "PHOTON_SUB",
            "PHOTON_MUL", "PHOTON_DIV"
        ]:
            result_pulse, summary = pulse_a.result_pulse(
                pulse_b, operation
            )
            results = result_pulse.read_all()
            raws    = summary["raws"]
            carries = summary["carries"]

        # --------------------------------------------------
        # PHOTON_AND / OR / XOR — عمليات بتية
        # --------------------------------------------------

        elif operation in ["PHOTON_AND", "PHOTON_OR", "PHOTON_XOR"]:

            a_data = pulse_a.read_all()
            b_data = pulse_b.read_all()
            results = []
            raws    = []
            carries = [0] * n

            for a_val, b_val in zip(a_data, b_data):
                if   operation == "PHOTON_AND":
                    r = a_val & b_val
                elif operation == "PHOTON_OR":
                    r = a_val | b_val
                elif operation == "PHOTON_XOR":
                    r = a_val ^ b_val
                results.append(r & 0xFFFF)
                raws.append(r)

            result_pulse = PhotonicPulseV1(n, data=results)
            summary = {
                "operation":     operation,
                "n_channels":    n,
                "results_16":    results,
                "raws":          raws,
                "carries":       carries,
                "overflow_count": 0
            }

        # --------------------------------------------------
        # PHOTON_MAX — أعلى قيمة لكل قناة
        # --------------------------------------------------

        elif operation == "PHOTON_MAX":

            a_data = pulse_a.read_all()
            b_data = pulse_b.read_all()
            results = [max(a, b) for a, b in zip(a_data, b_data)]
            raws    = results[:]
            carries = [0] * n
            result_pulse = PhotonicPulseV1(n, data=results)
            summary = {
                "operation":     "PHOTON_MAX",
                "n_channels":    n,
                "results_16":    results,
                "raws":          raws,
                "carries":       carries,
                "overflow_count": 0
            }

        # --------------------------------------------------
        # PHOTON_MIN — أدنى قيمة لكل قناة
        # --------------------------------------------------

        elif operation == "PHOTON_MIN":

            a_data = pulse_a.read_all()
            b_data = pulse_b.read_all()
            results = [min(a, b) for a, b in zip(a_data, b_data)]
            raws    = results[:]
            carries = [0] * n
            result_pulse = PhotonicPulseV1(n, data=results)
            summary = {
                "operation":     "PHOTON_MIN",
                "n_channels":    n,
                "results_16":    results,
                "raws":          raws,
                "carries":       carries,
                "overflow_count": 0
            }

        # --------------------------------------------------
        # PHOTON_SUM — مجموع كل القنوات → قناة واحدة
        # --------------------------------------------------

        elif operation == "PHOTON_SUM":

            total   = sum(pulse_a.read_all())
            results = [total & 0xFFFF]
            raws    = [total]
            carries = [1 if total > 0xFFFF else 0]
            result_pulse = PhotonicPulseV1(1, data=results)
            summary = {
                "operation":     "PHOTON_SUM",
                "n_channels":    n,
                "results_16":    results,
                "raws":          raws,
                "carries":       carries,
                "overflow_count": carries[0],
                "total_raw":     total
            }

        # --------------------------------------------------
        # PHOTON_DOT — حاصل الضرب النقطي
        # --------------------------------------------------

        elif operation == "PHOTON_DOT":

            a_data = pulse_a.read_all()
            b_data = pulse_b.read_all()
            dot    = sum(a * b for a, b in zip(a_data, b_data))
            results = [dot & 0xFFFF]
            raws    = [dot]
            carries = [1 if dot > 0xFFFF else 0]
            result_pulse = PhotonicPulseV1(1, data=results)
            summary = {
                "operation":     "PHOTON_DOT",
                "n_channels":    n,
                "results_16":    results,
                "raws":          raws,
                "carries":       carries,
                "overflow_count": carries[0],
                "dot_raw":       dot
            }

        # --------------------------------------------------
        # تحديث الإحصاءات والفلاغز
        # --------------------------------------------------

        self.total_cycles    += 1
        self.total_ops       += n
        self.total_overflows += summary.get("overflow_count", 0)
        self.op_counts[operation] = self.op_counts.get(operation, 0) + 1

        self._update_flags(results, carries, operation)

        record = {
            "cycle":     self.total_cycles,
            "operation": operation,
            "n_ops":     n,
            "overflow":  summary.get("overflow_count", 0),
            "flags":     deepcopy(self.flags)
        }
        self.history.append(record)

        print(f"\nPHOTON EXECUTE = {operation}")
        print(f"  قنوات   : {n}")
        print(f"  عمليات  : {n} في دورة واحدة")
        print(f"  overflow: {summary.get('overflow_count', 0)}")
        print(f"  flags   : {self.flags}")

        return result_pulse, summary

    # ======================================================
    # FLAGS
    # ======================================================

    def _update_flags(self, results, carries, operation):

        self.flags["Z"] = 1 if all(r == 0 for r in results) else 0
        self.flags["C"] = 1 if any(c != 0 for c in carries) else 0
        self.flags["O"] = 1 if any(c != 0 for c in carries) else 0
        self.flags["N"] = 1 if operation == "PHOTON_SUB" and any(
            r > 0x7FFF for r in results
        ) else 0

    def read_flag(self, name):

        return self.flags.get(name, 0)

    # ======================================================
    # REPORT
    # ======================================================

    def report(self):

        print("\n" + "=" * 50)
        print("PHOTONIC ALU V1 — REPORT")
        print("=" * 50)
        print(f"دورات الحساب الضوئي : {self.total_cycles}")
        print(f"إجمالي العمليات     : {self.total_ops}")
        print(f"إجمالي الـ overflow  : {self.total_overflows}")
        print(f"الفلاغز الحالية     : {self.flags}")
        print("\nإحصاء العمليات:")
        for op, count in self.op_counts.items():
            if count > 0:
                print(f"  {op:20} = {count}")
        print("=" * 50)

    def get_history(self):

        return deepcopy(self.history)


# ==========================================================
# SELF-TEST
# ==========================================================

if __name__ == "__main__":

    print("=" * 60)
    print("PHOTONIC ALU V1 — SELF TEST")
    print("=" * 60)

    alu = PhotonicALUV1()

    # --------------------------------------------------
    # TEST 1: PHOTON_ADD
    # --------------------------------------------------

    print("\n[ TEST 1 ] PHOTON_ADD — 4 قنوات")

    a = PhotonicPulseV1(4, data=[100, 200, 300, 400])
    b = PhotonicPulseV1(4, data=[ 10,  20,  30,  40])

    out, summary = alu.execute(a, b, "PHOTON_ADD")

    assert out.read_all() == [110, 220, 330, 440]
    assert alu.flags["Z"] == 0
    assert alu.flags["C"] == 0
    print("✓ PASS")

    # --------------------------------------------------
    # TEST 2: PHOTON_SUB
    # --------------------------------------------------

    print("\n[ TEST 2 ] PHOTON_SUB")

    a2 = PhotonicPulseV1(4, data=[500, 600, 700, 800])
    b2 = PhotonicPulseV1(4, data=[100, 100, 100, 100])

    out2, _ = alu.execute(a2, b2, "PHOTON_SUB")

    assert out2.read_all() == [400, 500, 600, 700]
    print("✓ PASS")

    # --------------------------------------------------
    # TEST 3: PHOTON_MUL مع overflow
    # --------------------------------------------------

    print("\n[ TEST 3 ] PHOTON_MUL مع overflow")

    a3 = PhotonicPulseV1(4, data=[1000, 2000,  100,  200])
    b3 = PhotonicPulseV1(4, data=[  50,  100, 1000, 1000])

    out3, sum3 = alu.execute(a3, b3, "PHOTON_MUL")

    assert sum3["raws"][0] == 50000
    assert sum3["raws"][1] == 200000
    assert alu.flags["C"]  == 1
    print(f"  raws   = {sum3['raws']}")
    print(f"  16bit  = {out3.read_all()}")
    print(f"  C flag = {alu.flags['C']}")
    print("✓ PASS")

    # --------------------------------------------------
    # TEST 4: PHOTON_MAX / PHOTON_MIN
    # --------------------------------------------------

    print("\n[ TEST 4 ] PHOTON_MAX و PHOTON_MIN")

    a4 = PhotonicPulseV1(4, data=[100, 500,  30, 800])
    b4 = PhotonicPulseV1(4, data=[200, 300, 400, 100])

    out_max, _ = alu.execute(a4, b4, "PHOTON_MAX")
    out_min, _ = alu.execute(a4, b4, "PHOTON_MIN")

    assert out_max.read_all() == [200, 500, 400, 800]
    assert out_min.read_all() == [100, 300,  30, 100]
    print(f"  MAX = {out_max.read_all()}")
    print(f"  MIN = {out_min.read_all()}")
    print("✓ PASS")

    # --------------------------------------------------
    # TEST 5: PHOTON_SUM — تكثيف القنوات
    # --------------------------------------------------

    print("\n[ TEST 5 ] PHOTON_SUM — مجموع الطيف كله")

    a5 = PhotonicPulseV1(4, data=[1000, 2000, 3000, 4000])
    b5 = PhotonicPulseV1(4, data=[0, 0, 0, 0])

    out5, sum5 = alu.execute(a5, b5, "PHOTON_SUM")

    assert sum5["total_raw"] == 10000
    assert out5.read_all()   == [10000]
    print(f"  SUM([1000,2000,3000,4000]) = {sum5['total_raw']}")
    print("✓ PASS")

    # --------------------------------------------------
    # TEST 6: PHOTON_DOT — الضرب النقطي
    # --------------------------------------------------

    print("\n[ TEST 6 ] PHOTON_DOT — حاصل الضرب النقطي")

    a6 = PhotonicPulseV1(4, data=[1, 2, 3, 4])
    b6 = PhotonicPulseV1(4, data=[1, 2, 3, 4])

    out6, sum6 = alu.execute(a6, b6, "PHOTON_DOT")

    # 1×1 + 2×2 + 3×3 + 4×4 = 1+4+9+16 = 30
    assert sum6["dot_raw"] == 30
    print(f"  DOT([1,2,3,4], [1,2,3,4]) = {sum6['dot_raw']}")
    print("✓ PASS")

    # --------------------------------------------------
    # TEST 7: نبضة كبيرة — 16 قناة
    # --------------------------------------------------

    print("\n[ TEST 7 ] نبضة 16 قناة — ذروة التوازي")

    data_a = list(range(100, 1700, 100))  # 100,200,...,1600
    data_b = list(range(  1,   17,   1))  # 1,2,...,16

    p16_a = PhotonicPulseV1(16, data=data_a)
    p16_b = PhotonicPulseV1(16, data=data_b)

    out16, s16 = alu.execute(p16_a, p16_b, "PHOTON_ADD")

    expected = [a + b for a, b in zip(data_a, data_b)]
    assert s16["raws"] == expected
    print(f"  16 ADD في دورة واحدة: أول 4 نتائج = {s16['raws'][:4]}")
    print(f"  إجمالي العمليات = {alu.total_ops}")
    print("✓ PASS")

    # --------------------------------------------------
    # TEST 8: Z-flag — جميع النتائج صفر
    # --------------------------------------------------

    print("\n[ TEST 8 ] Z-flag — جميع النتائج صفر")

    az = PhotonicPulseV1(4, data=[100, 200, 300, 400])
    bz = PhotonicPulseV1(4, data=[100, 200, 300, 400])

    outz, _ = alu.execute(az, bz, "PHOTON_SUB")

    assert alu.flags["Z"] == 1
    print(f"  SUB(A, A) = {outz.read_all()} → Z={alu.flags['Z']}")
    print("✓ PASS")

    # --------------------------------------------------
    # REPORT
    # --------------------------------------------------

    alu.report()

    print("\n" + "=" * 60)
    print("PHOTONIC ALU V1 — ALL TESTS PASSED ✓")
    print("=" * 60)
