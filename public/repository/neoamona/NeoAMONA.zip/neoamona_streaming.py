#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NeoAMONA Streaming - نظام كشف التسلل في الوقت الفعلي
"""
import time
import pickle
import threading
import numpy as np
import pandas as pd
from collections import defaultdict
from scapy.all import sniff, IP, TCP, UDP, ICMP, Raw
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

# استيراد NeoAMONA
from neoamona_core import NeoAMONACore

# ============================================================
# 1. تحميل النموذج المدرب
# ============================================================
MODEL_PATH = "models/neoamona_core_model.pkl"

def load_model():
    try:
        model = NeoAMONACore.load(MODEL_PATH)
        print(f"✅ نموذج NeoAMONA محمّل بنجاح من {MODEL_PATH}")
        print(f"   - العقد النشطة: {model.active_nodes}")
        print(f"   - العتبة: {model.best_threshold:.3f}")
        return model
    except Exception as e:
        print(f"❌ فشل تحميل النموذج: {e}")
        return None

model = load_model()
if model is None:
    print("⚠️  لا يمكن بدء البث المباشر بدون نموذج مدرب.")
    exit(1)

# ============================================================
# 2. تخزين التدفقات المؤقتة (Flows)
# ============================================================
# هيكل التدفق: مفتاح = (src_ip, dst_ip, src_port, dst_port, proto)
# القيمة = قائمة بالحزم (لحساب الميزات)
flows = defaultdict(list)

# مدة تجميع التدفق (بالثواني) قبل التنبؤ
FLOW_TIMEOUT = 30  # 30 ثانية

# قفل للوصول الآمن إلى التدفقات
flow_lock = threading.Lock()

# ============================================================
# 3. استخراج الميزات من التدفق (محاكاة لميزات UNSW-NB15)
# ============================================================

def extract_features(packets):
    """
    استخراج 41 ميزة من قائمة الحزم (محاكاة لميزات UNSW-NB15).
    في الواقع، يجب استخدام أداة مثل CICFlowMeter للحصول على ميزات دقيقة.
    لكن هذا النموذج المبسط يوضح الفكرة.
    """
    if not packets:
        return None

    # إحصائيات بسيطة
    total_bytes = sum(len(p) for p in packets)
    total_packets = len(packets)
    durations = []  # الفروق الزمنية بين الحزم
    for i in range(1, len(packets)):
        if packets[i].time and packets[i-1].time:
            durations.append(packets[i].time - packets[i-1].time)

    avg_duration = np.mean(durations) if durations else 0
    std_duration = np.std(durations) if durations else 0

    # بروتوكولات
    tcp_count = sum(1 for p in packets if TCP in p)
    udp_count = sum(1 for p in packets if UDP in p)
    icmp_count = sum(1 for p in packets if ICMP in p)

    # ميزات إضافية (محاكاة)
    features = [
        total_bytes,          # 1
        total_packets,        # 2
        avg_duration,         # 3
        std_duration,         # 4
        tcp_count,            # 5
        udp_count,            # 6
        icmp_count,           # 7
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  # 8-17 (قيم افتراضية)
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  # 18-27
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  # 28-37
        0, 0, 0                    # 38-41
    ]
    # قص أو حشو إلى 41 ميزة
    if len(features) < 41:
        features += [0] * (41 - len(features))
    else:
        features = features[:41]
    return np.array(features).reshape(1, -1)

# ============================================================
# 4. معالج الحزم
# ============================================================

def packet_handler(packet):
    """تستقبل كل حزمة وتقوم بتجميعها في التدفق المناسب."""
    if IP not in packet:
        return

    ip = packet[IP]
    src_ip = ip.src
    dst_ip = ip.dst
    proto = ip.proto

    # تحديد المنافذ
    src_port = 0
    dst_port = 0
    if TCP in packet:
        src_port = packet[TCP].sport
        dst_port = packet[TCP].dport
    elif UDP in packet:
        src_port = packet[UDP].sport
        dst_port = packet[UDP].dport
    # ICMP ليس له منافذ

    # مفتاح التدفق (نأخذ الاتجاه المصدر->الوجهة)
    flow_key = (src_ip, dst_ip, src_port, dst_port, proto)

    with flow_lock:
        flows[flow_key].append(packet)

        # إذا تجاوز عدد الحزم حداً معيناً، نقوم بالتنبؤ فوراً
        if len(flows[flow_key]) >= 20:  # عتبة سريعة
            predict_flow(flow_key)

# ============================================================
# 5. التنبؤ بالتدفق
# ============================================================

def predict_flow(flow_key):
    """استخراج الميزات والتنبؤ بتصنيف التدفق."""
    with flow_lock:
        if flow_key not in flows or not flows[flow_key]:
            return
        packets = flows[flow_key]
        # لا نمسح التدفق بعد التنبؤ (يمكن الاحتفاظ به لتحليل أطول)
        # لكن ننظفه لمنع تراكم الذاكرة
        del flows[flow_key]

    # استخراج الميزات
    features = extract_features(packets)
    if features is None:
        return

    # التنبؤ
    try:
        proba = model.predict_proba(features)[0]
        pred = int(proba >= model.best_threshold)
        label = "🚨 ATTACK" if pred == 1 else "✅ NORMAL"
        print(f"[{time.strftime('%H:%M:%S')}] {flow_key} → {label} (prob={proba:.3f})")
    except Exception as e:
        print(f"⚠️  خطأ في التنبؤ: {e}")

# ============================================================
# 6. المؤقت لتنظيف التدفقات القديمة
# ============================================================

def cleanup_flows():
    """تنظيف التدفقات التي تجاوزت مدة المهلة."""
    while True:
        time.sleep(FLOW_TIMEOUT)
        now = time.time()
        with flow_lock:
            for key, packets in list(flows.items()):
                if packets:
                    # إذا مرت مدة المهلة على آخر حزمة
                    last_time = max(p.time for p in packets)
                    if now - last_time > FLOW_TIMEOUT:
                        predict_flow(key)

# ============================================================
# 7. بدء البث المباشر
# ============================================================

def start_streaming(interface="eth0", count=0):
    """
    بدء التقاط الحزم من واجهة الشبكة.
    interface: اسم الواجهة (مثل eth0, wlan0, lo)
    count: عدد الحزم المطلوب التقاطها (0 = غير محدود)
    """
    print(f"🔍 بدء المراقبة على الواجهة {interface}...")
    print(f"⏱️  مهلة التدفق: {FLOW_TIMEOUT} ثانية")
    print("=" * 60)

    # تشغيل مؤقت التنظيف في خلفية
    cleanup_thread = threading.Thread(target=cleanup_flows, daemon=True)
    cleanup_thread.start()

    # بدء الالتقاط
    sniff(iface=interface, prn=packet_handler, store=False, count=count)

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        interface = sys.argv[1]
    else:
        interface = "lo"  # افتراضي: واجهة الاسترجاع (للاختبار)
        print(f"⚠️  لم يتم تحديد واجهة، استخدام {interface} للاختبار.")
    start_streaming(interface)