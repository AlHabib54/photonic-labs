# -*- coding: utf-8 -*-
"""
NeoAMONA Enterprise Server v5.1 - مع دعم وضعي التشغيل (Fast / Normal)
"""

import pickle
import numpy as np
import pandas as pd
import io
import os
import time
import logging
import base64
import argparse
from typing import List, Optional
from fastapi import FastAPI, UploadFile, File, HTTPException, Header, Form
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from sklearn.preprocessing import LabelEncoder
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import uvicorn
import warnings
warnings.filterwarnings('ignore')

# استيراد الخوارزمية المحسنة
from neoamona_core import NeoAMONACore

# ============================================================
# 1. إعداد نظام التسجيل (Logging)
# ============================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("neoamona.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("NeoAMONA")

# ============================================================
# 2. نظام الاشتراكات والتراخيص
# ============================================================
TIER_LIMITS = {
    "free": {"max_rows": 1000, "name": "Freemium", "color": "#94a3b8"},
    "pro": {"max_rows": 100000, "name": "Professional", "color": "#818cf8"},
    "enterprise": {"max_rows": float('inf'), "name": "Enterprise", "color": "#fbbf24"}
}

MOCK_API_KEYS = {
    "free_key_123": "free",
    "pro_key_789": "pro",
    "enterprise_key_000": "enterprise"
}

app = FastAPI(title="NeoAMONA Enterprise")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

MODEL_PATH = "models/neoamona_core_model.pkl"
ENCRYPTED_MODEL_PATH = "models/neoamona_core_model.pkl.enc"
ENCRYPTION_PASSWORD = "NeoAMONA_Secure_Key_2026"  # غيّر هذا في الإنتاج

model = None

# ============================================================
# 3. دوال التشفير وفك التشفير
# ============================================================

def generate_key(password: str, salt: bytes = None) -> tuple:
    if salt is None:
        salt = os.urandom(16)
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=100000)
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    return key, salt

def decrypt_model_file(encrypted_path: str, password: str) -> bytes:
    if not os.path.exists(encrypted_path):
        raise FileNotFoundError(f"Encrypted model not found: {encrypted_path}")
    with open(encrypted_path, 'rb') as f:
        salt = f.read(16)
        encrypted_data = f.read()
    key, _ = generate_key(password, salt)
    cipher = Fernet(key)
    return cipher.decrypt(encrypted_data)

def load_encrypted_model(encrypted_path: str, password: str):
    try:
        decrypted_data = decrypt_model_file(encrypted_path, password)
        model = pickle.loads(decrypted_data)
        logger.info("✅ Model decrypted and loaded successfully")
        return model
    except Exception as e:
        logger.error(f"❌ Failed to decrypt model: {str(e)}")
        return None

# ============================================================
# 4. تحميل النموذج
# ============================================================

@app.on_event("startup")
async def load_model():
    global model
    if os.path.exists(ENCRYPTED_MODEL_PATH):
        logger.info(f"🔐 Attempting to load encrypted model: {ENCRYPTED_MODEL_PATH}")
        model = load_encrypted_model(ENCRYPTED_MODEL_PATH, ENCRYPTION_PASSWORD)
        if model is not None:
            logger.info(f"✅ Encrypted model loaded successfully")
            logger.info(f"   - Active nodes: {model.active_nodes}")
            logger.info(f"   - Threshold: {model.best_threshold:.3f}")
            return
    if os.path.exists(MODEL_PATH):
        try:
            model = NeoAMONACore.load(MODEL_PATH)
            logger.info(f"✅ Plain model loaded from {MODEL_PATH}")
            return
        except Exception as e:
            logger.error(f"❌ Failed to load plain model: {e}")
    else:
        logger.warning(f"⚠️  Model not found at {MODEL_PATH} or {ENCRYPTED_MODEL_PATH}")

# ============================================================
# 5. دوال التحقق من الصلاحيات ومعالجة البيانات
# ============================================================

def validate_key(api_key: str) -> str:
    if api_key not in MOCK_API_KEYS:
        raise HTTPException(401, detail="❌ Invalid API key")
    return MOCK_API_KEYS[api_key]

def check_tier_limit(tier: str, rows: int):
    limit = TIER_LIMITS[tier]["max_rows"]
    if rows > limit:
        raise HTTPException(403, detail=f"❌ Row limit exceeded ({limit}) for {TIER_LIMITS[tier]['name']}")

def adapt_to_41_features(X: np.ndarray) -> np.ndarray:
    if X.ndim == 1:
        X = X.reshape(1, -1)
    target = 41
    current = X.shape[1]
    if current < target:
        return np.pad(X, ((0,0), (0, target-current)), 'constant')
    elif current > target:
        return X[:, :target]
    return X

def clean_data_smart(df: pd.DataFrame, target_col: Optional[str] = None):
    logger.info("🔄 Starting data cleaning...")
    start_time = time.time()
    
    if target_col and target_col in df.columns:
        y_raw = df[target_col].values
        try:
            y = np.array([0 if str(v).strip().upper() in ['BENIGN', 'NORMAL', '0'] else 1 for v in y_raw])
        except:
            y = np.array([0 if str(v).strip().lower() in ['normal', 'benign'] else 1 for v in y_raw])
        X_raw = df.drop(columns=[target_col])
        logger.info(f"✅ Target column: {target_col}")
    else:
        X_raw = df.copy()
        y = None
        logger.info("ℹ️  No target column specified")

    X_clean = []
    skipped = []
    for col_name in X_raw.columns:
        col = X_raw[col_name]
        if col.dtype == 'object' or col.dtype.name == 'category':
            try:
                le = LabelEncoder()
                col_filled = col.fillna('missing').astype(str)
                X_clean.append(le.fit_transform(col_filled).astype(float))
                continue
            except:
                skipped.append(col_name)
                continue
        try:
            col_numeric = pd.to_numeric(col, errors='coerce')
            mean_val = np.nanmean(col_numeric)
            if np.isnan(mean_val):
                mean_val = 0.0
            col_filled = np.nan_to_num(col_numeric, nan=mean_val)
            col_filled = np.clip(col_filled, -1e6, 1e6)
            X_clean.append(col_filled.astype(float))
        except:
            skipped.append(col_name)
            continue

    if len(X_clean) == 0:
        raise ValueError("❌ No valid columns found")

    X_final = np.column_stack(X_clean)
    X_final = adapt_to_41_features(X_final)
    X_final = np.nan_to_num(X_final, nan=0.0)
    
    logger.info(f"✅ Data cleaning completed in {time.time() - start_time:.2f}s")
    return X_final, y

def process_large_file_chunked(file_bytes: bytes, target_col: Optional[str] = None, chunk_size: int = 100000):
    logger.info(f"🔄 Starting chunked processing (chunk size: {chunk_size})")
    start_time = time.time()
    
    all_proba = []
    total_rows = 0
    total_attacks = 0
    
    try:
        df_iter = pd.read_csv(io.BytesIO(file_bytes), chunksize=chunk_size, low_memory=False)
    except Exception as e:
        raise ValueError(f"❌ Invalid CSV: {str(e)}")
    
    for i, chunk in enumerate(df_iter):
        logger.info(f"   - Chunk {i+1} ({len(chunk)} rows)")
        try:
            X_chunk, _ = clean_data_smart(chunk, target_col)
            if model is None:
                raise ValueError("Model not loaded")
            proba = model.predict_proba(X_chunk)
            if proba.ndim == 1:
                proba = np.column_stack([1 - proba, proba])
            y_pred = (proba[:, 1] >= model.best_threshold).astype(int)
            total_rows += len(X_chunk)
            total_attacks += int(np.sum(y_pred))
            all_proba.append(proba)
        except Exception as e:
            logger.error(f"❌ Chunk {i+1} error: {str(e)}")
            raise
    
    final_proba = np.vstack(all_proba) if all_proba else np.array([])
    logger.info(f"✅ Processing completed in {time.time() - start_time:.2f}s")
    logger.info(f"   - Total rows: {total_rows}, Attacks: {total_attacks}")
    return final_proba, total_rows, total_attacks

# ============================================================
# 6. نقاط النهاية (Endpoints)
# ============================================================

@app.get("/", response_class=HTMLResponse)
async def root():
    return HTML_PAGE

@app.get("/health")
async def health():
    return {"status": "ok", "model_loaded": model is not None}

@app.post("/api/predict")
async def predict(
    features: List[float],
    threshold: Optional[float] = None,
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(503, "Model not loaded")
    tier = validate_key(x_api_key)
    th = threshold if threshold is not None else model.best_threshold
    X = adapt_to_41_features(np.array(features).reshape(1, -1))
    proba = model.predict_proba(X)[0]
    pred = int(proba >= th)
    return {
        "prediction": "Attack" if pred else "Normal",
        "probability": float(proba),
        "threshold_used": float(th),
        "tier": tier
    }

@app.post("/api/upload")
async def upload_file(
    file: UploadFile = File(...),
    target_column: Optional[str] = None,
    mode: str = Form('normal'),
    x_api_key: str = Header(...)
):
    global model
    if model is None:
        raise HTTPException(503, "Model not loaded")
    
    tier = validate_key(x_api_key)
    contents = await file.read()
    
    try:
        df = pd.read_csv(io.BytesIO(contents))
    except Exception as e:
        raise HTTPException(400, detail=f"❌ Invalid CSV: {str(e)}")
    
    if df.empty:
        raise HTTPException(400, detail="❌ File is empty")
    
    check_tier_limit(tier, df.shape[0])
    logger.info(f"📦 Processing: {df.shape[0]} rows, Mode: {mode.upper()}")
    
    # تنظيف البيانات
    X, y = clean_data_smart(df, target_column)
    
    if y is None:
        # إذا لم يتم تحديد عمود هدف، نحاول استخدام العمود الأخير
        y = df.iloc[:, -1].values
        try:
            y = np.array([0 if str(v).strip().upper() in ['BENIGN', 'NORMAL', '0'] else 1 for v in y])
        except:
            y = np.array([0 if str(v).strip().lower() in ['normal', 'benign'] else 1 for v in y])
    
    # تقسيم البيانات
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)
    
    # تدريب NeoAMONA مع الوضع المختار
    logger.info(f"🚀 Training NeoAMONA in {mode.upper()} mode...")
    start_time = time.time()
    
    neo = NeoAMONACore()
    neo.fit(X_train, y_train, mode=mode)  # <-- تمرير الوضع هنا
    
    training_time = time.time() - start_time
    
    # حفظ النموذج المدرب
    neo.save(MODEL_PATH)
    model = neo  # تحديث النموذج العالمي
    
    # تقييم النموذج
    y_pred = neo.predict(X_test)
    y_proba = neo.predict_proba(X_test)
    
    from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    roc_auc = roc_auc_score(y_test, y_proba)
    cm = confusion_matrix(y_test, y_pred)
    
    tn, fp, fn, tp = cm.ravel() if cm.shape == (2, 2) else (0, 0, 0, 0)
    
    logger.info(f"✅ Training completed in {training_time:.2f}s")
    logger.info(f"   - Accuracy: {accuracy:.4f}, F1: {f1:.4f}, ROC-AUC: {roc_auc:.4f}")
    
    return {
        "status": "success",
        "tier": tier,
        "mode": mode,
        "total_rows": X.shape[0],
        "training_time": training_time,
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "roc_auc": roc_auc,
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
        "threshold": neo.best_threshold,
        "active_nodes": neo.active_nodes
    }

# ============================================================
# 7. HTML الرئيسي (مع خيار وضع التشغيل)
# ============================================================

HTML_PAGE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NeoAMONA Enterprise</title>
    <style>
        * { box-sizing: border-box; margin: 0; }
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #0f172a; color: #e2e8f0; padding: 20px; min-height: 100vh; }
        .container { max-width: 1100px; margin: 0 auto; }
        .header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 20px; }
        .logo { font-size: 28px; font-weight: bold; color: #818cf8; }
        .badge { background: #334155; padding: 6px 16px; border-radius: 50px; font-size: 13px; color: #94a3b8; display: inline-block; }
        .badge-pro { background: rgba(99,102,241,0.2); color: #818cf8; }
        .badge-enterprise { background: rgba(251,191,36,0.2); color: #fbbf24; }
        .card { background: #1e293b; border-radius: 16px; padding: 24px; margin: 16px 0; box-shadow: 0 4px 20px rgba(0,0,0,0.3); }
        .card h2 { color: #818cf8; margin-top: 0; font-size: 20px; }
        .stats { display: flex; gap: 16px; flex-wrap: wrap; }
        .stat { background: #0f172a; padding: 12px 24px; border-radius: 12px; flex: 1; min-width: 100px; text-align: center; }
        .stat .num { font-size: 28px; font-weight: bold; }
        .stat .lbl { color: #94a3b8; font-size: 14px; }
        .upload-zone { border: 2px dashed #334155; border-radius: 16px; padding: 40px 20px; text-align: center; cursor: pointer; transition: 0.3s; }
        .upload-zone:hover { border-color: #818cf8; background: rgba(99,102,241,0.05); }
        .upload-zone.dragover { border-color: #22c55e; background: rgba(34,197,94,0.05); }
        .upload-zone input[type="file"] { display: none; }
        .feature-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(48px, 1fr)); gap: 4px; margin: 12px 0; }
        .feature-grid input { width: 100%; padding: 4px; text-align: center; border-radius: 6px; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; font-size: 12px; }
        .btn { background: #818cf8; border: none; color: #0f172a; padding: 10px 24px; border-radius: 8px; font-weight: bold; cursor: pointer; transition: 0.3s; }
        .btn:hover { background: #6366f1; transform: translateY(-2px); }
        .btn-secondary { background: transparent; border: 1px solid #334155; color: #e2e8f0; }
        .btn-secondary:hover { background: #334155; }
        .btn-upgrade { background: #f59e0b; color: #0f172a; }
        .btn-upgrade:hover { background: #d97706; }
        .flex { display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }
        .mt-2 { margin-top: 16px; }
        .text-muted { color: #94a3b8; font-size: 14px; }
        .result-box { padding: 12px; border-radius: 8px; margin-top: 12px; }
        .result-box.success { background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); }
        .result-box.danger { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); }
        .log { background: #0f172a; padding: 12px; border-radius: 8px; max-height: 200px; overflow-y: auto; }
        .log div { padding: 4px 0; border-bottom: 1px solid #1e293b; font-size: 13px; }
        .toast { position: fixed; bottom: 20px; right: 20px; background: #1e293b; padding: 12px 24px; border-radius: 12px; border-left: 4px solid #818cf8; max-width: 400px; z-index: 999; animation: slideIn 0.3s ease; }
        .toast.error { border-left-color: #ef4444; }
        .toast.success { border-left-color: #22c55e; }
        @keyframes slideIn { from { transform: translateX(100px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); justify-content: center; align-items: center; z-index: 1000; }
        .modal-overlay.active { display: flex; }
        .modal { background: #1e293b; padding: 32px; border-radius: 16px; max-width: 450px; width: 90%; border: 1px solid #334155; }
        .modal .plan { background: #0f172a; padding: 16px; border-radius: 12px; text-align: center; border: 1px solid #334155; margin: 8px 0; }
        .modal .plan:hover { border-color: #818cf8; }
        .modal .plan .price { font-size: 24px; font-weight: bold; color: #818cf8; }
        .modal .plan .name { font-weight: bold; font-size: 18px; }
        .modal .plan ul { list-style: none; padding: 0; font-size: 13px; color: #94a3b8; }
        .key-selector { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
        .key-selector select { flex: 1; min-width: 180px; padding: 8px 12px; border-radius: 8px; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; }
        .mode-selector select { padding: 8px 12px; border-radius: 8px; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; min-width: 150px; }
        .mode-selector .mode-info { font-size: 12px; color: #94a3b8; margin-top: 4px; }
        input[type="text"], input[type="password"] { padding: 8px 12px; border-radius: 8px; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; width: 100%; }
        @media (max-width: 600px) { .stats { flex-direction: column; } .feature-grid { grid-template-columns: repeat(8, 1fr); } }
        .mode-tag { display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 11px; font-weight: bold; }
        .mode-tag.fast { background: rgba(34,197,94,0.2); color: #22c55e; }
        .mode-tag.normal { background: rgba(99,102,241,0.2); color: #818cf8; }
    </style>
</head>
<body>
<div class="container">
    <!-- Header -->
    <div class="header">
        <div class="logo">🛡️ NeoAMONA</div>
        <div>
            <span class="badge" id="tierBadge">🔓 Freemium</span>
            <span class="badge" id="reqBadge" style="margin-left:8px;">Requests: 10</span>
        </div>
    </div>

    <!-- API Key + Mode Selector -->
    <div class="card">
        <div class="key-selector" style="margin-bottom:12px;">
            <div style="flex:1;">
                <label style="color:#94a3b8; font-size:14px;">🔑 API Key</label>
                <select id="apiKeySelect">
                    <option value="free_key_123">Free Key (Freemium)</option>
                    <option value="pro_key_789">Pro Key (Professional)</option>
                    <option value="enterprise_key_000">Enterprise Key</option>
                </select>
            </div>
            <div>
                <label style="color:#94a3b8; font-size:14px;">&nbsp;</label>
                <button class="btn btn-upgrade" onclick="openUpgradeModal()">⬆️ Upgrade</button>
            </div>
        </div>
        
        <!-- Mode Selector (NEW) -->
        <div class="mode-selector">
            <label style="color:#94a3b8; font-size:14px;">⚡ Mode</label>
            <select id="modeSelect">
                <option value="normal">Normal (High Accuracy)</option>
                <option value="fast">Fast (Speed Optimized)</option>
            </select>
            <div class="mode-info">
                <span id="modeDescription">🐢 Normal: أفضل دقة (قد يستغرق تدريباً أطول)</span>
            </div>
        </div>
        
        <div style="margin-top:8px; font-size:13px; color:#94a3b8;">
            💡 Current plan: <span id="currentPlanDisplay">Freemium</span> · Max rows: <span id="maxRowsDisplay">1,000</span>
        </div>
    </div>

    <!-- Stats -->
    <div class="stats" id="stats">
        <div class="stat"><div class="num" id="statTotal">0</div><div class="lbl">Total Rows</div></div>
        <div class="stat"><div class="num" style="color:#ef4444;" id="statAttacks">0</div><div class="lbl">Attacks</div></div>
        <div class="stat"><div class="num" style="color:#22c55e;" id="statNormal">0</div><div class="lbl">Normal</div></div>
        <div class="stat"><div class="num" style="color:#f59e0b;" id="statRatio">0%</div><div class="lbl">Attack Ratio</div></div>
    </div>

    <!-- Upload -->
    <div class="card">
        <h2>📤 Upload CSV</h2>
        <div class="upload-zone" id="uploadZone">
            <div style="font-size:40px;">📁</div>
            <p><strong>Drop CSV here</strong> or click to browse</p>
            <p class="text-muted">Max rows: <span id="maxRowsDisplay2">1,000</span></p>
            <input type="file" id="fileInput" accept=".csv">
            <div style="margin-top:12px;">
                <input type="text" id="targetCol" placeholder="Target column (optional)" style="width:200px; display:inline-block;">
            </div>
        </div>
        <div id="uploadResult" class="mt-2"></div>
        <div id="trainingProgress" style="display:none; margin-top:12px;">
            <p class="text-muted">🔄 Training in progress... This may take a few minutes.</p>
            <div style="height:4px; background:#334155; border-radius:4px; overflow:hidden;">
                <div style="width:100%; height:100%; background:#818cf8; animation: pulse 1.5s infinite;"></div>
            </div>
        </div>
    </div>

    <!-- Predict -->
    <div class="card">
        <h2>⚡ Single Prediction</h2>
        <p class="text-muted">Enter 41 numeric features</p>
        <div class="feature-grid" id="featureGrid"></div>
        <div class="flex mt-2">
            <button class="btn" id="predictBtn">Predict</button>
            <button class="btn btn-secondary" id="randomBtn">🎲 Random</button>
        </div>
        <div id="predictResult" class="mt-2"></div>
    </div>

    <!-- Log -->
    <div class="card">
        <h2>📋 Activity Log</h2>
        <div class="log" id="logContainer"><div class="text-muted" style="text-align:center;">No activity yet.</div></div>
    </div>
</div>

<!-- Upgrade Modal -->
<div class="modal-overlay" id="upgradeModal">
    <div class="modal">
        <h2>⬆️ Upgrade to Professional</h2>
        <div class="plan">
            <div class="name">Professional</div>
            <div class="price">$999</div>
            <ul>
                <li>✅ 100,000 rows per upload</li>
                <li>✅ 1,000 API requests / day</li>
                <li>✅ Threshold tuning</li>
                <li>✅ CSV report export</li>
                <li>✅ Priority support</li>
            </ul>
        </div>
        <div style="margin:16px 0;">
            <label style="color:#94a3b8;">Payment Token</label>
            <input type="text" id="paymentToken" placeholder="Enter payment token" value="demo_payment">
            <div style="font-size:12px; color:#94a3b8; margin-top:4px;">🔑 Use <code>demo_payment</code> for testing</div>
        </div>
        <div class="flex" style="justify-content:flex-end;">
            <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
            <button class="btn btn-upgrade" onclick="confirmUpgrade()">Confirm Upgrade</button>
        </div>
    </div>
</div>

<div id="toastContainer" style="position:fixed; bottom:20px; right:20px; z-index:999;"></div>

<script>
// ============================================================
// State
// ============================================================
let state = {
    apiKey: 'free_key_123',
    tier: 'free',
    limits: { free: 1000, pro: 100000, enterprise: Infinity },
    names: { free: 'Freemium', pro: 'Professional', enterprise: 'Enterprise' }
};

// ============================================================
// DOM References
// ============================================================
const tierBadge = document.getElementById('tierBadge');
const reqBadge = document.getElementById('reqBadge');
const maxRowsDisplay = document.getElementById('maxRowsDisplay');
const maxRowsDisplay2 = document.getElementById('maxRowsDisplay2');
const currentPlanDisplay = document.getElementById('currentPlanDisplay');
const apiKeySelect = document.getElementById('apiKeySelect');
const modeSelect = document.getElementById('modeSelect');
const modeDescription = document.getElementById('modeDescription');
const uploadZone = document.getElementById('uploadZone');
const fileInput = document.getElementById('fileInput');
const targetCol = document.getElementById('targetCol');
const uploadResult = document.getElementById('uploadResult');
const trainingProgress = document.getElementById('trainingProgress');
const featureGrid = document.getElementById('featureGrid');
const predictBtn = document.getElementById('predictBtn');
const randomBtn = document.getElementById('randomBtn');
const predictResult = document.getElementById('predictResult');
const logContainer = document.getElementById('logContainer');
const upgradeModal = document.getElementById('upgradeModal');
const paymentToken = document.getElementById('paymentToken');
const toastContainer = document.getElementById('toastContainer');

// ============================================================
// Create feature grid (41 fields)
// ============================================================
for (let i = 0; i < 41; i++) {
    let inp = document.createElement('input');
    inp.type = 'number';
    inp.value = '0';
    inp.step = 'any';
    inp.id = 'f' + i;
    inp.placeholder = i;
    featureGrid.appendChild(inp);
}

// ============================================================
// Mode Selector Update
// ============================================================
modeSelect.addEventListener('change', function() {
    const mode = this.value;
    if (mode === 'fast') {
        modeDescription.innerHTML = '⚡ Fast: سرعة عالية (اختيار العقد باستخدام عينة صغيرة)';
        modeDescription.style.color = '#22c55e';
    } else {
        modeDescription.innerHTML = '🐢 Normal: دقة عالية (اختيار العقد باستخدام كامل البيانات)';
        modeDescription.style.color = '#94a3b8';
    }
});

// ============================================================
// UI Update Functions
// ============================================================
function updateTier(tier) {
    state.tier = tier;
    tierBadge.textContent = '🔓 ' + state.names[tier];
    currentPlanDisplay.textContent = state.names[tier];
    const limit = state.limits[tier];
    maxRowsDisplay.textContent = limit === Infinity ? '∞' : limit;
    maxRowsDisplay2.textContent = limit === Infinity ? '∞' : limit;
    const reqs = tier === 'free' ? 10 : tier === 'pro' ? 1000 : '∞';
    reqBadge.textContent = 'Requests: ' + reqs;
    
    if (tier === 'pro') { apiKeySelect.value = 'pro_key_789'; state.apiKey = 'pro_key_789'; }
    else if (tier === 'enterprise') { apiKeySelect.value = 'enterprise_key_000'; state.apiKey = 'enterprise_key_000'; }
    else { apiKeySelect.value = 'free_key_123'; state.apiKey = 'free_key_123'; }
}

function showToast(msg, type = 'info') {
    let div = document.createElement('div');
    div.className = 'toast ' + type;
    div.textContent = msg;
    toastContainer.appendChild(div);
    setTimeout(() => { div.style.opacity = '0'; setTimeout(() => div.remove(), 300); }, 4000);
}

function addLog(msg) {
    let placeholder = logContainer.querySelector('.text-muted');
    if (placeholder) placeholder.remove();
    let div = document.createElement('div');
    let time = new Date().toLocaleTimeString();
    div.innerHTML = '<span style="color:#94a3b8;">[' + time + ']</span> ' + msg;
    logContainer.prepend(div);
}

function updateStats(data) {
    document.getElementById('statTotal').textContent = data.total_rows || 0;
    document.getElementById('statAttacks').textContent = data.attacks_detected || 0;
    document.getElementById('statNormal').textContent = data.normal_count || 0;
    document.getElementById('statRatio').textContent = data.attack_ratio || '0%';
}

// ============================================================
// API Key Selector
// ============================================================
apiKeySelect.addEventListener('change', function() {
    state.apiKey = this.value;
    const tier = this.value === 'free_key_123' ? 'free' : this.value === 'pro_key_789' ? 'pro' : 'enterprise';
    updateTier(tier);
    showToast('🔑 Switched to ' + state.tier, 'info');
    addLog('🔑 API key changed to ' + tier);
});

// ============================================================
// File Upload Handler
// ============================================================
async function uploadFile(file) {
    if (!file) return;
    
    let reader = new FileReader();
    reader.onload = async function(e) {
        let lines = e.target.result.split('\\n').filter(l => l.trim() !== '');
        let rows = lines.length - 1;
        let limit = state.limits[state.tier];
        
        if (rows > limit && limit !== Infinity) {
            showToast('❌ Your tier allows only ' + limit + ' rows. Upgrade to Pro.', 'error');
            return;
        }
        
        let formData = new FormData();
        formData.append('file', file);
        let tc = targetCol.value.trim();
        if (tc) formData.append('target_column', tc);
        formData.append('mode', modeSelect.value);  // <-- إضافة الوضع المختار
        
        trainingProgress.style.display = 'block';
        uploadResult.innerHTML = '';
        
        try {
            let resp = await fetch('/api/upload', {
                method: 'POST',
                headers: { 'x-api-key': state.apiKey },
                body: formData
            });
            let data = await resp.json();
            
            if (!resp.ok) {
                showToast('❌ ' + (data.detail || 'Upload failed'), 'error');
                trainingProgress.style.display = 'none';
                return;
            }
            
            // عرض النتائج التفصيلية
            const modeTag = data.mode === 'fast' ? '<span class="mode-tag fast">⚡ FAST</span>' : '<span class="mode-tag normal">🐢 NORMAL</span>';
            uploadResult.innerHTML = `
                <div style="background:rgba(34,197,94,0.1); padding:16px; border-radius:8px; border:1px solid rgba(34,197,94,0.3);">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                        <div>
                            <strong>${data.total_rows}</strong> rows · 
                            <strong style="color:#ef4444;">${data.attacks_detected || 0}</strong> attacks · 
                            <strong style="color:#22c55e;">${data.normal_count || 0}</strong> normal
                        </div>
                        ${modeTag}
                    </div>
                    <div style="margin-top:8px; font-size:13px; color:#94a3b8;">
                        ⏱️ Training: ${data.training_time?.toFixed(1) || '?'}s · 
                        F1: <strong>${(data.f1 * 100).toFixed(2)}%</strong> · 
                        Accuracy: <strong>${(data.accuracy * 100).toFixed(2)}%</strong>
                    </div>
                    <div style="margin-top:4px; font-size:12px; color:#64748b;">
                        Nodes: ${data.active_nodes?.join(' → ') || 'N/A'} · Threshold: ${data.threshold?.toFixed(3) || 'N/A'}
                    </div>
                    ${data.confusion_matrix ? `
                    <div style="margin-top:8px; font-size:12px; color:#94a3b8; display:flex; gap:12px; flex-wrap:wrap;">
                        <span>✅ TN: ${data.confusion_matrix.tn}</span>
                        <span style="color:#ef4444;">❌ FP: ${data.confusion_matrix.fp}</span>
                        <span style="color:#f59e0b;">⚠️ FN: ${data.confusion_matrix.fn}</span>
                        <span style="color:#22c55e;">✅ TP: ${data.confusion_matrix.tp}</span>
                    </div>` : ''}
                </div>
            `;
            
            addLog('✅ Uploaded ' + file.name + ' (' + data.mode.toUpperCase() + '): ' + 
                   (data.attacks_detected || 0) + ' attacks, ' + 
                   (data.normal_count || 0) + ' normal · F1: ' + (data.f1 * 100).toFixed(2) + '%');
            
            showToast('✅ File analyzed successfully! (' + data.mode.toUpperCase() + ' mode)', 'success');
            
            // تحديث الإحصائيات
            document.getElementById('statTotal').textContent = data.total_rows || 0;
            document.getElementById('statAttacks').textContent = data.attacks_detected || 0;
            document.getElementById('statNormal').textContent = data.normal_count || 0;
            document.getElementById('statRatio').textContent = ((data.attacks_detected || 0) / (data.total_rows || 1) * 100).toFixed(2) + '%';
            
            if (data.remaining_requests !== undefined) {
                reqBadge.textContent = 'Requests: ' + data.remaining_requests;
            }
            
        } catch (err) {
            showToast('❌ Connection error: ' + err.message, 'error');
            console.error(err);
        }
        trainingProgress.style.display = 'none';
    };
    reader.readAsText(file);
}

// ============================================================
// Drag & Drop Events
// ============================================================
uploadZone.addEventListener('click', () => fileInput.click());
uploadZone.addEventListener('dragover', (e) => { e.preventDefault(); uploadZone.classList.add('dragover'); });
uploadZone.addEventListener('dragleave', () => { uploadZone.classList.remove('dragover'); });
uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.classList.remove('dragover');
    if (e.dataTransfer.files.length) {
        uploadFile(e.dataTransfer.files[0]);
    }
});
fileInput.addEventListener('change', () => {
    if (fileInput.files.length) {
        uploadFile(fileInput.files[0]);
    }
});

// ============================================================
// Single Prediction
// ============================================================
predictBtn.addEventListener('click', async function() {
    let feats = [];
    for (let i = 0; i < 41; i++) {
        let v = parseFloat(document.getElementById('f' + i).value);
        feats.push(isNaN(v) ? 0 : v);
    }
    
    try {
        let resp = await fetch('/api/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': state.apiKey
            },
            body: JSON.stringify({ features: feats })
        });
        let data = await resp.json();
        
        if (!resp.ok) {
            showToast('❌ ' + (data.detail || 'Prediction failed'), 'error');
            return;
        }
        
        let cls = data.prediction === 'Attack' ? 'danger' : 'success';
        predictResult.innerHTML = '<div class="result-box ' + cls + '"><strong>' + data.prediction + '</strong> · Probability: ' + (data.probability * 100).toFixed(2) + '%<br><span class="text-muted">Threshold: ' + data.threshold_used + '</span></div>';
        addLog('🔮 Prediction: ' + data.prediction + ' (' + (data.probability * 100).toFixed(2) + '%)');
    } catch (err) {
        showToast('❌ Connection error: ' + err.message, 'error');
        console.error(err);
    }
});

// ============================================================
// Random Fill
// ============================================================
randomBtn.addEventListener('click', () => {
    for (let i = 0; i < 41; i++) {
        document.getElementById('f' + i).value = (Math.random() * 10).toFixed(2);
    }
});

// ============================================================
// Upgrade Functions
// ============================================================
function openUpgradeModal() { upgradeModal.classList.add('active'); }
function closeModal() { upgradeModal.classList.remove('active'); }

function confirmUpgrade() {
    let token = paymentToken.value.trim();
    if (token === 'demo_payment') {
        state.apiKey = 'pro_key_789';
        updateTier('pro');
        showToast('✅ Upgraded to Professional!', 'success');
        addLog('⬆️ Upgraded to Professional plan');
        closeModal();
        reqBadge.textContent = 'Requests: ∞';
        apiKeySelect.value = 'pro_key_789';
    } else {
        showToast('❌ Invalid payment token. Use "demo_payment" for testing.', 'error');
    }
}

upgradeModal.addEventListener('click', (e) => { if (e.target === upgradeModal) closeModal(); });

// ============================================================
// Initialization
// ============================================================
updateTier('free');
addLog('🚀 NeoAMONA ready. Select mode and upload CSV or try prediction.');
console.log('✅ NeoAMONA v5.1 loaded successfully.');
</script>
</body>
</html>
"""

# ============================================================
# 8. تشغيل الخادم
# ============================================================

if __name__ == "__main__":
    print("="*60)
    print("🚀 NeoAMONA Enterprise Server v5.1 - مع دعم وضعي التشغيل")
    print("="*60)
    print("✅ Fast mode: اختيار العقد باستخدام عينة صغيرة (سرعة)")
    print("✅ Normal mode: اختيار العقد باستخدام كامل البيانات (دقة)")
    print("="*60)
    uvicorn.run("neoamona_server:app", host="0.0.0.0", port=8080, reload=False)