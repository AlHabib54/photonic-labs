# -*- coding: utf-8 -*-
"""
NeoAMONA Enterprise Server - مع زر ترقية وحقل مفتاح API
"""

import pickle
import numpy as np
import pandas as pd
import io
import os
import uuid
from typing import List, Optional
from fastapi import FastAPI, UploadFile, File, HTTPException, Header, Form
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

try:
    from neoamona_core import NeoAMONACore
except ImportError:
    print("⚠️  neoamona_core.py not found")
    exit(1)

# ============================================================
# 1. نظام الاشتراكات
# ============================================================

TIER_LIMITS = {
    "free": {"max_rows": 1000, "name": "Freemium", "price": "$0"},
    "pro": {"max_rows": 100000, "name": "Professional", "price": "$999/mo"},
    "enterprise": {"max_rows": float('inf'), "name": "Enterprise", "price": "Contact"}
}

MOCK_API_KEYS = {
    "free_key_123": "free",
    "pro_key_789": "pro",
    "enterprise_key_000": "enterprise"
}

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

MODEL_PATH = "models/neoamona_core_model.pkl"
model = None

@app.on_event("startup")
async def load_model():
    global model
    if os.path.exists(MODEL_PATH):
        model = NeoAMONACore.load(MODEL_PATH)
        print(f"✅ Model loaded")
    else:
        print(f"⚠️  Model not found")

def validate_key(api_key: str) -> str:
    if api_key not in MOCK_API_KEYS:
        raise HTTPException(401, "Invalid API key")
    return MOCK_API_KEYS[api_key]

def clean_data(df: pd.DataFrame, target_col: Optional[str] = None):
    if target_col and target_col in df.columns:
        y = df[target_col].values
        y = np.array([0 if str(v).strip().upper() == 'BENIGN' or v == 0 else 1 for v in y])
        X_raw = df.drop(columns=[target_col]).values
    else:
        X_raw = df.values
        y = None
    X_clean = []
    for i in range(X_raw.shape[1]):
        col = pd.to_numeric(X_raw[:, i], errors='coerce')
        mean = np.nanmean(col)
        col = np.nan_to_num(col, nan=mean)
        X_clean.append(col)
    return np.column_stack(X_clean).astype(float), y

# ============================================================
# 2. HTML مع حقل مفتاح API وزر ترقية
# ============================================================

HTML_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>NeoAMONA</title>
    <style>
        body { font-family: Arial; background: #0f172a; color: #e2e8f0; padding: 20px; }
        .container { max-width: 1000px; margin: 0 auto; }
        .card { background: #1e293b; border-radius: 12px; padding: 20px; margin: 16px 0; }
        .upload-zone { border: 2px dashed #334155; padding: 30px; text-align: center; cursor: pointer; transition: 0.3s; }
        .upload-zone.dragover { border-color: #818cf8; background: rgba(99,102,241,0.05); }
        .btn { background: #818cf8; border: none; color: #0f172a; padding: 8px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; }
        .btn:hover { background: #6366f1; }
        .btn-secondary { background: transparent; border: 1px solid #334155; color: #e2e8f0; }
        .btn-secondary:hover { background: #334155; }
        .btn-success { background: #22c55e; color: #0f172a; }
        .btn-success:hover { background: #16a34a; }
        .feature-grid { display: grid; grid-template-columns: repeat(10, 1fr); gap: 4px; margin: 10px 0; }
        .feature-grid input { width: 100%; padding: 4px; text-align: center; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; border-radius: 4px; }
        .log { background: #0f172a; padding: 10px; border-radius: 6px; max-height: 150px; overflow-y: auto; }
        .stat { display: inline-block; background: #0f172a; padding: 8px 20px; border-radius: 8px; margin-right: 10px; }
        .stat .num { font-size: 24px; font-weight: bold; }
        .result-box { padding: 10px; border-radius: 6px; margin-top: 10px; }
        .result-box.success { background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); }
        .result-box.danger { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); }
        input[type="text"], input[type="password"] { padding: 6px; border-radius: 6px; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; }
        .flex { display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }
        .mt-2 { margin-top: 12px; }
        .toast { position: fixed; bottom: 20px; right: 20px; background: #1e293b; padding: 10px 20px; border-radius: 8px; border-left: 4px solid #818cf8; z-index: 999; }
        .toast.error { border-left-color: #ef4444; }
        .toast.success { border-left-color: #22c55e; }
        .badge { background: #334155; padding: 4px 14px; border-radius: 50px; font-size: 13px; }
        .badge.pro { background: rgba(99,102,241,0.2); color: #818cf8; }
        .badge.enterprise { background: rgba(251,191,36,0.2); color: #fbbf24; }
        .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); justify-content: center; align-items: center; z-index: 1000; }
        .modal-overlay.active { display: flex; }
        .modal { background: #1e293b; padding: 32px; border-radius: 16px; max-width: 500px; width: 90%; border: 1px solid #334155; }
        .modal .plan { background: #0f172a; padding: 16px; border-radius: 12px; margin: 8px 0; cursor: pointer; border: 1px solid #334155; }
        .modal .plan:hover { border-color: #818cf8; }
        .modal .plan .price { font-size: 20px; font-weight: bold; color: #818cf8; }
        @media (max-width: 600px) { .feature-grid { grid-template-columns: repeat(5, 1fr); } }
    </style>
</head>
<body>
<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
        <h1 style="color:#818cf8;">🛡️ NeoAMONA</h1>
        <div>
            <span class="badge" id="tierBadge">🔓 Freemium</span>
            <span class="badge" id="reqBadge" style="margin-left:8px;">Requests: 10</span>
        </div>
    </div>

    <!-- API Key & Upgrade -->
    <div class="card">
        <div class="flex">
            <div>
                <label style="color:#94a3b8;">🔑 API Key:</label>
                <input type="text" id="apiKeyInput" value="free_key_123" style="width:180px;">
                <button class="btn btn-secondary" id="applyKeyBtn">Apply</button>
            </div>
            <div>
                <button class="btn btn-success" id="upgradeBtn">⬆️ Upgrade to Pro</button>
                <button class="btn btn-secondary" id="enterpriseBtn">🏢 Enterprise</button>
            </div>
        </div>
        <div style="margin-top:8px; font-size:13px; color:#94a3b8;">
            💡 Use <strong>free_key_123</strong> (1,000 rows) · <strong>pro_key_789</strong> (100,000 rows) · <strong>enterprise_key_000</strong> (unlimited)
        </div>
    </div>

    <!-- Stats -->
    <div style="margin:16px 0;">
        <div class="stat"><div class="num" id="statTotal">0</div><div style="color:#94a3b8;">Rows</div></div>
        <div class="stat"><div class="num" style="color:#ef4444;" id="statAttacks">0</div><div style="color:#94a3b8;">Attacks</div></div>
        <div class="stat"><div class="num" style="color:#22c55e;" id="statNormal">0</div><div style="color:#94a3b8;">Normal</div></div>
    </div>

    <!-- Upload -->
    <div class="card">
        <h3>📤 Upload CSV</h3>
        <div class="upload-zone" id="uploadZone">
            <p><strong>Drop CSV here</strong> or click to browse</p>
            <p style="color:#94a3b8;">Max rows: <span id="maxRowsDisplay">1,000</span></p>
            <input type="file" id="fileInput" accept=".csv" style="display:none;">
            <div style="margin-top:10px;">
                <input type="text" id="targetCol" placeholder="Target column (optional)">
            </div>
        </div>
        <div id="uploadResult" style="margin-top:10px;"></div>
    </div>

    <!-- Predict -->
    <div class="card">
        <h3>⚡ Predict</h3>
        <div class="feature-grid" id="featureGrid"></div>
        <div class="flex mt-2">
            <button class="btn" id="predictBtn">Predict</button>
            <button class="btn btn-secondary" id="randomBtn">🎲 Random</button>
        </div>
        <div id="predictResult" style="margin-top:10px;"></div>
    </div>

    <!-- Log -->
    <div class="card">
        <h3>📋 Log</h3>
        <div class="log" id="logContainer"><div style="color:#94a3b8;">Ready.</div></div>
    </div>
</div>

<!-- Upgrade Modal -->
<div class="modal-overlay" id="upgradeModal">
    <div class="modal">
        <h2>⬆️ Upgrade Required</h2>
        <p style="color:#94a3b8;">Your plan (<span id="modalTier">Freemium</span>) allows only <span id="modalLimit">1,000</span> rows.</p>
        <div class="plan" onclick="upgradeTo('pro')">
            <div class="price">$999/mo</div>
            <div><strong>Professional</strong> · 100,000 rows · 1,000 req/day · CSV export</div>
        </div>
        <div class="plan" onclick="upgradeTo('enterprise')">
            <div class="price">Contact</div>
            <div><strong>Enterprise</strong> · Unlimited · Custom nodes · 24/7 support</div>
        </div>
        <div style="background:rgba(99,102,241,0.1); padding:8px; border-radius:8px; margin-top:12px;">
            <small>🔑 Use <code>demo_payment</code> for testing</small>
        </div>
        <button class="btn btn-secondary" style="margin-top:12px;" onclick="closeModal()">Close</button>
    </div>
</div>

<script>
// ============================================================
// Application Logic
// ============================================================
document.addEventListener('DOMContentLoaded', function() {

    console.log('✅ Page loaded');

    // State
    let apiKey = 'free_key_123';
    let tier = 'free';
    const limits = { free: 1000, pro: 100000, enterprise: Infinity };

    // DOM refs
    const uploadZone = document.getElementById('uploadZone');
    const fileInput = document.getElementById('fileInput');
    const targetCol = document.getElementById('targetCol');
    const uploadResult = document.getElementById('uploadResult');
    const featureGrid = document.getElementById('featureGrid');
    const predictBtn = document.getElementById('predictBtn');
    const randomBtn = document.getElementById('randomBtn');
    const predictResult = document.getElementById('predictResult');
    const logContainer = document.getElementById('logContainer');
    const tierBadge = document.getElementById('tierBadge');
    const reqBadge = document.getElementById('reqBadge');
    const maxRowsDisplay = document.getElementById('maxRowsDisplay');
    const apiKeyInput = document.getElementById('apiKeyInput');
    const applyKeyBtn = document.getElementById('applyKeyBtn');
    const upgradeBtn = document.getElementById('upgradeBtn');
    const enterpriseBtn = document.getElementById('enterpriseBtn');
    const upgradeModal = document.getElementById('upgradeModal');
    const modalTier = document.getElementById('modalTier');
    const modalLimit = document.getElementById('modalLimit');

    // Create feature grid (41 fields)
    for (let i = 0; i < 41; i++) {
        let inp = document.createElement('input');
        inp.type = 'number';
        inp.value = '0';
        inp.step = 'any';
        inp.id = 'f'+i;
        inp.placeholder = i;
        featureGrid.appendChild(inp);
    }

    // Update tier display
    function updateTier(t) {
        tier = t;
        const names = { free: 'Freemium', pro: 'Professional', enterprise: 'Enterprise' };
        const colors = { free: '', pro: 'pro', enterprise: 'enterprise' };
        tierBadge.textContent = '🔓 ' + names[t];
        tierBadge.className = 'badge ' + colors[t];
        maxRowsDisplay.textContent = limits[t] === Infinity ? '∞' : limits[t];
        const reqs = t === 'free' ? 10 : t === 'pro' ? 1000 : '∞';
        reqBadge.textContent = 'Requests: ' + reqs;
        console.log('✅ Tier updated to:', t);
    }

    // Toast
    function toast(msg, type='info') {
        let div = document.createElement('div');
        div.className = 'toast ' + type;
        div.textContent = msg;
        document.body.appendChild(div);
        setTimeout(() => { div.style.opacity = '0'; setTimeout(() => div.remove(), 300); }, 4000);
    }

    // Log
    function log(msg) {
        let placeholder = logContainer.querySelector('div[style*="color:#94a3b8;"]');
        if (placeholder) placeholder.remove();
        let div = document.createElement('div');
        let time = new Date().toLocaleTimeString();
        div.innerHTML = '<span style="color:#94a3b8;">['+time+']</span> '+msg;
        logContainer.prepend(div);
    }

    // Update stats
    function updateStats(data) {
        document.getElementById('statTotal').textContent = data.total_rows || 0;
        document.getElementById('statAttacks').textContent = data.attacks_detected || 0;
        document.getElementById('statNormal').textContent = data.normal_count || 0;
    }

    // Upload handler
    async function uploadFile(file) {
        if (!file) return;
        console.log('📤 Uploading file:', file.name);

        let reader = new FileReader();
        reader.onload = async function(e) {
            let lines = e.target.result.split('\\n').filter(l => l.trim() !== '');
            let rows = lines.length - 1;
            console.log('Rows:', rows);
            let limit = limits[tier];
            if (rows > limit && limit !== Infinity) {
                modalTier.textContent = TIER_NAMES[tier] || tier;
                modalLimit.textContent = limit;
                upgradeModal.classList.add('active');
                return;
            }

            let formData = new FormData();
            formData.append('file', file);
            let tc = targetCol.value.trim();
            if (tc) formData.append('target_column', tc);

            try {
                let resp = await fetch('/api/upload', {
                    method: 'POST',
                    headers: { 'x-api-key': apiKey },
                    body: formData
                });
                let data = await resp.json();
                if (!resp.ok) {
                    toast('❌ ' + (data.detail || 'Upload failed'), 'error');
                    return;
                }
                updateStats(data);
                log('✅ Uploaded '+file.name+': '+data.attacks_detected+' attacks, '+data.normal_count+' normal');
                toast('✅ File analyzed!', 'success');
                uploadResult.innerHTML = '<div style="background:rgba(34,197,94,0.1); padding:10px; border-radius:6px;">'+
                    '<strong>'+data.total_rows+'</strong> rows · <strong>'+data.attacks_detected+'</strong> attacks · <strong>'+data.normal_count+'</strong> normal'+
                    '</div>';
                if (data.remaining_requests !== undefined) {
                    reqBadge.textContent = 'Requests: '+data.remaining_requests;
                }
            } catch(err) {
                toast('❌ Connection error', 'error');
                console.error(err);
            }
        };
        reader.readAsText(file);
    }

    // === Drag & Drop ===
    uploadZone.addEventListener('dragover', (e) => { e.preventDefault(); uploadZone.classList.add('dragover'); });
    uploadZone.addEventListener('dragleave', () => { uploadZone.classList.remove('dragover'); });
    uploadZone.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadZone.classList.remove('dragover');
        if (e.dataTransfer.files.length) {
            uploadFile(e.dataTransfer.files[0]);
        }
    });
    uploadZone.addEventListener('click', () => { fileInput.click(); });
    fileInput.addEventListener('change', () => {
        if (fileInput.files.length) {
            uploadFile(fileInput.files[0]);
        }
    });

    // === API Key Change ===
    applyKeyBtn.addEventListener('click', function() {
        let newKey = apiKeyInput.value.trim();
        if (!newKey) { toast('❌ Please enter a key', 'error'); return; }
        // Validate key
        fetch('/health', { headers: { 'x-api-key': newKey } })
            .then(r => r.json())
            .then(data => {
                // Try to determine tier by checking limits
                if (newKey.includes('pro')) {
                    updateTier('pro');
                    apiKey = newKey;
                    toast('✅ Switched to Professional', 'success');
                } else if (newKey.includes('enterprise')) {
                    updateTier('enterprise');
                    apiKey = newKey;
                    toast('✅ Switched to Enterprise', 'success');
                } else {
                    updateTier('free');
                    apiKey = newKey;
                    toast('✅ Switched to Freemium', 'success');
                }
                log('🔑 API key changed to: ' + newKey.substring(0,8)+'...');
            })
            .catch(() => {
                toast('⚠️ Could not validate key, but applying anyway', 'info');
                if (newKey.includes('pro')) updateTier('pro');
                else if (newKey.includes('enterprise')) updateTier('enterprise');
                else updateTier('free');
                apiKey = newKey;
            });
    });
    // Enter key support
    apiKeyInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') applyKeyBtn.click(); });

    // === Upgrade Buttons ===
    upgradeBtn.addEventListener('click', function() {
        if (tier === 'pro') { toast('✅ Already on Pro!', 'success'); return; }
        upgradeTo('pro');
    });
    enterpriseBtn.addEventListener('click', function() {
        if (tier === 'enterprise') { toast('✅ Already on Enterprise!', 'success'); return; }
        upgradeTo('enterprise');
    });

    function upgradeTo(plan) {
        let planName = plan.charAt(0).toUpperCase() + plan.slice(1);
        let token = prompt('Enter payment token for ' + planName + ' (use "demo_payment"):');
        if (token === 'demo_payment') {
            // Generate a new key for the plan
            let suffix = Math.random().toString(36).substring(2,6);
            let newKey = plan + '_key_' + suffix;
            apiKey = newKey;
            updateTier(plan);
            apiKeyInput.value = newKey;
            toast('✅ Upgraded to ' + planName + '! New key: ' + newKey, 'success');
            log('⬆️ Upgraded to ' + planName + ' (key: ' + newKey + ')');
            closeModal();
        } else if (token !== null) {
            toast('❌ Invalid payment token. Use "demo_payment"', 'error');
        }
    }

    function closeModal() {
        upgradeModal.classList.remove('active');
    }
    upgradeModal.addEventListener('click', (e) => { if (e.target === upgradeModal) closeModal(); });

    // === Predict ===
    predictBtn.addEventListener('click', async function() {
        let feats = [];
        for (let i=0; i<41; i++) {
            let v = parseFloat(document.getElementById('f'+i).value);
            feats.push(isNaN(v) ? 0 : v);
        }
        try {
            let resp = await fetch('/api/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-api-key': apiKey
                },
                body: JSON.stringify({ features: feats })
            });
            let data = await resp.json();
            if (!resp.ok) {
                toast('❌ ' + (data.detail || 'Prediction failed'), 'error');
                return;
            }
            let cls = data.prediction === 'Attack' ? 'danger' : 'success';
            predictResult.innerHTML = '<div class="result-box '+cls+'"><strong>'+data.prediction+'</strong> · '+(data.probability*100).toFixed(2)+'%<br><span style="color:#94a3b8;">Threshold: '+data.threshold_used+'</span></div>';
            log('🔮 Prediction: '+data.prediction+' ('+(data.probability*100).toFixed(2)+'%)');
            if (data.remaining_requests !== undefined) {
                reqBadge.textContent = 'Requests: '+data.remaining_requests;
            }
        } catch(err) {
            toast('❌ Connection error', 'error');
            console.error(err);
        }
    });

    // === Random ===
    randomBtn.addEventListener('click', function() {
        for (let i=0; i<41; i++) {
            document.getElementById('f'+i).value = (Math.random()*10).toFixed(2);
        }
    });

    // === Init ===
    const TIER_NAMES = { free: 'Freemium', pro: 'Professional', enterprise: 'Enterprise' };
    updateTier('free');
    log('🚀 NeoAMONA ready');
    console.log('✅ All events registered');
});
</script>
</body>
</html>
"""

# ============================================================
# 3. Endpoints
# ============================================================

@app.get("/", response_class=HTMLResponse)
async def root():
    return HTML_PAGE

@app.get("/health")
async def health():
    return {"status": "ok", "model_loaded": model is not None}

@app.post("/api/predict")
async def predict(features: List[float], x_api_key: str = Header(...)):
    if model is None:
        raise HTTPException(503, "Model not loaded")
    tier = validate_key(x_api_key)
    X = np.array(features).reshape(1, -1)
    proba = model.predict_proba(X)[0]
    pred = int(proba >= model.best_threshold)
    return {
        "prediction": "Attack" if pred else "Normal",
        "probability": float(proba),
        "threshold_used": float(model.best_threshold),
        "tier": tier,
        "remaining_requests": 999
    }

@app.post("/api/upload")
async def upload_file(file: UploadFile = File(...), target_column: Optional[str] = None, x_api_key: str = Header(...)):
    if model is None:
        raise HTTPException(503, "Model not loaded")
    tier = validate_key(x_api_key)
    contents = await file.read()
    df = pd.read_csv(io.BytesIO(contents))
    if df.empty:
        raise HTTPException(400, "Empty file")
    limit = TIER_LIMITS[tier]["max_rows"]
    if df.shape[0] > limit:
        raise HTTPException(403, f"Row limit exceeded. Your tier allows {limit} rows.")
    X, y_true = clean_data(df, target_column)
    proba = model.predict_proba(X)
    y_pred = (proba >= model.best_threshold).astype(int)
    return {
        "status": "success",
        "tier": tier,
        "total_rows": X.shape[0],
        "attacks_detected": int(np.sum(y_pred)),
        "normal_count": int(len(y_pred) - np.sum(y_pred)),
        "remaining_requests": 999
    }

# ============================================================
# 4. Run
# ============================================================

if __name__ == "__main__":
    print("="*50)
    print("🚀 NeoAMONA Server (with Upgrade & API Key)")
    print("="*50)
    uvicorn.run("neoamona_server:app", host="0.0.0.0", port=8080, reload=False)