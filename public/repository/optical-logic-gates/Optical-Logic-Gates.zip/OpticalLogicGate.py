import meep as mp

# ------------------------
# 1. المجال
# ------------------------
cell = mp.Vector3(16, 10, 0)
resolution = 20

silicon = mp.Medium(index=3.4)

# ------------------------
# 2. الهندسة (Interference region)
# ------------------------
geometry = [
    # Input A (top waveguide)
    mp.Block(
        size=mp.Vector3(6, 1, mp.inf),
        center=mp.Vector3(-4, 2),
        material=silicon
    ),

    # Input B (bottom waveguide)
    mp.Block(
        size=mp.Vector3(6, 1, mp.inf),
        center=mp.Vector3(-4, -2),
        material=silicon
    ),

    # Coupling region (interference zone)
    mp.Block(
        size=mp.Vector3(4, 3, mp.inf),
        center=mp.Vector3(2, 0),
        material=silicon
    ),

    # Output waveguide
    mp.Block(
        size=mp.Vector3(6, 1, mp.inf),
        center=mp.Vector3(6, 0),
        material=silicon
    )
]

# ------------------------
# 3. المصادر (حالتين لتجربة المنطق)
# ------------------------

sources = [
    # Input A
    mp.Source(
        mp.ContinuousSource(frequency=1/1.55),
        component=mp.Ez,
        center=mp.Vector3(-6, 2),
        size=mp.Vector3(0, 1)
    ),

    # Input B
    mp.Source(
        mp.ContinuousSource(frequency=1/1.55),
        component=mp.Ez,
        center=mp.Vector3(-6, -2),
        size=mp.Vector3(0, 1)
    )
]

# ------------------------
# 4. الحدود
# ------------------------
pml_layers = [mp.PML(1.0)]

# ------------------------
# 5. تشغيل المحاكاة
# ------------------------
sim = mp.Simulation(
    cell_size=cell,
    geometry=geometry,
    sources=sources,
    boundary_layers=pml_layers,
    resolution=resolution
)

# ------------------------
# 6. قياس الخرج (Output logic)
# ------------------------
out_flux = sim.add_flux(
    1/1.55,
    0,
    1,
    mp.FluxRegion(center=mp.Vector3(8, 0), size=mp.Vector3(0, 2))
)

# ------------------------
# 7. تشغيل
# ------------------------
sim.run(until=200)

# ------------------------
# 8. قراءة الخرج
# ------------------------
output_power = mp.get_fluxes(out_flux)[0]

print("\n===== OPTICAL LOGIC OUTPUT =====")
print("Output Power:", output_power)
