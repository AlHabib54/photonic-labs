import matplotlib.pyplot as plt

# ==================================================
# VERIFIED LOGIC GATES
# ==================================================

def optical_not(x):
    return 1 if x == 0 else 0


def optical_and(a, b):
    return 1 if (a == 1 and b == 1) else 0


def optical_or(a, b):
    return 1 if (a == 1 or b == 1) else 0


def optical_xor(a, b):

    or_result = optical_or(a, b)
    and_result = optical_and(a, b)

    return optical_and(
        or_result,
        optical_not(and_result)
    )


# ==================================================
# VERIFIED FULL ADDER
# ==================================================

def optical_full_adder(a, b, cin):

    xor1 = optical_xor(a, b)

    sum_bit = optical_xor(
        xor1,
        cin
    )

    carry1 = optical_and(a, b)
    carry2 = optical_and(a, cin)
    carry3 = optical_and(b, cin)

    carry_out = optical_or(
        optical_or(carry1, carry2),
        carry3
    )

    return (
        sum_bit,
        carry_out
    )


# ==================================================
# VERIFIED 4-BIT ADDER
# ==================================================

def optical_4bit_adder(A, B):

    carry = 0
    sums = []

    for i in range(4):

        sum_bit, carry = optical_full_adder(
            A[i],
            B[i],
            carry
        )

        sums.append(sum_bit)

    return sums, carry


# ==================================================
# INPUTS
# ==================================================

# A = 1101 (13)
# B = 0110 (6)

A = [1, 0, 1, 1]   # LSB → MSB
B = [0, 1, 1, 0]

# ==================================================
# MODE SELECT
# ==================================================

# 00 = AND
# 01 = OR
# 10 = XOR
# 11 = ADD

MODE = "11"

# ==================================================
# ALU OPERATIONS
# ==================================================

result = []
carry_out = 0
operation_name = ""

if MODE == "00":

    operation_name = "AND"

    for i in range(4):

        result.append(
            optical_and(
                A[i],
                B[i]
            )
        )

elif MODE == "01":

    operation_name = "OR"

    for i in range(4):

        result.append(
            optical_or(
                A[i],
                B[i]
            )
        )

elif MODE == "10":

    operation_name = "XOR"

    for i in range(4):

        result.append(
            optical_xor(
                A[i],
                B[i]
            )
        )

elif MODE == "11":

    operation_name = "ADD"

    result, carry_out = optical_4bit_adder(
        A,
        B
    )

else:

    print("INVALID MODE")
    exit()

# ==================================================
# FORMAT OUTPUT
# ==================================================

binary_A = "".join(
    map(str, reversed(A))
)

binary_B = "".join(
    map(str, reversed(B))
)

binary_result = "".join(
    map(str, reversed(result))
)

if MODE == "11":

    binary_result = (
        str(carry_out)
        + binary_result
    )

decimal_A = int(binary_A, 2)
decimal_B = int(binary_B, 2)

if MODE == "00":
    expected = decimal_A & decimal_B

elif MODE == "01":
    expected = decimal_A | decimal_B

elif MODE == "10":
    expected = decimal_A ^ decimal_B

else:
    expected = decimal_A + decimal_B

result_decimal = int(
    binary_result,
    2
)

status = (
    "PASS"
    if result_decimal == expected
    else "FAIL"
)

# ==================================================
# REPORT
# ==================================================

print("")
print("====================================")
print("OPTICAL 4-BIT ALU V1 REPORT")
print("====================================")

print("")
print("MODE =", MODE)
print("OPERATION =", operation_name)

print("")
print("INPUT A =", binary_A)
print("INPUT B =", binary_B)

print("")
print("OUTPUT =", binary_result)

if MODE == "11":
    print("CARRY OUT =", carry_out)

print("")
print("DECIMAL A =", decimal_A)
print("DECIMAL B =", decimal_B)

print("EXPECTED =", expected)
print("RESULT =", result_decimal)

print("")
print("STATUS =", status)

# ==================================================
# VISUALIZATION
# ==================================================

plot_bits = list(
    map(int, binary_result)
)

labels = []

for i in range(
    len(plot_bits)
):

    labels.append(
        f"Bit{i}"
    )

plt.figure(figsize=(10, 5))

plt.bar(
    labels,
    plot_bits
)

plt.ylim(0, 1.1)

plt.ylabel(
    "Logic Output"
)

plt.title(
    f"Optical 4-Bit ALU V1 ({operation_name})"
)

plt.savefig(
    "optical_4bit_alu_v1.png",
    dpi=300
)

plt.close()

print("")
print(
    "Saved: optical_4bit_alu_v1.png"
)

# ==================================================
# SAVE REPORT
# ==================================================

with open(
    "optical_4bit_alu_v1_report.txt",
    "w"
) as f:

    f.write(
        "OPTICAL 4-BIT ALU V1 REPORT\n"
    )

    f.write(
        "============================\n\n"
    )

    f.write(
        f"MODE = {MODE}\n"
    )

    f.write(
        f"OPERATION = {operation_name}\n\n"
    )

    f.write(
        f"INPUT A = {binary_A}\n"
    )

    f.write(
        f"INPUT B = {binary_B}\n\n"
    )

    f.write(
        f"OUTPUT = {binary_result}\n"
    )

    if MODE == "11":

        f.write(
            f"CARRY OUT = {carry_out}\n"
        )

    f.write("\n")

    f.write(
        f"DECIMAL A = {decimal_A}\n"
    )

    f.write(
        f"DECIMAL B = {decimal_B}\n"
    )

    f.write(
        f"EXPECTED = {expected}\n"
    )

    f.write(
        f"RESULT = {result_decimal}\n\n"
    )

    f.write(
        f"STATUS = {status}\n"
    )

print(
    "Saved: optical_4bit_alu_v1_report.txt"
)
