# -*- coding: utf-8 -*-
"""
================================================================================
🔬 برنامج المقارنة الشامل: NeoAMONA vs RandomForest vs XGBoost vs LightGBM
================================================================================
📌 الميزات:
- معالجة ذكية للبيانات (تتكيف مع أي عدد من الأعمدة، وتحويل النصوص إلى أرقام).
- دعم تشغيل NeoAMONA (اختياري، يمكن تعطيله لتوفير الوقت).
- حساب مقاييس: Accuracy, Precision, Recall, F1-Score, ROC-AUC, وزمن التدريب.
- حفظ النتائج في ملف CSV ورسم بياني للمقارنة.
- واجهة سطر أوامر بسيطة لتحديد الملف والعمود الهدف.
================================================================================
"""

import os
import sys
import time
import argparse
import warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression

# محاولة استيراد XGBoost
try:
    from xgboost import XGBClassifier
    XGB_AVAILABLE = True
except ImportError:
    XGB_AVAILABLE = False
    print("⚠️  XGBoost not installed. Run: pip install xgboost")

# محاولة استيراد LightGBM
try:
    from lightgbm import LGBMClassifier
    LGBM_AVAILABLE = True
except ImportError:
    LGBM_AVAILABLE = False
    print("⚠️  LightGBM not installed. Run: pip install lightgbm")

# محاولة استيراد NeoAMONA (اختياري)
try:
    from neoamona_core import NeoAMONACore
    NEO_AVAILABLE = True
except ImportError:
    NEO_AVAILABLE = False
    print("⚠️  NeoAMONA not found. Skipping NeoAMONA benchmark.")

# ====================================================================
# 1. دوال تنظيف البيانات (مطابقة لـ NeoAMONA)
# ====================================================================

def clean_data(file_path: str, target_col: str = None):
    """
    تحميل وتنظيف ملف CSV:
    - يحاول قراءة الملف مع رأس.
    - إذا تعذر العثور على العمود الهدف، يحاول البحث بأحرف صغيرة.
    - إذا لم يجد، يعتبر الملف بدون رأس ويستخدم العمود الأخير كهدف.
    """
    print(f"📥 Loading file: {file_path}")
    df = pd.read_csv(file_path)
    print(f"   - Shape: {df.shape[0]} rows, {df.shape[1]} columns")

    # عرض أسماء الأعمدة للمساعدة
    print(f"   - Columns: {df.columns.tolist()[:10]} ... (first 10 shown)")

    # إذا لم يحدد المستخدم الهدف، نأخذ العمود الأخير
    if target_col is None:
        target_col = df.columns[-1]
        print(f"   - Using last column as target: '{target_col}'")

    # محاولة العثور على العمود الهدف (حساسية الحروف)
    if target_col not in df.columns:
        # محاولة تطابق الحروف الصغيرة
        lower_cols = {col.lower(): col for col in df.columns}
        if target_col.lower() in lower_cols:
            target_col = lower_cols[target_col.lower()]
            print(f"   - Found target column (case-insensitive): '{target_col}'")
        else:
            # إذا لم يجد، قد يكون الملف بدون رأس
            print(f"   - Column '{target_col}' not found. Assuming file has no header.")
            # إعادة قراءة الملف بدون رأس
            df = pd.read_csv(file_path, header=None)
            # العمود الأخير هو الهدف
            target_col = df.columns[-1]
            print(f"   - Using last column (index {target_col}) as target.")

    # الآن نفصل الميزات والهدف
    X_raw = df.drop(columns=[target_col])
    y_raw = df[target_col]

    # تحويل الهدف إلى ثنائي (0 = طبيعي، 1 = هجوم)
    try:
        y = np.array([0 if str(v).strip().upper() in ['BENIGN', 'NORMAL', '0'] else 1 for v in y_raw])
    except:
        y = np.array([0 if str(v).strip().lower() in ['normal', 'benign'] else 1 for v in y_raw])

    print(f"   - Class distribution: Normal={np.sum(y==0)}, Attack={np.sum(y==1)}")

    # تنظيف الأعمدة
    X_clean = []
    for col in X_raw.columns:
        # الأعمدة النصية
        if X_raw[col].dtype == 'object':
            le = LabelEncoder()
            col_filled = X_raw[col].fillna('missing').astype(str)
            X_clean.append(le.fit_transform(col_filled).astype(float))
        else:
            # الأعمدة الرقمية
            col_numeric = pd.to_numeric(X_raw[col], errors='coerce')
            mean_val = np.nanmean(col_numeric)
            if np.isnan(mean_val):
                mean_val = 0.0
            col_filled = np.nan_to_num(col_numeric, nan=mean_val)
            col_filled = np.clip(col_filled, -1e6, 1e6)
            X_clean.append(col_filled.astype(float))

    X = np.column_stack(X_clean)

    # تكييف إلى 41 ميزة (مطابقة لـ NeoAMONA)
    if X.shape[1] < 41:
        pad = 41 - X.shape[1]
        X = np.pad(X, ((0, 0), (0, pad)), 'constant')
        print(f"   - Padded features from {X.shape[1]-pad} to 41")
    elif X.shape[1] > 41:
        X = X[:, :41]
        print(f"   - Truncated features from {X.shape[1]+41} to 41")

    print(f"✅ Data ready: {X.shape[0]} samples, {X.shape[1]} features")
    return X, y

# ====================================================================
# 2. دوال التدريب والتقييم
# ====================================================================

def train_and_evaluate(model, X_train, X_test, y_train, y_test, name):
    """تدريب نموذج وحساب المقاييس."""
    print(f"   🧠 Training {name}...")
    start = time.time()
    try:
        model.fit(X_train, y_train)
        train_time = time.time() - start

        y_pred = model.predict(X_test)
        try:
            y_proba = model.predict_proba(X_test)[:, 1]
        except:
            y_proba = np.ones(len(y_test)) * 0.5

        return {
            'accuracy': accuracy_score(y_test, y_pred),
            'precision': precision_score(y_test, y_pred, zero_division=0),
            'recall': recall_score(y_test, y_pred, zero_division=0),
            'f1': f1_score(y_test, y_pred, zero_division=0),
            'roc_auc': roc_auc_score(y_test, y_proba),
            'time': train_time,
            'model': model
        }
    except Exception as e:
        print(f"   ❌ {name} failed: {str(e)}")
        return None

# ====================================================================
# 3. غلاف NeoAMONA
# ====================================================================

class NeoAMONAWrapper:
    def __init__(self):
        self.model = None
        self.best_threshold = 0.5

    def fit(self, X, y):
        self.model = NeoAMONACore()
        self.model.fit(X, y)
        self.best_threshold = self.model.best_threshold
        return self

    def predict(self, X):
        return self.model.predict(X, threshold=self.best_threshold)

    def predict_proba(self, X):
        proba = self.model.predict_proba(X)
        if proba.ndim == 1:
            return np.column_stack([1 - proba, proba])
        return proba

# ====================================================================
# 4. البرنامج الرئيسي
# ====================================================================

def main():
    parser = argparse.ArgumentParser(description='Benchmark NeoAMONA vs RandomForest, XGBoost, LightGBM')
    parser.add_argument('--file', type=str, required=True, help='Path to CSV file')
    parser.add_argument('--target', type=str, default=None, help='Target column name (default: last column)')
    parser.add_argument('--skip-neo', action='store_true', help='Skip NeoAMONA training (saves time)')
    parser.add_argument('--test-size', type=float, default=0.3, help='Test set ratio (default: 0.3)')
    args = parser.parse_args()

    if not os.path.exists(args.file):
        print(f"❌ File not found: {args.file}")
        sys.exit(1)

    print("\n" + "="*70)
    print("🚀 Starting Comprehensive Benchmark")
    print("="*70)

    # تحميل البيانات
    X, y = clean_data(args.file, args.target)

    # تقسيم البيانات
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, random_state=42, stratify=y
    )
    print(f"📊 Split: Train={X_train.shape[0]}, Test={X_test.shape[0]}")

    # تطبيع البيانات (ضروري لـ XGBoost، LightGBM، SVM)
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    results = {}
    results_neo = {}

    # ============================================================
    # 4a. RandomForest
    # ============================================================
    rf = RandomForestClassifier(
        n_estimators=150,
        max_depth=20,
        class_weight='balanced',
        random_state=42,
        n_jobs=-1
    )
    res = train_and_evaluate(rf, X_train_scaled, X_test_scaled, y_train, y_test, 'RandomForest')
    if res:
        results['RandomForest'] = res

    # ============================================================
    # 4b. XGBoost
    # ============================================================
    if XGB_AVAILABLE:
        xgb = XGBClassifier(
            n_estimators=150,
            learning_rate=0.05,
            max_depth=6,
            scale_pos_weight=(len(y_train) - sum(y_train)) / sum(y_train),
            use_label_encoder=False,
            eval_metric='logloss',
            random_state=42
        )
        res = train_and_evaluate(xgb, X_train_scaled, X_test_scaled, y_train, y_test, 'XGBoost')
        if res:
            results['XGBoost'] = res
    else:
        print("⚠️  Skipping XGBoost (not installed)")

    # ============================================================
    # 4c. LightGBM
    # ============================================================
    if LGBM_AVAILABLE:
        lgbm = LGBMClassifier(
            n_estimators=150,
            learning_rate=0.05,
            num_leaves=31,
            class_weight='balanced',
            random_state=42,
            verbosity=-1
        )
        res = train_and_evaluate(lgbm, X_train_scaled, X_test_scaled, y_train, y_test, 'LightGBM')
        if res:
            results['LightGBM'] = res
    else:
        print("⚠️  Skipping LightGBM (not installed)")

    # ============================================================
    # 4d. LogisticRegression (خط أساس بسيط)
    # ============================================================
    lr = LogisticRegression(
        max_iter=500,
        class_weight='balanced',
        random_state=42
    )
    res = train_and_evaluate(lr, X_train_scaled, X_test_scaled, y_train, y_test, 'LogisticRegression')
    if res:
        results['LogisticRegression'] = res

    # ============================================================
    # 4e. NeoAMONA (على البيانات الأصلية غير المعيارية)
    # ============================================================
    if NEO_AVAILABLE and not args.skip_neo:
        print("\n" + "-"*50)
        print("🚀 Training NeoAMONA (this may take a few minutes)...")
        print("-"*50)
        try:
            neo_wrapper = NeoAMONAWrapper()
            neo_wrapper.fit(X_train, y_train)
            y_pred_neo = neo_wrapper.predict(X_test)
            y_proba_neo = neo_wrapper.predict_proba(X_test)[:, 1]

            results['NeoAMONA'] = {
                'accuracy': accuracy_score(y_test, y_pred_neo),
                'precision': precision_score(y_test, y_pred_neo, zero_division=0),
                'recall': recall_score(y_test, y_pred_neo, zero_division=0),
                'f1': f1_score(y_test, y_pred_neo, zero_division=0),
                'roc_auc': roc_auc_score(y_test, y_proba_neo),
                'time': 0,
                'model': neo_wrapper.model
            }
            print("   ✅ NeoAMONA completed")
        except Exception as e:
            print(f"   ❌ NeoAMONA failed: {str(e)}")
    elif args.skip_neo:
        print("\n⚠️  Skipping NeoAMONA as requested (--skip-neo)")
    else:
        print("\n⚠️  NeoAMONA not available. Skipping.")

    # ============================================================
    # 5. عرض النتائج
    # ============================================================
    print("\n" + "="*70)
    print("📊 COMPARISON RESULTS")
    print("="*70)

    # إنشاء جدول النتائج
    df_results = pd.DataFrame({
        'Algorithm': list(results.keys()),
        'Accuracy': [r['accuracy'] for r in results.values()],
        'Precision': [r['precision'] for r in results.values()],
        'Recall': [r['recall'] for r in results.values()],
        'F1-Score': [r['f1'] for r in results.values()],
        'ROC-AUC': [r['roc_auc'] for r in results.values()],
        'Time (s)': [r['time'] for r in results.values()]
    })

    # ترتيب حسب F1-Score تنازلياً
    df_results = df_results.sort_values('F1-Score', ascending=False)
    df_results['Rank'] = range(1, len(df_results) + 1)

    print("\n📋 Final Ranking (by F1-Score):")
    print(df_results[['Rank', 'Algorithm', 'F1-Score', 'Accuracy', 'ROC-AUC', 'Time (s)']].to_string(index=False))

    # حفظ النتائج
    os.makedirs('benchmark_results', exist_ok=True)
    df_results.to_csv('benchmark_results/comparison_results.csv', index=False)
    print(f"\n📁 Results saved to: benchmark_results/comparison_results.csv")

    # ============================================================
    # 6. رسم المقارنة
    # ============================================================
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    # 6a. F1-Score
    colors = ['#6366f1' if a == 'NeoAMONA' else '#334155' for a in df_results['Algorithm']]
    axes[0].barh(df_results['Algorithm'], df_results['F1-Score'], color=colors)
    axes[0].set_xlabel('F1-Score')
    axes[0].set_title('F1-Score Comparison')
    if 'NeoAMONA' in df_results['Algorithm'].values:
        neo_f1 = df_results[df_results['Algorithm'] == 'NeoAMONA']['F1-Score'].values[0]
        axes[0].axvline(x=neo_f1, color='#22c55e', linestyle='--', linewidth=2, label='NeoAMONA')
        axes[0].legend()

    # 6b. Accuracy + ROC-AUC
    x = np.arange(len(df_results))
    width = 0.35
    axes[1].bar(x - width/2, df_results['Accuracy'], width, label='Accuracy', color='#818cf8')
    axes[1].bar(x + width/2, df_results['ROC-AUC'], width, label='ROC-AUC', color='#22c55e')
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(df_results['Algorithm'], rotation=45, ha='right')
    axes[1].set_title('Accuracy & ROC-AUC Comparison')
    axes[1].legend()

    plt.tight_layout()
    plt.savefig('benchmark_results/comparison_chart.png', dpi=150)
    print(f"📁 Chart saved to: benchmark_results/comparison_chart.png")
    plt.show()

    # ============================================================
    # 7. تحليل الأداء النسبي
    # ============================================================
    print("\n" + "="*70)
    print("📈 PERFORMANCE ANALYSIS")
    print("="*70)

    if 'NeoAMONA' in df_results['Algorithm'].values:
        neo_f1 = df_results[df_results['Algorithm'] == 'NeoAMONA']['F1-Score'].values[0]
        best_f1 = df_results.iloc[0]['F1-Score']
        best_algo = df_results.iloc[0]['Algorithm']
        print(f"🏆 Best Algorithm: {best_algo} (F1={best_f1:.4f})")
        print(f"🚀 NeoAMONA F1-Score: {neo_f1:.4f}")
        print(f"📈 NeoAMONA vs Best: {neo_f1/best_f1*100:.1f}% of the best")
    else:
        print(f"🏆 Best Algorithm: {df_results.iloc[0]['Algorithm']} (F1={df_results.iloc[0]['F1-Score']:.4f})")

    print("\n✅ Benchmark completed successfully!")
    print("="*70)

if __name__ == "__main__":
    main()