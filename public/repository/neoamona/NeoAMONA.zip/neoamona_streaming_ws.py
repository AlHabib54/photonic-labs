#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NeoAMONA Streaming - إرسال التنبيهات إلى الخادم عبر WebSocket
"""

import time
import pickle
import threading
import numpy as np
import json
import asyncio
import websockets
from collections import defaultdict
from scapy.all import sniff, IP, TCP, UDP, ICMP
import warnings
warnings.filterwarnings('ignore')

from neoamona_core import NeoAMONACore

# ============================================================
# 1. تحميل النموذج
# ============================================================
MODEL_PATH = "models/neoamona_core_model.pkl"

def load_model():
    try:
        model = NeoAMONACore.load(MODEL_PATH)
        print(f"✅ Model loaded from {MODEL_PATH}")
        return model
    except Exception as e:
        print(f"❌ Failed to load model: {e}")
        return None

model = load_model()
if model is None:
    exit(1)

# ============================================================
# 2. تخزين التدفقات
# ============================================================
flows = defaultdict(list)
FLOW_TIMEOUT = 30
flow_lock = threading.Lock()

# ============================================================
# 3. استخراج الميزات (مبسطة)
# ============================================================
def extract_features(packets):
    if not packets:
        return None
    total_bytes = sum(len(p) for p in packets)
    total_packets = len(packets)
    features = [total_bytes, total_packets] + [0] * 39
    return np.array(features[:41]).reshape(1, -1)

# ============================================================
# 4. إرسال التنبيه إلى الخادم عبر WebSocket
# ============================================================
async def send_alert_to_server(flow_key, prediction, proba):
    """إرسال التنبيه إلى خادم NeoAMONA عبر WebSocket"""
    uri = "ws://localhost:8080/ws"
    try:
        async with websockets.connect(uri) as websocket:
            message = {
                "flow": f"{flow_key[0]}:{flow_key[2]} → {flow_key[1]}:{flow_key[3]} ({flow_key[4]})",
                "prediction": "Attack" if prediction == 1 else "Normal",
                "probability": float(proba),
                "timestamp": time.time()
            }
            await websocket.send(json.dumps(message))
            print(f"📤 Sent alert: {message['prediction']} - {message['flow']}")
    except Exception as e:
        print(f"⚠️  Could not send alert to server: {e}")

# ============================================================
# 5. معالج الحزم
# ============================================================
def packet_handler(packet):
    if IP not in packet:
        return
    ip = packet[IP]
    src_ip = ip.src
    dst_ip = ip.dst
    proto = ip.proto
    src_port = dst_port = 0
    if TCP in packet:
        src_port = packet[TCP].sport
        dst_port = packet[TCP].dport
    elif UDP in packet:
        src_port = packet[UDP].sport
        dst_port = packet[UDP].dport
    flow_key = (src_ip, dst_ip, src_port, dst_port, proto)
    with flow_lock:
        flows[flow_key].append(packet)
        if len(flows[flow_key]) >= 20:
            predict_and_send(flow_key)

def predict_and_send(flow_key):
    with flow_lock:
        if flow_key not in flows or not flows[flow_key]:
            return
        packets = flows.pop(flow_key)
    features = extract_features(packets)
    if features is None:
        return
    try:
        proba = model.predict_proba(features)[0]
        pred = int(proba >= model.best_threshold)
        asyncio.run(send_alert_to_server(flow_key, pred, proba))
    except Exception as e:
        print(f"⚠️  Prediction error: {e}")

# ============================================================
# 6. مؤقت التنظيف
# ============================================================
def cleanup_flows():
    while True:
        time.sleep(FLOW_TIMEOUT)
        now = time.time()
        with flow_lock:
            for key, packets in list(flows.items()):
                if packets and now - max(p.time for p in packets) > FLOW_TIMEOUT:
                    predict_and_send(key)

# ============================================================
# 7. بدء البث
# ============================================================
def start_streaming(interface="lo"):
    print(f"🔍 Starting live capture on {interface}...")
    print(f"📡 Alerts will be sent to ws://localhost:8080/ws")
    cleanup_thread = threading.Thread(target=cleanup_flows, daemon=True)
    cleanup_thread.start()
    sniff(iface=interface, prn=packet_handler, store=False)

if __name__ == "__main__":
    import sys
    iface = sys.argv[1] if len(sys.argv) > 1 else "lo"
    start_streaming(iface)