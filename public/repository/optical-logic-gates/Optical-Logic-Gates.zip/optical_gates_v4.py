import meep as mp
import numpy as np
import csv

# ============================================================
# Optical Logic Gates v4 — FDTD Lookup Table
# ============================================================
# الاكتشاف من v1,v2,v3:
#   1. جهازنا يُفضّل Cross بشكل طبيعي (83% بدون إشارة)
#   2. منطق القراءة الصحيح: Bar>Cross → OUT=1
#   3. النموذج الرياضي غير دقيق → نستخدم FDTD مباشرة
#
# البيانات المتوفرة من قياسات سابقة:
#   (dn_u=0,    dn_l=0)    → Bar=16.8, Cross=83.2
#   (dn_u=0.016,dn_l=0)    → Bar=2.5,  Cross=97.5
#   (dn_u=0.032,dn_l=0)    → Bar=66.9, Cross=33.1
#   (dn_u=0.065,dn_l=0)    → Bar=46.5, Cross=53.5
#   (dn_u=0.081,dn_l=0)    → Bar=76.9, Cross=23.1
#   (dn_u=0.065,dn_l=0.065)→ Bar=83.7, Cross=16.3
#   (dn_u=0,    dn_l=0.065)→ Bar=90.7, Cross=9.3
#
# نحتاج قياس:
#   (dn_u=0,    dn_l=0.032) ← OR(0,1)
#   (dn_u=0.032,dn_l=0)     ← OR(1,0) — موجود أعلاه!
#   (dn_u=0.032,dn_l=0.032) ← OR(1,1)
# ============================================================

resolution = 20
lam        = 1.55
freq       = 1 / lam
n_si       = 3.4
wg_w       = 1.0
gap        = 1.70
c_len      = 6.0
arm_len    = 12.0
dn_pi      = lam / (2 * arm_len)   # 0.0646

# ── نقطة الـ Bias: φ=0.5π → Δn=0.032 يعطي Bar=66.9% ──
# هذه أفضل نقطة وسطى وجدناها من البيانات
dn_bias = dn_pi / 2   # 0.0323

def run_sim(dn_upper, dn_lower, label):
    y_up =  gap / 2
    y_dn = -gap / 2
    geo = [
        mp.Block(size=mp.Vector3(6,wg_w,mp.inf),
                 center=mp.Vector3(-21,y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(c_len,wg_w,mp.inf),
                 center=mp.Vector3(-14,y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(c_len,wg_w,mp.inf),
                 center=mp.Vector3(-14,y_dn),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(arm_len,wg_w,mp.inf),
                 center=mp.Vector3(0,y_up),
                 material=mp.Medium(index=n_si+dn_upper)),
        mp.Block(size=mp.Vector3(arm_len,wg_w,mp.inf),
                 center=mp.Vector3(0,y_dn),
                 material=mp.Medium(index=n_si+dn_lower)),
        mp.Block(size=mp.Vector3(c_len,wg_w,mp.inf),
                 center=mp.Vector3(14,y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(c_len,wg_w,mp.inf),
                 center=mp.Vector3(14,y_dn),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(6,wg_w,mp.inf),
                 center=mp.Vector3(21,y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(6,wg_w,mp.inf),
                 center=mp.Vector3(21,y_dn),
                 material=mp.Medium(index=n_si)),
    ]
    sim = mp.Simulation(
        cell_size=mp.Vector3(50,12,0),
        geometry=geo,
        boundary_layers=[mp.PML(1.5)],
        sources=[mp.Source(mp.ContinuousSource(frequency=freq),
                           component=mp.Ez,
                           center=mp.Vector3(-23,y_up))],
        resolution=resolution
    )
    bar_m   = sim.add_flux(freq,0,1,
        mp.FluxRegion(center=mp.Vector3(23,y_up),
                      size=mp.Vector3(0,2,0)))
    cross_m = sim.add_flux(freq,0,1,
        mp.FluxRegion(center=mp.Vector3(23,y_dn),
                      size=mp.Vector3(0,2,0)))
    sim.run(until=400)
    p_bar   = max(mp.get_fluxes(bar_m)[0],   0)
    p_cross = max(mp.get_fluxes(cross_m)[0], 0)
    total   = max(p_bar+p_cross, 1e-10)
    bar_pct   = p_bar/total*100
    cross_pct = p_cross/total*100
    # منطق القراءة: Bar > Cross → OUT=1
    out = 1 if bar_pct > cross_pct else 0
    print(f"  {label:28s} Bar={bar_pct:5.1f}% Cross={cross_pct:5.1f}% OUT={out}")
    return round(bar_pct,1), round(cross_pct,1), out

# ============================================================
# البيانات الموجودة مسبقاً (من قياسات FDTD السابقة)
# منطق: Bar > Cross → 1
# ============================================================
known = {
    # (dn_upper, dn_lower): (bar%, cross%, out)
    (0.0,    0.0   ): (16.8, 83.2, 0),   # Cross=83 → OUT=0
    (dn_pi,  0.0   ): (46.5, 53.5, 0),   # Cross=53 → OUT=0
    (0.0,    dn_pi ): (90.7,  9.3, 1),   # Bar=90   → OUT=1
    (dn_pi,  dn_pi ): (83.7, 16.3, 1),   # Bar=83   → OUT=1
    (dn_pi/2,0.0   ): (66.9, 33.1, 1),   # Bar=66   → OUT=1
    (0.0,    dn_pi/2): (None, None, None),# غير معروف → نقيسه
    (dn_pi/2,dn_pi/2): (None, None, None),# غير معروف → نقيسه
}

# ============================================================
# خطة البوابات بناءً على البيانات الحقيقية
# ============================================================
# AND: نريد OUT=1 فقط عند (1,1)
#   (0,0) → dn=0,0      → OUT=0 ✓ (موجود)
#   (0,1) → dn=0,dn_pi  → OUT=1 ✗ (يجب أن يكون 0)
# المشكلة: (0,1) يعطي Bar=90% → OUT=1
# الحل: لـ AND نستخدم dn_pi في UPPER فقط كـ"enable"
#   A=1 يُفعّل الذراع العلوية، B=1 يُفعّل السفلية
#   لكن النتيجة 1 فقط عند (upper+lower) → إزاحة كاملة

# ── الإستراتيجية المُعدَّلة ──
# نستخدم قراءة مزدوجة:
#   - Bar port  = OUT_BAR
#   - Cross port = OUT_CROSS = NOT(OUT_BAR)
# هذا يعطينا مجموعتين من البوابات بتصميم واحد

print("=" * 60)
print("OPTICAL LOGIC GATES v4 — FDTD Lookup + Dual Output")
print("=" * 60)
print(f"\ndn_pi = {dn_pi:.5f}")
print(f"منطق القراءة: Bar>Cross → BAR_OUT=1, Cross>Bar → CROSS_OUT=1\n")

# ── قياس الحالات الناقصة ──
print("[ قياس الحالات الناقصة ]")
missing = [
    (0.0,     dn_pi/2, "dn_u=0,    dn_l=π/2"),
    (dn_pi/2, dn_pi/2, "dn_u=π/2,  dn_l=π/2"),
    (dn_pi,   dn_pi/2, "dn_u=π,    dn_l=π/2"),
    (dn_pi/2, dn_pi,   "dn_u=π/2,  dn_l=π  "),
]
measured = {}
for dn_u, dn_l, lbl in missing:
    bar, cross, out = run_sim(dn_u, dn_l, lbl)
    measured[(dn_u, dn_l)] = (bar, cross, out)

# دمج البيانات
all_data = {k: v for k,v in known.items() if v[0] is not None}
all_data.update(measured)

def get(dn_u, dn_l):
    key = (round(dn_u,5), round(dn_l,5))
    for k,v in all_data.items():
        if abs(k[0]-dn_u)<0.001 and abs(k[1]-dn_l)<0.001:
            return v
    return (None, None, None)

def gate_result(bar, cross):
    if bar is None:
        return None, None
    bar_out   = 1 if bar > cross else 0
    cross_out = 1 - bar_out
    return bar_out, cross_out

# ── جداول الحقيقة الكاملة ──
# بناءً على dn: A=0→0, A=1→dn_pi
gates_def = {
    "AND_via_upper_A": [
        # A يتحكم في upper، B في lower
        # (A, B, dn_u,    dn_l,    exp_AND)
        (0, 0, 0,        0,        0),
        (0, 1, 0,        dn_pi,    0),
        (1, 0, dn_pi,    0,        0),
        (1, 1, dn_pi,    dn_pi,    1),
    ],
    "OR_via_halfpi": [
        (0, 0, 0,        0,        0),
        (0, 1, 0,        dn_pi/2,  1),
        (1, 0, dn_pi/2,  0,        1),
        (1, 1, dn_pi/2,  dn_pi/2,  1),
    ],
    "XOR_via_pi": [
        (0, 0, 0,        0,        0),
        (0, 1, 0,        dn_pi,    1),
        (1, 0, dn_pi,    0,        1),
        (1, 1, dn_pi,    dn_pi,    0),
    ],
}

results_all = []

for gname, table in gates_def.items():
    print(f"\n{'='*60}")
    print(f"  {gname}")
    print(f"{'='*60}")
    print(f"  {'A':>3} {'B':>3} {'Bar%':>7} {'Cross%':>8} "
          f"{'BAR_OUT':>8} {'CROSS_OUT':>10} {'Expected':>9} {'':>3}")

    correct_bar = correct_cross = 0
    for A, B, dn_u, dn_l, exp in table:
        bar, cross, _ = get(dn_u, dn_l)
        if bar is None:
            print(f"  {A:>3} {B:>3}  --- لم يُقَس بعد ---")
            continue
        bar_out, cross_out = gate_result(bar, cross)

        # هل أي من المنفذَين يُعطي النتيجة الصحيحة؟
        ok_bar   = (bar_out   == exp)
        ok_cross = (cross_out == exp)
        if ok_bar:   correct_bar   += 1
        if ok_cross: correct_cross += 1

        mark = "✓" if ok_bar else ("✓(X)" if ok_cross else "✗")
        print(f"  {A:>3} {B:>3} {bar:>7.1f} {cross:>8.1f} "
              f"{bar_out:>8} {cross_out:>10} {exp:>9} {mark:>3}")

        results_all.append([gname, A, B, bar, cross,
                            bar_out, cross_out, exp,
                            ok_bar, ok_cross])

    n = len(table)
    print(f"\n  Bar  port: {correct_bar}/{n} correct")
    print(f"  Cross port: {correct_cross}/{n} correct")
    best = max(correct_bar, correct_cross)
    print(f"  Best output: {best}/{n} "
          f"({'BAR' if correct_bar>=correct_cross else 'CROSS'})")

# ── حفظ ──
with open("optical_gates_v4_results.csv","w",newline="") as f:
    w = csv.writer(f)
    w.writerow(["Gate","A","B","Bar_%","Cross_%",
                "Bar_OUT","Cross_OUT","Expected",
                "Bar_Correct","Cross_Correct"])
    w.writerows(results_all)

# ── ملخص ──
print("\n" + "="*60)
print("FINAL SUMMARY")
print("="*60)
for gname in gates_def:
    rows = [r for r in results_all if r[0]==gname]
    bar_ok   = sum(r[8] for r in rows)
    cross_ok = sum(r[9] for r in rows)
    best = max(bar_ok, cross_ok)
    port = "Bar  " if bar_ok >= cross_ok else "Cross"
    bar_chart = "█"*best + "░"*(len(rows)-best)
    print(f"  {gname:25s}: {bar_chart} {best}/{len(rows)} via {port}")

total_bar   = sum(r[8] for r in results_all)
total_cross = sum(r[9] for r in results_all)
total_n     = len(results_all)
print(f"\n  Bar  port total : {total_bar}/{total_n}")
print(f"  Cross port total: {total_cross}/{total_n}")
print(f"  Best achievable : {max(total_bar,total_cross)}/{total_n}")
print("\n  Saved → optical_gates_v4_results.csv")
print("="*60)
