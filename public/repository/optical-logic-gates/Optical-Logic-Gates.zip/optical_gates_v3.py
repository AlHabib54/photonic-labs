import numpy as np
import csv
import time

# ============================================================
# Optical Logic Gates v3 — Hybrid Approach
# ============================================================
# المرحلة 1: Analytical CMT (ثوانٍ)
#   من نتائج FDTD السابقة استخرجنا:
#   - Transfer matrix للـ Directional Coupler
#   - العلاقة الدقيقة بين Δn والـ Cross%
#   نستخدمها لحساب كل البوابات فورياً
#
# المرحلة 2: FDTD تحقق للحالة الأصعب فقط (XOR 1,1)
# ============================================================

print("=" * 58)
print("OPTICAL LOGIC GATES v3 — Analytical + FDTD Verification")
print("=" * 58)

# ── معلمات مُعايَرة من نتائج FDTD السابقة ──
# من mzi_final_results.csv:
#   φ=0      → Cross=83.2%   (Δn=0)
#   φ=0.25π  → Cross=97.5%   (Δn=0.016)
#   φ=0.5π   → Cross=33.1%   (Δn=0.032)
#   φ=0.75π  → Cross=82.9%   (Δn=0.048)
#   φ=1.0π   → Cross=53.5%   (Δn=0.065)
#   φ=1.25π  → Cross=23.1%   (Δn=0.081)  ← أفضل Bar
#   φ=1.5π   → Cross=26.6%   (Δn=0.097)
#   φ=2.0π   → Cross=50.1%   (Δn=0.129)

lam     = 1.55
arm_len = 12.0
dn_pi   = lam / (2 * arm_len)   # 0.0646

# نقاط المعايرة المقاسة
dn_measured    = np.array([0, 0.016, 0.032, 0.048,
                            0.065, 0.081, 0.097, 0.129])
cross_measured = np.array([83.2, 97.5, 33.1, 82.9,
                            53.5, 23.1, 26.6, 50.1])

# ── دالة التنبؤ بالـ Cross% لأي Δn_total ──
def predict_cross(dn_upper, dn_lower):
    """
    يستخدم نموذج MZI التحليلي المُعايَر من بياناتنا الفعلية.
    التداخل يعتمد على فرق الطور بين الذراعَين:
      φ_diff = (2π/λ) × (Δn_upper - Δn_lower) × L
    """
    phi_diff = (2 * np.pi / lam) * (dn_upper - dn_lower) * arm_len

    # نموذج MZI مع coupler غير مثالي (من بياناتنا)
    # Cross = A + B×cos(φ_diff + φ_offset)
    # معاملات مُعايَرة بالـ least squares من قياساتنا:
    A      = 53.3    # متوسط
    B      = 37.8    # سعة التذبذب
    phi0   = 2.15    # إزاحة الطور الابتدائية (الـ bias الطبيعي)

    cross_pct = A + B * np.cos(phi_diff + phi0)
    cross_pct = np.clip(cross_pct, 0, 100)
    return cross_pct


# ── تحقق من دقة النموذج ──
print("\n[ Model Calibration Check ]")
print(f"  {'Δn':>8} {'FDTD%':>8} {'Model%':>8} {'Error':>8}")
for dn, real in zip(dn_measured, cross_measured):
    pred = predict_cross(dn, 0)
    print(f"  {dn:8.3f} {real:8.1f} {pred:8.1f} {abs(pred-real):8.1f}")


# ── معلمات البوابات ──
dn_bias = 1.25 * dn_pi    # 0.0808 → Bar state
THRESHOLD = 50.0           # Cross > 50% → OUT=1

def compute_gate_logic(dn_u_logic, dn_lower):
    dn_u_total = dn_bias + dn_u_logic
    cross = predict_cross(dn_u_total, dn_lower)
    bar   = 100 - cross
    out   = 1 if cross >= THRESHOLD else 0
    return round(bar, 1), round(cross, 1), out


# ── جداول الحقيقة ──
gate_tables = {
    "AND": [
        (0, 0,  0,         0,       0),
        (0, 1,  0,         dn_pi,   0),
        (1, 0,  dn_pi,     0,       0),
        (1, 1,  dn_pi,     dn_pi,   1),
    ],
    "OR": [
        (0, 0,  0,         0,        0),
        (0, 1,  0,         dn_pi/2,  1),
        (1, 0,  dn_pi/2,   0,        1),
        (1, 1,  dn_pi/2,   dn_pi/2,  1),
    ],
    "XOR": [
        (0, 0,  0,         0,       0),
        (0, 1,  0,         dn_pi,   1),
        (1, 0,  dn_pi,     0,       1),
        (1, 1,  dn_pi,     dn_pi,   0),
    ],
    "NOT": [
        (0, 0,  0,         0,       0),
        (1, 0,  dn_pi,     0,       1),
    ],
    "NAND": [
        (0, 0,  0,         0,       1),
        (0, 1,  0,         dn_pi,   1),
        (1, 0,  dn_pi,     0,       1),
        (1, 1,  dn_pi,     dn_pi,   0),
    ],
    "NOR": [
        (0, 0,  0,         0,        1),
        (0, 1,  0,         dn_pi/2,  0),
        (1, 0,  dn_pi/2,   0,        0),
        (1, 1,  dn_pi/2,   dn_pi/2,  0),
    ],
    "XNOR": [
        (0, 0,  0,         0,       1),
        (0, 1,  0,         dn_pi,   0),
        (1, 0,  dn_pi,     0,       0),
        (1, 1,  dn_pi,     dn_pi,   1),
    ],
}

# ── تشغيل كل البوابات ──
all_results = []
gate_scores = {}

print("\n[ Analytical Gate Computation ]")
t0 = time.time()

for gname, table in gate_tables.items():
    correct = 0
    print(f"\n  ── {gname} ──")
    print(f"  {'A':>3} {'B':>3} {'Bar%':>7} {'Cross%':>8} "
          f"{'OUT':>5} {'EXP':>5} {'':>3}")

    for A, B, dn_u_logic, dn_l, expected in table:
        bar, cross, got = compute_gate_logic(dn_u_logic, dn_l)
        ok = (got == expected)
        if ok:
            correct += 1
        mark = "✓" if ok else "✗"
        print(f"  {A:>3} {B:>3} {bar:>7.1f} {cross:>8.1f} "
              f"{got:>5} {expected:>5} {mark:>3}")
        all_results.append([gname, A, B, bar, cross, got, expected, ok])

    gate_scores[gname] = (correct, len(table))
    status = "PASS ✓" if correct == len(table) else f"PARTIAL {correct}/{len(table)}"
    print(f"  → {status}")

elapsed = time.time() - t0
print(f"\n  Analytical computation time: {elapsed:.2f} seconds")

# ── حفظ النتائج ──
with open("optical_gates_v3_analytical.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["Gate","A","B","Bar_%","Cross_%",
                "Got","Expected","Correct"])
    w.writerows(all_results)

# ── ملخص ──
print("\n" + "=" * 58)
print("ANALYTICAL SUMMARY")
print("=" * 58)
total_ok = sum(r[7] for r in all_results)
for gname, (ok, total) in gate_scores.items():
    bar_chart = "█" * ok + "░" * (total - ok)
    print(f"  {gname:6s}: {bar_chart}  {ok}/{total}")
print(f"\n  Total: {total_ok}/{len(all_results)} correct")
print(f"  Time : {elapsed:.2f} seconds")
print("  Saved → optical_gates_v3_analytical.csv")
print("=" * 58)

# ── المرحلة 2: FDTD تحقق لحالة واحدة فقط ──
print("\n" + "=" * 58)
print("PHASE 2 — FDTD Verification (XOR: A=1, B=1)")
print("Expected: Cross < 50% → OUT=0")
print("Estimated time: 15 minutes")
print("=" * 58)

try:
    import meep as mp

    y_up = 1.70 / 2
    y_dn = -1.70 / 2
    dn_u = dn_bias + dn_pi
    dn_l = dn_pi

    geo = [
        mp.Block(size=mp.Vector3(6,1,mp.inf),
                 center=mp.Vector3(-21,y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(6,1,mp.inf),
                 center=mp.Vector3(-21,y_dn),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(6,1,mp.inf),
                 center=mp.Vector3(-14,y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(6,1,mp.inf),
                 center=mp.Vector3(-14,y_dn),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(arm_len,1,mp.inf),
                 center=mp.Vector3(0,y_up),
                 material=mp.Medium(index=n_si+dn_u)),
        mp.Block(size=mp.Vector3(arm_len,1,mp.inf),
                 center=mp.Vector3(0,y_dn),
                 material=mp.Medium(index=n_si+dn_l)),
        mp.Block(size=mp.Vector3(6,1,mp.inf),
                 center=mp.Vector3(14,y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(6,1,mp.inf),
                 center=mp.Vector3(14,y_dn),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(6,1,mp.inf),
                 center=mp.Vector3(21,y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(6,1,mp.inf),
                 center=mp.Vector3(21,y_dn),
                 material=mp.Medium(index=n_si)),
    ]

    sim = mp.Simulation(
        cell_size=mp.Vector3(50,12,0),
        geometry=geo,
        boundary_layers=[mp.PML(1.5)],
        sources=[mp.Source(mp.ContinuousSource(frequency=freq),
                           component=mp.Ez,
                           center=mp.Vector3(-23,y_up))],
        resolution=20
    )

    bar_m   = sim.add_flux(freq,0,1,
        mp.FluxRegion(center=mp.Vector3(23,y_up),
                      size=mp.Vector3(0,2,0)))
    cross_m = sim.add_flux(freq,0,1,
        mp.FluxRegion(center=mp.Vector3(23,y_dn),
                      size=mp.Vector3(0,2,0)))

    sim.run(until=400)

    p_bar   = max(mp.get_fluxes(bar_m)[0],   0)
    p_cross = max(mp.get_fluxes(cross_m)[0], 0)
    total   = max(p_bar+p_cross, 1e-10)
    bar_pct   = p_bar/total*100
    cross_pct = p_cross/total*100
    fdtd_out  = 1 if cross_pct >= 50 else 0

    print(f"\n  FDTD Result: Bar={bar_pct:.1f}%  "
          f"Cross={cross_pct:.1f}%  OUT={fdtd_out}")
    pred = predict_cross(dn_u, dn_l)
    print(f"  Model pred : Cross={pred:.1f}%")
    print(f"  Error      : {abs(cross_pct-pred):.1f}%")
    print(f"  XOR(1,1)   : {'✓ CORRECT (=0)' if fdtd_out==0 else '✗ Got 1, expected 0'}")

    with open("xor_fdtd_verify.csv","w",newline="") as f:
        csv.writer(f).writerows([
            ["Gate","A","B","Bar_%","Cross_%","OUT","Expected","Model_pred"],
            ["XOR",1,1,round(bar_pct,1),round(cross_pct,1),
             fdtd_out,0,round(pred,1)]
        ])
    print("  Saved → xor_fdtd_verify.csv")

except Exception as e:
    print(f"  Meep error: {e}")

print("\n" + "=" * 58)
print("DONE")
print("=" * 58)
