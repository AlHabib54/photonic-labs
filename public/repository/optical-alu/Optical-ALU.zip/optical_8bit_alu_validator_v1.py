# ==========================================================
# optical_8bit_alu_validator_v1.py
# Verified Optical 8-Bit ALU Validator V1
# Stable + Defensive + Low Execution Risk
# Built only on verified modules
# ==========================================================

import matplotlib.pyplot as plt


# ==========================================================
# VERIFIED LOGIC GATES
# ==========================================================

def optical_and(a, b):
    return a & b


def optical_or(a, b):
    return a | b


def optical_xor(a, b):
    return a ^ b


# ==========================================================
# VERIFIED FULL ADDER
# ==========================================================

def optical_full_adder(a, b, cin):

    xor1 = optical_xor(a, b)

    sum_bit = optical_xor(
        xor1,
        cin
    )

    carry = optical_or(
        optical_and(a, b),
        optical_and(cin, xor1)
    )

    return sum_bit, carry


# ==========================================================
# VERIFIED 8-BIT ADDER
# ==========================================================

def optical_8bit_adder(a_bits, b_bits):

    if len(a_bits) != 8:
        raise ValueError(
            "A input must be 8 bits"
        )

    if len(b_bits) != 8:
        raise ValueError(
            "B input must be 8 bits"
        )

    result = [0] * 8

    carry = 0
    carry_history = []

    # LSB → MSB
    for i in range(7, -1, -1):

        result[i], carry = (
            optical_full_adder(
                a_bits[i],
                b_bits[i],
                carry
            )
        )

        carry_history.append(carry)

    return (
        result,
        carry,
        carry_history
    )


# ==========================================================
# VERIFIED 8-BIT ALU
# ==========================================================

def optical_8bit_alu(
    A,
    B,
    mode
):

    if mode == "00":

        operation = "AND"

        result = [

            optical_and(
                A[i],
                B[i]
            )

            for i in range(8)
        ]

        carry = 0

    elif mode == "01":

        operation = "OR"

        result = [

            optical_or(
                A[i],
                B[i]
            )

            for i in range(8)
        ]

        carry = 0

    elif mode == "10":

        operation = "XOR"

        result = [

            optical_xor(
                A[i],
                B[i]
            )

            for i in range(8)
        ]

        carry = 0

    elif mode == "11":

        operation = "ADD"

        (
            result,
            carry,
            _
        ) = optical_8bit_adder(
            A,
            B
        )

    else:

        raise ValueError(
            "Invalid ALU mode"
        )

    return (
        result,
        carry,
        operation
    )


# ==========================================================
# HELPERS
# ==========================================================

def bits_to_decimal(bits):

    return int(
        "".join(map(str, bits)),
        2
    )


def decimal_to_8bit(n):

    return list(
        map(
            int,
            format(n, "08b")
        )
    )


# ==========================================================
# TEST SUITES
# ==========================================================

logic_tests = [

    (204, 170),
    (255, 255),
    (0, 0),
    (85, 170),
    (240, 15),
    (60, 195)
]

add_tests = [

    (0, 0),
    (1, 1),
    (15, 1),
    (127, 1),
    (128, 128),
    (205, 102),
    (255, 1),
    (255, 255),
    (170, 85)
]

modes = {

    "00": "AND",
    "01": "OR",
    "10": "XOR",
    "11": "ADD"
}

# ==========================================================
# VALIDATION ENGINE
# ==========================================================

total_tests = 0
passed_tests = 0

mode_stats = {

    "AND": [0,0],
    "OR": [0,0],
    "XOR": [0,0],
    "ADD": [0,0]
}

print("=" * 60)
print(
    "OPTICAL 8-BIT ALU VALIDATOR V1"
)
print("=" * 60)

try:

    # ------------------------------------------------------
    # LOGIC MODES
    # ------------------------------------------------------

    for mode in ["00", "01", "10"]:

        operation = modes[mode]

        for a_dec, b_dec in logic_tests:

            total_tests += 1
            mode_stats[
                operation
            ][1] += 1

            A = decimal_to_8bit(
                a_dec
            )

            B = decimal_to_8bit(
                b_dec
            )

            (
                result,
                carry,
                _
            ) = optical_8bit_alu(
                A,
                B,
                mode
            )

            result_decimal = (
                bits_to_decimal(
                    result
                )
            )

            # Expected
            if mode == "00":

                expected = (
                    a_dec
                    & b_dec
                )

            elif mode == "01":

                expected = (
                    a_dec
                    | b_dec
                )

            else:

                expected = (
                    a_dec
                    ^ b_dec
                )

            if (
                result_decimal
                == expected
            ):

                passed_tests += 1

                mode_stats[
                    operation
                ][0] += 1

    # ------------------------------------------------------
    # ADD MODE
    # ------------------------------------------------------

    for a_dec, b_dec in add_tests:

        total_tests += 1
        mode_stats["ADD"][1] += 1

        A = decimal_to_8bit(
            a_dec
        )

        B = decimal_to_8bit(
            b_dec
        )

        (
            result,
            carry,
            _
        ) = optical_8bit_alu(
            A,
            B,
            "11"
        )

        result_decimal = (
            bits_to_decimal(
                result
            )
        )

        if carry == 1:

            result_decimal += 256

        expected = (
            a_dec
            + b_dec
        )

        if (
            result_decimal
            == expected
        ):

            passed_tests += 1

            mode_stats[
                "ADD"
            ][0] += 1

    # ======================================================
    # FINAL REPORT
    # ======================================================

    failed_tests = (
        total_tests
        - passed_tests
    )

    print("")
    print("=" * 60)
    print(
        "VALIDATION REPORT"
    )
    print("=" * 60)

    for mode in mode_stats:

        passed = (
            mode_stats[
                mode
            ][0]
        )

        total = (
            mode_stats[
                mode
            ][1]
        )

        print(
            f"{mode} "
            f"PASSED = "
            f"{passed}/{total}"
        )

    print("-" * 60)

    print(
        "TOTAL TESTS =",
        total_tests
    )

    print(
        "PASSED =",
        passed_tests
    )

    print(
        "FAILED =",
        failed_tests
    )

    status = (

        "VERIFIED"

        if failed_tests == 0

        else "FAILED"
    )

    print(
        "FINAL STATUS =",
        status
    )

    # ======================================================
    # VISUALIZATION
    # ======================================================

    labels = list(
        mode_stats.keys()
    )

    pass_ratio = [

        mode_stats[m][0]
        /
        mode_stats[m][1]

        for m in labels
    ]

    plt.figure(
        figsize=(10,5)
    )

    plt.bar(
        labels,
        pass_ratio
    )

    plt.ylim(0, 1.1)

    plt.ylabel(
        "Pass Ratio"
    )

    plt.title(
        "Optical 8-Bit ALU Validator V1"
    )

    plt.show()

except Exception as e:

    print("")
    print(
        "VALIDATION ERROR:"
    )

    print(str(e))
