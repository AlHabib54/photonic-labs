# -*- coding: utf-8 -*-
"""
NeoAMONA Enterprise Server - Commercial Edition v3.1
مع إصلاحات الاستيراد والواجهة
"""

import pickle
import numpy as np
import pandas as pd
import json
import time
import uuid
import os
import io
from typing import List, Optional, Dict, Any
from collections import Counter
import warnings
warnings.filterwarnings('ignore')

from fastapi import FastAPI, UploadFile, File, HTTPException, Header, Form
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

# استيراد قلب الخوارزمية
from neoamona_core import NeoAMONACore

# ============================================================
# 1. نظام الاشتراكات
# ============================================================

TIER_LIMITS = {
    "free": {
        "name": "Freemium",
        "max_rows_per_upload": 1000,
        "daily_api_requests": 10,
        "allow_threshold_tuning": False,
        "allow_download_report": False,
        "price": "$0 / month",
        "color": "free"
    },
    "basic": {
        "name": "Basic",
        "max_rows_per_upload": 10000,
        "daily_api_requests": 100,
        "allow_threshold_tuning": False,
        "allow_download_report": True,
        "price": "$299 / month",
        "color": "basic"
    },
    "pro": {
        "name": "Professional",
        "max_rows_per_upload": 100000,
        "daily_api_requests": 1000,
        "allow_threshold_tuning": True,
        "allow_download_report": True,
        "price": "$999 / month",
        "color": "pro"
    },
    "enterprise": {
        "name": "Enterprise",
        "max_rows_per_upload": float('inf'),
        "daily_api_requests": float('inf'),
        "allow_threshold_tuning": True,
        "allow_download_report": True,
        "price": "Contact Sales",
        "color": "enterprise"
    }
}

# قاعدة بيانات المفاتيح التجريبية
MOCK_API_KEYS = {
    "free_key_123": {"tier": "free", "expires": None},
    "basic_key_456": {"tier": "basic", "expires": None},
    "pro_key_789": {"tier": "pro", "expires": None},
    "enterprise_key_000": {"tier": "enterprise", "expires": None}
}

request_counter = {tier: 0 for tier in TIER_LIMITS.keys()}

# ============================================================
# 2. تهيئة الخادم
# ============================================================

app = FastAPI(
    title="NeoAMONA Enterprise API",
    description="AI-Powered Cybersecurity Detection Platform",
    version="4.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================
# 3. تحميل النموذج
# ============================================================

MODEL_PATH = "models/neoamona_core_model.pkl"
model: NeoAMONACore = None

@app.on_event("startup")
async def load_model():
    global model
    try:
        os.makedirs("models", exist_ok=True)
        if not os.path.exists(MODEL_PATH):
            print(f"⚠️  Model not found at {MODEL_PATH}. Please train it first.")
            return
        model = NeoAMONACore.load(MODEL_PATH)
        print(f"✅ Model loaded: {MODEL_PATH}")
        print(f"   - Active nodes: {model.active_nodes}")
        print(f"   - Threshold: {model.best_threshold:.3f}")
    except Exception as e:
        print(f"❌ Error loading model: {e}")

# ============================================================
# 4. دوال المساعدة
# ============================================================

def validate_tier(api_key: str) -> str:
    if api_key not in MOCK_API_KEYS:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return MOCK_API_KEYS[api_key]["tier"]

def get_limits(tier: str) -> dict:
    return TIER_LIMITS[tier]

def check_limits(tier: str, requested_rows: int = 0):
    limits = get_limits(tier)
    if request_counter[tier] >= limits["daily_api_requests"]:
        raise HTTPException(
            status_code=429,
            detail=f"Daily request limit exceeded ({limits['daily_api_requests']}) for tier {tier}"
        )
    if requested_rows > limits["max_rows_per_upload"]:
        raise HTTPException(
            status_code=403,
            detail=f"Row limit exceeded. Your tier allows {limits['max_rows_per_upload']} rows, but {requested_rows} were uploaded."
        )
    request_counter[tier] += 1
    return True

def clean_and_prepare_data(df: pd.DataFrame, target_column: Optional[str] = None):
    try:
        y = None
        if target_column and target_column in df.columns:
            y_raw = df[target_column].values
            if len(np.unique(y_raw)) == 2:
                y = np.array([0 if str(v).strip().upper() == 'BENIGN' or v == 0 else 1 for v in y_raw])
            else:
                most_common = Counter(y_raw).most_common(1)[0][0]
                y = np.array([0 if v == most_common else 1 for v in y_raw])
            X_raw = df.drop(columns=[target_column]).values
        else:
            X_raw = df.values

        X_cleaned = []
        for i in range(X_raw.shape[1]):
            col = X_raw[:, i]
            col_numeric = pd.to_numeric(col, errors='coerce')
            mean_val = np.nanmean(col_numeric)
            if np.isnan(mean_val):
                mean_val = 0.0
            col_filled = np.where(np.isnan(col_numeric), mean_val, col_numeric)
            X_cleaned.append(col_filled.astype(float))
        
        X_final = np.column_stack(X_cleaned)
        X_final = np.nan_to_num(X_final, nan=0.0, posinf=1e6, neginf=-1e6)
        return X_final, y
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Data cleaning error: {str(e)}")

# ============================================================
# 5. نقاط النهاية (Endpoints)
# ============================================================

# HTML الرئيسي (سيتم تقديمه كسلسلة مباشرة لتجنب مشاكل الملفات)
MAIN_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NeoAMONA Enterprise</title>
    <style>
        body { font-family: system-ui, -apple-system, sans-serif; background: #0f172a; color: #f1f5f9; margin: 0; padding: 2rem; display: flex; flex-direction: column; align-items: center; }
        .container { max-width: 1200px; width: 100%; }
        .card { background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.1); border-radius: 24px; padding: 2rem; margin-bottom: 1.5rem; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; }
        .logo { font-size: 1.8rem; font-weight: 700; background: linear-gradient(135deg, #818cf8, #6366f1); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .badge { background: rgba(99,102,241,0.2); padding: 0.3rem 1rem; border-radius: 50px; font-size: 0.8rem; color: #a78bfa; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
        .stat { background: rgba(255,255,255,0.03); padding: 1rem; border-radius: 16px; text-align: center; }
        .stat .number { font-size: 2rem; font-weight: 700; }
        .stat .label { font-size: 0.8rem; color: #94a3b8; }
        .upload-zone { border: 2px dashed rgba(255,255,255,0.2); border-radius: 20px; padding: 3rem 2rem; text-align: center; cursor: pointer; transition: all 0.3s; }
        .upload-zone:hover, .upload-zone.dragover { border-color: #6366f1; background: rgba(99,102,241,0.05); }
        .upload-zone .icon { font-size: 3rem; margin-bottom: 0.5rem; }
        input, select { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 0.75rem 1rem; color: #f1f5f9; width: 100%; margin-top: 0.5rem; }
        .btn { background: linear-gradient(135deg, #6366f1, #4f46e5); border: none; color: white; padding: 0.75rem 2rem; border-radius: 12px; font-weight: 600; cursor: pointer; transition: all 0.3s; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 8px 30px rgba(99,102,241,0.4); }
        .btn-secondary { background: transparent; border: 1px solid rgba(255,255,255,0.2); }
        .btn-secondary:hover { background: rgba(255,255,255,0.05); }
        .flex { display: flex; gap: 1rem; flex-wrap: wrap; align-items: center; }
        .mt-2 { margin-top: 1rem; }
        .text-muted { color: #94a3b8; font-size: 0.9rem; }
        .result { padding: 1rem; border-radius: 12px; margin-top: 1rem; }
        .result.success { background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); }
        .result.danger { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); }
        .feature-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(55px, 1fr)); gap: 4px; margin: 0.5rem 0; }
        .feature-grid input { width: 100%; padding: 0.3rem; text-align: center; font-size: 0.8rem; }
        .log { max-height: 200px; overflow-y: auto; background: rgba(0,0,0,0.2); padding: 1rem; border-radius: 12px; }
        .log div { padding: 0.2rem 0; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: 0.85rem; }
        .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); justify-content: center; align-items: center; z-index: 999; }
        .modal-overlay.active { display: flex; }
        .modal { background: #1e293b; border-radius: 24px; padding: 2rem; max-width: 600px; width: 90%; border: 1px solid rgba(255,255,255,0.1); }
        .modal h3 { margin-top: 0; }
        .pricing-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin: 1rem 0; }
        .plan { background: rgba(255,255,255,0.03); padding: 1rem; border-radius: 12px; text-align: center; border: 1px solid rgba(255,255,255,0.05); cursor: pointer; }
        .plan:hover { border-color: #6366f1; }
        .plan .price { font-size: 1.5rem; font-weight: 700; color: #818cf8; }
        .plan .name { font-weight: 600; }
        .plan ul { list-style: none; padding: 0; font-size: 0.8rem; color: #94a3b8; }
        .plan ul li { padding: 0.15rem 0; }
        .toast-container { position: fixed; bottom: 20px; right: 20px; z-index: 1000; }
        .toast { background: #1e293b; padding: 1rem 1.5rem; border-radius: 12px; border-left: 4px solid #6366f1; margin-bottom: 0.5rem; box-shadow: 0 10px 40px rgba(0,0,0,0.3); }
        .toast.error { border-left-color: #ef4444; }
        .toast.success { border-left-color: #22c55e; }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="logo">🛡️ NeoAMONA Enterprise</div>
        <div>
            <span class="badge" id="tierBadge">🔓 Freemium</span>
            <span class="badge" style="background:rgba(255,255,255,0.05); color:#94a3b8; margin-left:0.5rem;" id="requestsBadge">10 requests left</span>
        </div>
    </div>

    <!-- Stats -->
    <div class="stats">
        <div class="stat"><div class="number" id="statTotal">0</div><div class="label">Total Rows</div></div>
        <div class="stat"><div class="number" style="color:#ef4444;" id="statAttacks">0</div><div class="label">Attacks</div></div>
        <div class="stat"><div class="number" style="color:#22c55e;" id="statNormal">0</div><div class="label">Normal</div></div>
        <div class="stat"><div class="number" style="color:#f59e0b;" id="statRatio">0%</div><div class="label">Attack Ratio</div></div>
    </div>

    <div class="card">
        <h3><i class="fas fa-upload" style="color:#6366f1;"></i> Upload CSV File</h3>
        <div class="upload-zone" id="uploadZone">
            <div class="icon">📁</div>
            <p><strong>Drop your CSV file here</strong> or click to browse</p>
            <p class="text-muted">Supports up to <span id="maxRowsDisplay">1,000</span> rows on your current plan</p>
            <input type="file" id="fileInput" accept=".csv" style="display:none;">
            <div style="margin-top:0.5rem;">
                <input type="text" id="targetColumn" placeholder="Target column (optional)" style="width:auto; display:inline-block; max-width:250px;">
            </div>
        </div>
        <div id="uploadProgress" style="display:none; margin-top:1rem;">
            <div style="background:rgba(255,255,255,0.05); border-radius:50px; height:8px; overflow:hidden;">
                <div style="background:linear-gradient(90deg,#6366f1,#818cf8); height:100%; width:100%; border-radius:50px;"></div>
            </div>
            <p class="text-muted" style="text-align:center; margin-top:0.3rem;">Analyzing...</p>
        </div>
        <div id="uploadResults" class="mt-2"></div>
    </div>

    <div class="card">
        <h3><i class="fas fa-bolt" style="color:#f59e0b;"></i> Single Prediction</h3>
        <p class="text-muted">Enter 41 numeric features</p>
        <div class="feature-grid" id="featureGrid"></div>
        <div class="flex mt-2">
            <button class="btn" id="predictBtn"> Predict</button>
            <button class="btn btn-secondary" id="fillRandomBtn">🎲 Random</button>
        </div>
        <div id="predictResult" class="mt-2"></div>
    </div>

    <div class="card">
        <h3><i class="fas fa-history" style="color:#94a3b8;"></i> Activity Log</h3>
        <div class="log" id="logContainer"><div class="text-muted" style="text-align:center;">No activity yet.</div></div>
    </div>
</div>

<!-- Upgrade Modal -->
<div class="modal-overlay" id="upgradeModal">
    <div class="modal">
        <h3>⬆️ Upgrade Required</h3>
        <p class="text-muted">Your current plan (<span id="modalCurrentTier">Freemium</span>) allows only <span id="modalCurrentLimit">1,000</span> rows.</p>
        <div class="pricing-grid">
            <div class="plan" onclick="upgradeTo('basic')"><div class="name">Basic</div><div class="price">$299</div><ul><li>10,000 rows</li><li>100 req/day</li><li>Report export</li></ul><button class="btn btn-secondary" style="width:100%;">Select</button></div>
            <div class="plan" style="border-color:#6366f1;" onclick="upgradeTo('pro')"><div class="name">Professional</div><div class="price">$999</div><ul><li>100,000 rows</li><li>1,000 req/day</li><li>Threshold tuning</li><li>CSV export</li></ul><button class="btn" style="width:100%;">Select</button></div>
            <div class="plan" onclick="upgradeTo('enterprise')"><div class="name">Enterprise</div><div class="price">Contact</div><ul><li>Unlimited</li><li>Unlimited</li><li>Custom nodes</li><li>24/7 support</li></ul><button class="btn btn-secondary" style="width:100%;">Contact</button></div>
        </div>
        <div style="background:rgba(99,102,241,0.1); padding:0.75rem; border-radius:12px; margin:1rem 0;">
            <small class="text-muted">🔑 Use <code>demo_payment</code> as payment token for testing.</small>
        </div>
        <button class="btn btn-secondary" onclick="closeModal()">Close</button>
    </div>
</div>

<div class="toast-container" id="toastContainer"></div>

<script>
// ============================================================
// State
// ============================================================
const STATE = {
    apiKey: 'free_key_123',
    tier: 'free',
    tierLimits: {
        free: { maxRows: 1000, name: 'Freemium', color: 'free' },
        basic: { maxRows: 10000, name: 'Basic', color: 'basic' },
        pro: { maxRows: 100000, name: 'Professional', color: 'pro' },
        enterprise: { maxRows: Infinity, name: 'Enterprise', color: 'enterprise' }
    }
};

// ============================================================
// Elements
// ============================================================
const tierBadge = document.getElementById('tierBadge');
const requestsBadge = document.getElementById('requestsBadge');
const uploadZone = document.getElementById('uploadZone');
const fileInput = document.getElementById('fileInput');
const targetColInput = document.getElementById('targetColumn');
const uploadProgress = document.getElementById('uploadProgress');
const uploadResults = document.getElementById('uploadResults');
const featureGrid = document.getElementById('featureGrid');
const predictBtn = document.getElementById('predictBtn');
const fillRandomBtn = document.getElementById('fillRandomBtn');
const predictResult = document.getElementById('predictResult');
const logContainer = document.getElementById('logContainer');
const upgradeModal = document.getElementById('upgradeModal');
const modalCurrentTier = document.getElementById('modalCurrentTier');
const modalCurrentLimit = document.getElementById('modalCurrentLimit');

// ============================================================
// Initialize features grid (41 fields)
// ============================================================
function initFeatureGrid() {
    for (let i = 0; i < 41; i++) {
        const input = document.createElement('input');
        input.type = 'number';
        input.value = '0';
        input.step = 'any';
        input.id = `f${i}`;
        input.placeholder = i;
        featureGrid.appendChild(input);
    }
}
initFeatureGrid();

// ============================================================
// Update UI based on tier
// ============================================================
function updateTierDisplay(tier) {
    STATE.tier = tier;
    const info = STATE.tierLimits[tier] || STATE.tierLimits.free;
    tierBadge.textContent = `🔓 ${info.name}`;
    document.getElementById('maxRowsDisplay').textContent = info.maxRows === Infinity ? '∞' : info.maxRows.toLocaleString();
    // Update requests (simulate)
    const maxReqs = tier === 'free' ? 10 : tier === 'basic' ? 100 : tier === 'pro' ? 1000 : '∞';
    requestsBadge.textContent = `Requests: ${maxReqs}`;
}

// ============================================================
// Toast notifications
// ============================================================
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 300); }, 5000);
}

// ============================================================
// Logging
// ============================================================
function addLog(message) {
    const placeholder = logContainer.querySelector('.text-muted');
    if (placeholder) placeholder.remove();
    const entry = document.createElement('div');
    const time = new Date().toLocaleTimeString();
    entry.innerHTML = `<span style="color:#94a3b8;">[${time}]</span> ${message}`;
    logContainer.prepend(entry);
}

// ============================================================
// Update stats
// ============================================================
function updateStats(data) {
    document.getElementById('statTotal').textContent = data.total_rows || 0;
    document.getElementById('statAttacks').textContent = data.attacks_detected || 0;
    document.getElementById('statNormal').textContent = data.normal_count || 0;
    document.getElementById('statRatio').textContent = data.prediction_summary?.attack_ratio || '0%';
}

// ============================================================
// File Upload Handler
// ============================================================
async function handleFileUpload(file) {
    if (!file) return;
    const targetCol = targetColInput.value.trim() || undefined;

    // Quick row count check
    const reader = new FileReader();
    reader.onload = async function(e) {
        const content = e.target.result;
        const lines = content.split('\n').filter(line => line.trim().length > 0);
        const rowCount = Math.max(0, lines.length - 1);
        const tier = STATE.tier;
        const limit = STATE.tierLimits[tier].maxRows;
        if (rowCount > limit && limit !== Infinity) {
            modalCurrentTier.textContent = STATE.tierLimits[tier].name;
            modalCurrentLimit.textContent = limit.toLocaleString();
            upgradeModal.classList.add('active');
            return;
        }

        // Proceed with upload
        const formData = new FormData();
        formData.append('file', file);
        if (targetCol) formData.append('target_column', targetCol);

        uploadProgress.style.display = 'block';
        uploadResults.innerHTML = '';
        try {
            const resp = await fetch('/api/upload', {
                method: 'POST',
                headers: { 'x-api-key': STATE.apiKey },
                body: formData
            });
            const data = await resp.json();
            if (!resp.ok) {
                showToast('❌ ' + (data.detail || 'Upload failed'), 'error');
                uploadProgress.style.display = 'none';
                return;
            }
            updateStats(data);
            addLog(`✅ Uploaded ${file.name}: ${data.attacks_detected} attacks, ${data.normal_count} normal`);
            showToast('✅ File analyzed successfully!', 'success');
            uploadResults.innerHTML = `
                <div style="background:rgba(34,197,94,0.1); border:1px solid rgba(34,197,94,0.3); padding:1rem; border-radius:12px;">
                    <strong>${data.total_rows}</strong> rows · <strong>${data.attacks_detected}</strong> attacks · <strong>${data.normal_count}</strong> normal
                    ${data.download_url ? `<br><a href="${data.download_url}" target="_blank" style="color:#818cf8;">Download Report (CSV)</a>` : ''}
                </div>
            `;
            if (data.remaining_requests !== undefined) {
                requestsBadge.textContent = `Requests: ${data.remaining_requests}`;
            }
        } catch (err) {
            showToast('❌ Connection error: ' + err.message, 'error');
        }
        uploadProgress.style.display = 'none';
    };
    reader.readAsText(file);
}

// ============================================================
// Drag & Drop
// ============================================================
uploadZone.addEventListener('click', () => fileInput.click());
uploadZone.addEventListener('dragover', (e) => { e.preventDefault(); uploadZone.classList.add('dragover'); });
uploadZone.addEventListener('dragleave', () => uploadZone.classList.remove('dragover'));
uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.classList.remove('dragover');
    if (e.dataTransfer.files.length) {
        const file = e.dataTransfer.files[0];
        handleFileUpload(file);
    }
});
fileInput.addEventListener('change', (e) => {
    if (e.target.files.length) {
        handleFileUpload(e.target.files[0]);
    }
});

// ============================================================
// Predict
// ============================================================
predictBtn.addEventListener('click', async function() {
    const features = [];
    for (let i = 0; i < 41; i++) {
        const val = parseFloat(document.getElementById(`f${i}`).value);
        features.push(isNaN(val) ? 0 : val);
    }
    try {
        const resp = await fetch('/api/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': STATE.apiKey
            },
            body: JSON.stringify({ features })
        });
        const data = await resp.json();
        if (!resp.ok) {
            showToast('❌ ' + (data.detail || 'Prediction failed'), 'error');
            return;
        }
        const color = data.prediction === 'Attack' ? 'danger' : 'success';
        predictResult.innerHTML = `
            <div style="background:${data.prediction === 'Attack' ? 'rgba(239,68,68,0.1)' : 'rgba(34,197,94,0.1)'}; border:1px solid ${data.prediction === 'Attack' ? 'rgba(239,68,68,0.3)' : 'rgba(34,197,94,0.3)'}; padding:1rem; border-radius:12px;">
                <strong>${data.prediction}</strong> · Probability: ${(data.probability * 100).toFixed(2)}%
                <br><span style="font-size:0.8rem; color:#94a3b8;">Threshold: ${data.threshold_used}</span>
            </div>
        `;
        addLog(`🔮 Prediction: ${data.prediction} (${(data.probability * 100).toFixed(2)}%)`);
        if (data.remaining_requests !== undefined) {
            requestsBadge.textContent = `Requests: ${data.remaining_requests}`;
        }
    } catch (err) {
        showToast('❌ Connection error: ' + err.message, 'error');
    }
});

// ============================================================
// Random fill
// ============================================================
fillRandomBtn.addEventListener('click', function() {
    for (let i = 0; i < 41; i++) {
        document.getElementById(`f${i}`).value = (Math.random() * 10).toFixed(2);
    }
});

// ============================================================
// Upgrade functions
// ============================================================
function closeModal() {
    upgradeModal.classList.remove('active');
}
function upgradeTo(plan) {
    const planName = STATE.tierLimits[plan].name;
    if (confirm(`Upgrade to ${planName}?`)) {
        const token = prompt('Enter payment token (use "demo_payment" for testing):');
        if (token === 'demo_payment') {
            const suffix = Math.random().toString(36).substring(2, 6);
            const newKey = `${plan}_key_${suffix}`;
            STATE.apiKey = newKey;
            updateTierDisplay(plan);
            showToast(`✅ Upgraded to ${planName}! New key: ${newKey}`, 'success');
            closeModal();
            requestsBadge.textContent = 'Requests: ∞';
        } else {
            showToast('❌ Invalid payment token', 'error');
        }
    }
}
// close modal on outside click
upgradeModal.addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});

// ============================================================
// Init
// ============================================================
updateTierDisplay('free');
addLog('🚀 NeoAMONA Enterprise ready. Upload a CSV or try a prediction.');
showToast('🚀 Server ready! Use pro_key_789 for higher limits.', 'info');
</script>
</body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
async def root():
    return MAIN_HTML

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard():
    return MAIN_HTML  # نفس الصفحة

# ============================================================
# نقاط نهاية API (كما هي)
# ============================================================

@app.get("/health")
async def health():
    return {"status": "healthy", "model_loaded": model is not None}

@app.get("/api/pricing")
async def pricing():
    return {"tiers": TIER_LIMITS}

@app.post("/api/subscribe")
async def subscribe(plan: str = Form(...), payment_token: str = Form(...)):
    if plan not in TIER_LIMITS:
        raise HTTPException(status_code=400, detail="Invalid plan")
    if not payment_token.startswith("demo_"):
        raise HTTPException(status_code=402, detail="Payment failed. Use 'demo_payment' for testing.")
    new_key = f"{plan}_key_{uuid.uuid4().hex[:8]}"
    MOCK_API_KEYS[new_key] = {"tier": plan, "expires": None}
    return {
        "status": "success",
        "message": f"Upgraded to {TIER_LIMITS[plan]['name']}",
        "api_key": new_key,
        "tier": plan,
        "limits": TIER_LIMITS[plan]
    }

@app.post("/api/predict")
async def predict(
    features: List[float],
    threshold: Optional[float] = None,
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    tier = validate_tier(x_api_key)
    limits = get_limits(tier)
    check_limits(tier)
    if threshold is not None and not limits["allow_threshold_tuning"]:
        raise HTTPException(
            status_code=403,
            detail=f"Threshold tuning not allowed for tier {tier}"
        )
    if threshold is None:
        threshold = model.best_threshold
    features_np = np.array(features).reshape(1, -1)
    proba = model.predict_proba(features_np)[0]
    pred = int(proba >= threshold)
    return {
        "prediction": "Attack" if pred == 1 else "Normal",
        "probability": float(proba),
        "threshold_used": float(threshold),
        "tier": tier,
        "remaining_requests": int(limits["daily_api_requests"] - request_counter[tier])
    }

@app.post("/api/upload")
async def upload_file(
    file: UploadFile = File(...),
    target_column: Optional[str] = None,
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    tier = validate_tier(x_api_key)
    limits = get_limits(tier)
    contents = await file.read()
    df = pd.read_csv(io.BytesIO(contents))
    if df.empty:
        raise HTTPException(status_code=400, detail="File is empty")
    check_limits(tier, requested_rows=df.shape[0])
    X, y_true = clean_and_prepare_data(df, target_column)
    proba = model.predict_proba(X)
    y_pred = (proba >= model.best_threshold).astype(int)
    attacks = int(np.sum(y_pred))
    normal_count = len(y_pred) - attacks
    confusion = None
    if y_true is not None:
        from sklearn.metrics import confusion_matrix
        cm = confusion_matrix(y_true, y_pred)
        confusion = {
            "true_negatives": int(cm[0, 0]),
            "false_positives": int(cm[0, 1]),
            "false_negatives": int(cm[1, 0]),
            "true_positives": int(cm[1, 1])
        }
    summary = {
        "total": X.shape[0],
        "features_count": X.shape[1],
        "attacks_detected": attacks,
        "normal_count": normal_count,
        "attack_ratio": f"{attacks / X.shape[0] * 100:.2f}%"
    }
    if confusion:
        summary["confusion_matrix"] = confusion
    download_url = None
    if limits["allow_download_report"]:
        results_df = df.copy()
        results_df['prediction'] = ['Attack' if p == 1 else 'Normal' for p in y_pred]
        results_df['probability'] = proba
        output_path = f"predictions_{int(time.time())}.csv"
        results_df.to_csv(output_path, index=False)
        download_url = f"/download/{output_path}"
    return {
        "status": "success",
        "tier": tier,
        "total_rows": X.shape[0],
        "attacks_detected": attacks,
        "normal_count": normal_count,
        "prediction_summary": summary,
        "remaining_requests": int(limits["daily_api_requests"] - request_counter[tier]),
        "download_url": download_url
    }

@app.get("/download/{filename}")
async def download_file(filename: str, x_api_key: str = Header(...)):
    tier = validate_tier(x_api_key)
    limits = get_limits(tier)
    if not limits["allow_download_report"]:
        raise HTTPException(status_code=403, detail="Download not allowed for your tier")
    return FileResponse(filename, media_type="text/csv", filename=filename)

# ============================================================
# 6. تشغيل الخادم
# ============================================================

if __name__ == "__main__":
    print("="*70)
    print("🚀 NeoAMONA Enterprise Server - Commercial Edition v3.1")
    print("="*70)
    print("📌 Available Tiers:")
    for tier, info in TIER_LIMITS.items():
        print(f"   - {tier.upper()}: {info['name']} - {info['price']}")
    print("="*70)
    uvicorn.run(
        "neoamona_server:app",
        host="0.0.0.0",
        port=8080,
        reload=False
    )