# ==========================================================
# optical_4bit_alu_validator_v1.py
# Verified Optical 4-Bit ALU Validator V1
# Built only on verified modules
# Defensive + Stable + Low execution risk
# ==========================================================

import matplotlib.pyplot as plt


# ==========================================================
# VERIFIED LOGIC GATES
# ==========================================================

def optical_and(a, b):
    return a & b


def optical_or(a, b):
    return a | b


def optical_xor(a, b):
    return a ^ b


# ==========================================================
# VERIFIED FULL ADDER
# ==========================================================

def optical_full_adder(a, b, cin):
    xor1 = optical_xor(a, b)
    sum_bit = optical_xor(xor1, cin)

    and1 = optical_and(a, b)
    and2 = optical_and(cin, xor1)

    carry = optical_or(and1, and2)

    return sum_bit, carry


# ==========================================================
# VERIFIED 4-BIT ADDER
# ==========================================================

def optical_4bit_adder(a_bits, b_bits):

    if len(a_bits) != 4 or len(b_bits) != 4:
        raise ValueError("Input must be exactly 4 bits")

    carry = 0
    result = [0, 0, 0, 0]

    for i in range(3, -1, -1):
        result[i], carry = optical_full_adder(
            a_bits[i],
            b_bits[i],
            carry
        )

    return result, carry


# ==========================================================
# VERIFIED 4-BIT ALU
# MODES:
# 00 = AND
# 01 = OR
# 10 = XOR
# 11 = ADD
# ==========================================================

def optical_4bit_alu(a_bits, b_bits, mode):

    if len(a_bits) != 4 or len(b_bits) != 4:
        raise ValueError("Inputs must be 4 bits")

    if len(mode) != 2:
        raise ValueError("Mode must be 2 bits")

    # AND
    if mode == [0, 0]:
        result = [
            optical_and(a_bits[i], b_bits[i])
            for i in range(4)
        ]
        carry = 0

    # OR
    elif mode == [0, 1]:
        result = [
            optical_or(a_bits[i], b_bits[i])
            for i in range(4)
        ]
        carry = 0

    # XOR
    elif mode == [1, 0]:
        result = [
            optical_xor(a_bits[i], b_bits[i])
            for i in range(4)
        ]
        carry = 0

    # ADD
    elif mode == [1, 1]:
        result, carry = optical_4bit_adder(
            a_bits,
            b_bits
        )

    else:
        raise ValueError("Invalid ALU mode")

    return result, carry


# ==========================================================
# HELPERS
# ==========================================================

def bits_to_decimal(bits):
    return int("".join(map(str, bits)), 2)


def decimal_to_bits(value):
    return list(map(int, format(value, '04b')))


# ==========================================================
# TEST ENGINE
# ==========================================================

def run_validation():

    total_tests = 0
    passed_tests = 0

    mode_results = {
        "AND": [0, 0],
        "OR": [0, 0],
        "XOR": [0, 0],
        "ADD": [0, 0]
    }

    print("=" * 50)
    print("OPTICAL 4-BIT ALU VALIDATOR V1")
    print("=" * 50)

    try:

        # ==================================================
        # AND TESTS
        # ==================================================
        and_tests = [
            ([1,1,0,0], [1,0,1,0]),
            ([1,1,1,1], [1,1,1,1]),
            ([0,0,0,0], [1,1,1,1]),
            ([1,0,1,0], [0,1,0,1]),
            ([1,0,0,1], [1,1,0,0])
        ]

        for a, b in and_tests:

            total_tests += 1
            mode_results["AND"][1] += 1

            result, _ = optical_4bit_alu(
                a, b, [0,0]
            )

            expected = [
                a[i] & b[i]
                for i in range(4)
            ]

            if result == expected:
                passed_tests += 1
                mode_results["AND"][0] += 1

        # ==================================================
        # OR TESTS
        # ==================================================
        or_tests = and_tests

        for a, b in or_tests:

            total_tests += 1
            mode_results["OR"][1] += 1

            result, _ = optical_4bit_alu(
                a, b, [0,1]
            )

            expected = [
                a[i] | b[i]
                for i in range(4)
            ]

            if result == expected:
                passed_tests += 1
                mode_results["OR"][0] += 1

        # ==================================================
        # XOR TESTS
        # ==================================================
        xor_tests = and_tests

        for a, b in xor_tests:

            total_tests += 1
            mode_results["XOR"][1] += 1

            result, _ = optical_4bit_alu(
                a, b, [1,0]
            )

            expected = [
                a[i] ^ b[i]
                for i in range(4)
            ]

            if result == expected:
                passed_tests += 1
                mode_results["XOR"][0] += 1

        # ==================================================
        # ADD TESTS
        # ==================================================
        add_tests = [
            (0, 0),
            (1, 1),
            (3, 5),
            (7, 1),
            (9, 3),
            (10, 5),
            (13, 6),
            (15, 1),
            (15, 15)
        ]

        for a_dec, b_dec in add_tests:

            total_tests += 1
            mode_results["ADD"][1] += 1

            a_bits = decimal_to_bits(a_dec)
            b_bits = decimal_to_bits(b_dec)

            result, carry = optical_4bit_alu(
                a_bits,
                b_bits,
                [1,1]
            )

            result_decimal = bits_to_decimal(result)

            if carry == 1:
                result_decimal += 16

            expected = a_dec + b_dec

            if result_decimal == expected:
                passed_tests += 1
                mode_results["ADD"][0] += 1

        # ==================================================
        # FINAL REPORT
        # ==================================================
        print("\n" + "=" * 50)
        print("VALIDATION REPORT")
        print("=" * 50)

        failed_tests = total_tests - passed_tests

        for mode in mode_results:

            passed = mode_results[mode][0]
            total = mode_results[mode][1]

            print(f"{mode} PASSED = {passed}/{total}")

        print("-" * 50)
        print("TOTAL TESTS =", total_tests)
        print("PASSED =", passed_tests)
        print("FAILED =", failed_tests)

        status = (
            "VERIFIED"
            if failed_tests == 0
            else "FAILED"
        )

        print("FINAL STATUS =", status)

        # ==================================================
        # VISUALIZATION
        # ==================================================
        labels = list(mode_results.keys())

        scores = [
            mode_results[m][0] /
            mode_results[m][1]
            for m in labels
        ]

        plt.figure(figsize=(10, 5))
        plt.bar(labels, scores)

        plt.title(
            "Optical 4-Bit ALU Validator V1"
        )
        plt.ylabel("Pass Ratio")
        plt.ylim(0, 1.1)

        plt.show()

    except Exception as e:
        print("\nVALIDATION ERROR:")
        print(str(e))


# ==========================================================
# MAIN
# ==========================================================

if __name__ == "__main__":
    run_validation()
