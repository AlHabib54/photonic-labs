import meep as mp
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime

# =====================================================
# OPTICAL OR GATE V1
# Built on Photonic Logic Core V1
# =====================================================

print("")
print("====================================")
print("OPTICAL OR GATE V1")
print("Built on Photonic Logic Core V1")
print("====================================")

# =====================================================
# VERIFIED CONSTANTS
# =====================================================

resolution = 20

silicon = mp.Medium(index=3.4)

wavelength = 1.55
frequency = 1 / wavelength

wg_width = 1.0
spacing = 3.0

arm_length = 50
merge_length = 45
final_gap = 0.6

simulation_time = 400

# =====================================================
# VERIFIED DELTA L STATES
# =====================================================

DELTA_L_LOW = 45.0
DELTA_L_HIGH = 100.0

# =====================================================
# OR INPUT STATES
# =====================================================

logic_cases = {

    "00": (0, 0),
    "01": (0, 1),
    "10": (1, 0),
    "11": (1, 1)
}

results = {}

# =====================================================
# SAFE POLYGON BUILDER
# =====================================================

def build_waveguide(points, width):

    top = []
    bottom = []

    n = len(points)

    for i in range(n):

        x, y = points[i]

        if i == 0:

            dx = points[i + 1][0] - x
            dy = points[i + 1][1] - y

        elif i == n - 1:

            dx = x - points[i - 1][0]
            dy = y - points[i - 1][1]

        else:

            dx = (
                points[i + 1][0]
                - points[i - 1][0]
            )

            dy = (
                points[i + 1][1]
                - points[i - 1][1]
            )

        norm = np.sqrt(dx**2 + dy**2)

        if norm < 1e-12:
            continue

        nx = -dy / norm
        ny = dx / norm

        top.append(
            (
                x + nx * width / 2,
                y + ny * width / 2
            )
        )

        bottom.append(
            (
                x - nx * width / 2,
                y - ny * width / 2
            )
        )

    polygon = top + bottom[::-1]

    return [
        mp.Vector3(px, py)
        for px, py in polygon
    ]

# =====================================================
# RUN ALL CASES
# =====================================================

for case_name, (A, B) in logic_cases.items():

    print("")
    print("------------------------------------")
    print("CASE =", case_name)
    print("A =", A, "B =", B)
    print("------------------------------------")

    # =================================================
    # OR LOGIC PHASE ENGINEERING
    # =================================================

    if A == 0 and B == 0:

        delta_L = DELTA_L_LOW

    else:

        delta_L = DELTA_L_HIGH

    print("DELTA L =", delta_L)

    sx = 240
    sy = 24

    cell = mp.Vector3(
        sx,
        sy,
        0
    )

    geometry = []

    upper_points = []
    lower_points = []

    # =================================================
    # INPUT WAVEGUIDE
    # =================================================

    geometry.append(

        mp.Block(

            size=mp.Vector3(
                24,
                wg_width,
                mp.inf
            ),

            center=mp.Vector3(
                -102,
                0
            ),

            material=silicon
        )
    )

    # =================================================
    # SPLITTER
    # =================================================

    split_start = -90
    split_end = -60

    for x in np.linspace(
        split_start,
        split_end,
        120
    ):

        t = (
            x - split_start
        ) / (
            split_end - split_start
        )

        y = (

            spacing
            * 0.5
            * (
                1
                - np.cos(np.pi * t)
            )
        )

        upper_points.append(
            (x, y)
        )

        lower_points.append(
            (x, -y)
        )

    # =================================================
    # ARMS
    # =================================================

    arm_start = split_end

    upper_arm_end = (
        arm_start
        + arm_length
        + delta_L
    )

    lower_arm_end = (
        arm_start
        + arm_length
    )

    for x in np.linspace(
        arm_start,
        upper_arm_end,
        140
    ):

        upper_points.append(
            (
                x,
                spacing
            )
        )

    for x in np.linspace(
        arm_start,
        lower_arm_end,
        140
    ):

        lower_points.append(
            (
                x,
                -spacing
            )
        )

    merge_start = max(
        upper_arm_end,
        lower_arm_end
    )

    if upper_arm_end < merge_start:

        for x in np.linspace(
            upper_arm_end,
            merge_start,
            40
        ):

            upper_points.append(
                (
                    x,
                    spacing
                )
            )

    if lower_arm_end < merge_start:

        for x in np.linspace(
            lower_arm_end,
            merge_start,
            40
        ):

            lower_points.append(
                (
                    x,
                    -spacing
                )
            )

    # =================================================
    # COMBINER
    # =================================================

    merge_end = (
        merge_start
        + merge_length
    )

    for x in np.linspace(
        merge_start,
        merge_end,
        160
    ):

        t = (
            x - merge_start
        ) / (
            merge_end
            - merge_start
        )

        y = spacing - (

            (
                spacing
                - final_gap
            )

            * 0.5

            * (
                1
                - np.cos(np.pi * t)
            )
        )

        upper_points.append(
            (
                x,
                y
            )
        )

        lower_points.append(
            (
                x,
                -y
            )
        )

    # =================================================
    # OUTPUT
    # =================================================

    output_start = merge_end
    output_end = output_start + 20

    for x in np.linspace(
        output_start,
        output_end,
        60
    ):

        upper_points.append(
            (
                x,
                final_gap
            )
        )

        lower_points.append(
            (
                x,
                -final_gap
            )
        )

    geometry.append(

        mp.Prism(

            vertices=build_waveguide(
                upper_points,
                wg_width
            ),

            height=mp.inf,

            material=silicon
        )
    )

    geometry.append(

        mp.Prism(

            vertices=build_waveguide(
                lower_points,
                wg_width
            ),

            height=mp.inf,

            material=silicon
        )
    )

    # =================================================
    # SOURCE
    # =================================================

    sources = [

        mp.Source(

            src=mp.GaussianSource(
                frequency=frequency,
                fwidth=0.08
            ),

            component=mp.Ez,

            center=mp.Vector3(
                -105,
                0
            ),

            size=mp.Vector3(
                0,
                1.2
            )
        )
    ]

    sim = mp.Simulation(

        cell_size=cell,

        geometry=geometry,

        boundary_layers=[
            mp.PML(1.0)
        ],

        sources=sources,

        resolution=resolution,

        eps_averaging=False
    )

    output_flux = sim.add_flux(

        frequency,
        0,
        1,

        mp.FluxRegion(

            center=mp.Vector3(
                95,
                0
            ),

            size=mp.Vector3(
                0,
                4
            )
        )
    )

    sim.run(
        until=simulation_time
    )

    output_power = mp.get_fluxes(
        output_flux
    )[0]

    results[case_name] = output_power

    print(
        "OUTPUT POWER =",
        output_power
    )

# =====================================================
# AUTO THRESHOLD
# =====================================================

threshold = (
    results["00"]
    +
    min(
        results["01"],
        results["10"],
        results["11"]
    )
) / 2

# =====================================================
# LOGIC OUTPUT
# =====================================================

logic_outputs = {}

for case in logic_cases:

    logic_outputs[case] = (

        1 if results[case] > threshold
        else 0
    )

# =====================================================
# VERIFICATION
# =====================================================

verified = (

    logic_outputs["00"] == 0
    and logic_outputs["01"] == 1
    and logic_outputs["10"] == 1
    and logic_outputs["11"] == 1
)

status = (
    "PASS"
    if verified
    else "FAIL"
)

# =====================================================
# PLOT
# =====================================================

labels = [
    "00",
    "01",
    "10",
    "11"
]

values = [
    logic_outputs["00"],
    logic_outputs["01"],
    logic_outputs["10"],
    logic_outputs["11"]
]

plt.figure(figsize=(7,4))

plt.bar(
    labels,
    values
)

plt.ylabel(
    "Logic Output"
)

plt.title(
    "Optical OR Gate V1"
)

plt.savefig(
    "optical_or_gate_v1.png",
    dpi=250
)

plt.close()

# =====================================================
# REPORT TXT
# =====================================================

with open(
    "optical_or_gate_v1_report.txt",
    "w"
) as f:

    f.write(
        "OPTICAL OR GATE V1 REPORT\n"
    )

    f.write(
        "====================================\n"
    )

    f.write(
        f"DATE: {datetime.now()}\n\n"
    )

    for case in labels:

        f.write(
            f"{case} POWER = {results[case]}\n"
        )

        f.write(
            f"OR{case} = {logic_outputs[case]}\n\n"
        )

    f.write(
        f"THRESHOLD = {threshold}\n"
    )

    f.write(
        f"STATUS = {status}\n"
    )

# =====================================================
# FINAL REPORT
# =====================================================

print("")
print("====================================")
print("OPTICAL OR GATE V1 REPORT")
print("====================================")

for case in labels:

    print(
        case,
        "POWER =",
        results[case]
    )

    print(
        "OR" + case,
        "=",
        logic_outputs[case]
    )

print("")
print("THRESHOLD =", threshold)
print("STATUS =", status)

print("")
print("Saved Files:")
print("optical_or_gate_v1.png")
print("optical_or_gate_v1_report.txt")
print("====================================")
