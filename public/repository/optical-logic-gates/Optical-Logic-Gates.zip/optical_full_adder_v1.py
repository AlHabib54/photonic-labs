import matplotlib.pyplot as plt
from datetime import datetime

# =====================================================
# OPTICAL FULL ADDER V1
#
# VERIFIED COMPONENTS:
# XOR Gate V1
# AND Gate V1
# OR Gate V1
#
# SUM = A XOR B XOR Cin
#
# CARRY =
# (A AND B)
# OR
# (Cin AND (A XOR B))
# =====================================================

print("")
print("====================================")
print("OPTICAL FULL ADDER V1")
print("Built on Verified Gates")
print("====================================")

# =====================================================
# INPUT CASES
# =====================================================

logic_cases = {

    "000": (0,0,0),
    "001": (0,0,1),
    "010": (0,1,0),
    "011": (0,1,1),
    "100": (1,0,0),
    "101": (1,0,1),
    "110": (1,1,0),
    "111": (1,1,1)
}

sum_results = {}
carry_results = {}

# =====================================================
# VERIFIED LOGIC GATES
# =====================================================

def optical_or(a, b):

    if a == 0 and b == 0:
        return 0

    return 1


def optical_and(a, b):

    if a == 1 and b == 1:
        return 1

    return 0


def optical_not(x):

    return 1 - x


def optical_xor(a, b):

    or_output = optical_or(a, b)

    and_output = optical_and(a, b)

    not_and_output = optical_not(
        and_output
    )

    return (
        or_output
        * not_and_output
    )

# =====================================================
# RUN ALL STATES
# =====================================================

for case_name, (
    A,
    B,
    Cin
) in logic_cases.items():

    print("")
    print("------------------------------------")
    print("CASE =", case_name)
    print(
        "A =", A,
        "B =", B,
        "Cin =", Cin
    )
    print("------------------------------------")

    # =================================
    # SUM
    # =================================

    xor_ab = optical_xor(
        A,
        B
    )

    sum_output = optical_xor(
        xor_ab,
        Cin
    )

    # =================================
    # CARRY
    # =================================

    and_ab = optical_and(
        A,
        B
    )

    and_cin = optical_and(
        Cin,
        xor_ab
    )

    carry_output = optical_or(
        and_ab,
        and_cin
    )

    sum_results[
        case_name
    ] = sum_output

    carry_results[
        case_name
    ] = carry_output

    print(
        "SUM =",
        sum_output
    )

    print(
        "CARRY =",
        carry_output
    )

# =====================================================
# VERIFICATION
# =====================================================

expected_sum = {
    "000":0,
    "001":1,
    "010":1,
    "011":0,
    "100":1,
    "101":0,
    "110":0,
    "111":1
}

expected_carry = {
    "000":0,
    "001":0,
    "010":0,
    "011":1,
    "100":0,
    "101":1,
    "110":1,
    "111":1
}

sum_verified = all(
    sum_results[k]
    == expected_sum[k]
    for k in expected_sum
)

carry_verified = all(
    carry_results[k]
    == expected_carry[k]
    for k in expected_carry
)

verified = (
    sum_verified
    and carry_verified
)

status = (
    "PASS"
    if verified
    else "FAIL"
)

# =====================================================
# PLOTS
# =====================================================

labels = list(
    logic_cases.keys()
)

sum_values = [
    sum_results[k]
    for k in labels
]

carry_values = [
    carry_results[k]
    for k in labels
]

# SUM PLOT
plt.figure(
    figsize=(8,4)
)

plt.bar(
    labels,
    sum_values
)

plt.ylabel(
    "Logic Output"
)

plt.title(
    "Optical Full Adder V1 - SUM"
)

plt.savefig(
    "optical_full_adder_v1_sum.png",
    dpi=250
)

plt.close()

# CARRY PLOT
plt.figure(
    figsize=(8,4)
)

plt.bar(
    labels,
    carry_values
)

plt.ylabel(
    "Logic Output"
)

plt.title(
    "Optical Full Adder V1 - CARRY"
)

plt.savefig(
    "optical_full_adder_v1_carry.png",
    dpi=250
)

plt.close()

# =====================================================
# TXT REPORT
# =====================================================

with open(
    "optical_full_adder_v1_report.txt",
    "w"
) as f:

    f.write(
        "OPTICAL FULL ADDER V1 REPORT\n"
    )

    f.write(
        "====================================\n"
    )

    f.write(
        f"DATE: {datetime.now()}\n\n"
    )

    for case in labels:

        f.write(
            f"CASE {case}\n"
        )

        f.write(
            f"SUM = "
            f"{sum_results[case]}\n"
        )

        f.write(
            f"CARRY = "
            f"{carry_results[case]}\n\n"
        )

    f.write(
        f"STATUS = {status}\n"
    )

# =====================================================
# FINAL REPORT
# =====================================================

print("")
print("====================================")
print("OPTICAL FULL ADDER V1 REPORT")
print("====================================")

for case in labels:

    print(
        "CASE",
        case
    )

    print(
        "SUM =",
        sum_results[case]
    )

    print(
        "CARRY =",
        carry_results[case]
    )

    print("")

print(
    "STATUS =",
    status
)

print("")
print("Saved Files:")

print(
    "optical_full_adder_v1_sum.png"
)

print(
    "optical_full_adder_v1_carry.png"
)

print(
    "optical_full_adder_v1_report.txt"
)

print("====================================")
