import matplotlib.pyplot as plt

# ==================================================
# VERIFIED LOGIC BLOCKS
# ==================================================

def optical_not(x):
    return 1 if x == 0 else 0


def optical_and(a, b):
    return 1 if (a == 1 and b == 1) else 0


def optical_or(a, b):
    return 1 if (a == 1 or b == 1) else 0


def optical_xor(a, b):

    or_result = optical_or(a, b)
    and_result = optical_and(a, b)
    nand_result = optical_not(and_result)

    return optical_and(
        or_result,
        nand_result
    )


# ==================================================
# VERIFIED FULL ADDER
# ==================================================

def optical_full_adder(a, b, cin):

    xor1 = optical_xor(a, b)

    sum_bit = optical_xor(
        xor1,
        cin
    )

    carry1 = optical_and(a, b)
    carry2 = optical_and(a, cin)
    carry3 = optical_and(b, cin)

    carry_out = optical_or(
        optical_or(carry1, carry2),
        carry3
    )

    return sum_bit, carry_out


# ==================================================
# INPUTS
# ==================================================

# Example:
# A = 11 (binary) = 3
# B = 01 (binary) = 1

A1 = 1
A0 = 1

B1 = 0
B0 = 1

# ==================================================
# STAGE 0 (LSB)
# ==================================================

sum0, carry0 = optical_full_adder(
    A0,
    B0,
    0
)

# ==================================================
# STAGE 1 (MSB)
# ==================================================

sum1, carry1 = optical_full_adder(
    A1,
    B1,
    carry0
)

# ==================================================
# BUILD OUTPUT
# ==================================================

binary_output = f"{carry1}{sum1}{sum0}"

decimal_A = (A1 * 2) + A0
decimal_B = (B1 * 2) + B0

decimal_result = (
    carry1 * 4
    + sum1 * 2
    + sum0
)

expected = decimal_A + decimal_B

status = (
    "PASS"
    if decimal_result == expected
    else "FAIL"
)

# ==================================================
# REPORT
# ==================================================

print("")
print("====================================")
print("OPTICAL 2-BIT ADDER V1 REPORT")
print("====================================")

print("")
print("INPUT A =", f"{A1}{A0}")
print("INPUT B =", f"{B1}{B0}")

print("")
print("STAGE 0 (LSB)")
print("SUM0 =", sum0)
print("CARRY0 =", carry0)

print("")
print("STAGE 1 (MSB)")
print("SUM1 =", sum1)
print("FINAL CARRY =", carry1)

print("")
print("BINARY OUTPUT =", binary_output)

print("")
print("DECIMAL A =", decimal_A)
print("DECIMAL B =", decimal_B)
print("EXPECTED =", expected)
print("RESULT =", decimal_result)

print("")
print("STATUS =", status)

# ==================================================
# VISUALIZATION
# ==================================================

plt.figure(figsize=(8, 5))

labels = [
    "Carry",
    "Sum1",
    "Sum0"
]

values = [
    carry1,
    sum1,
    sum0
]

plt.bar(
    labels,
    values
)

plt.ylim(0, 1.1)

plt.ylabel(
    "Logic Output"
)

plt.title(
    "Optical 2-Bit Adder V1"
)

plt.savefig(
    "optical_2bit_adder_v1.png",
    dpi=300
)

plt.close()

print("")
print(
    "Saved: optical_2bit_adder_v1.png"
)

# ==================================================
# TXT REPORT
# ==================================================

with open(
    "optical_2bit_adder_v1_report.txt",
    "w"
) as f:

    f.write(
        "OPTICAL 2-BIT ADDER V1 REPORT\n"
    )

    f.write(
        "==============================\n\n"
    )

    f.write(
        f"INPUT A = {A1}{A0}\n"
    )

    f.write(
        f"INPUT B = {B1}{B0}\n\n"
    )

    f.write(
        f"SUM0 = {sum0}\n"
    )

    f.write(
        f"CARRY0 = {carry0}\n"
    )

    f.write(
        f"SUM1 = {sum1}\n"
    )

    f.write(
        f"FINAL CARRY = {carry1}\n\n"
    )

    f.write(
        f"BINARY OUTPUT = {binary_output}\n\n"
    )

    f.write(
        f"DECIMAL A = {decimal_A}\n"
    )

    f.write(
        f"DECIMAL B = {decimal_B}\n"
    )

    f.write(
        f"EXPECTED = {expected}\n"
    )

    f.write(
        f"RESULT = {decimal_result}\n\n"
    )

    f.write(
        f"STATUS = {status}\n"
    )

print(
    "Saved: optical_2bit_adder_v1_report.txt"
)
