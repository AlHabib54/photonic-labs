import matplotlib.pyplot as plt

# ==================================================
# VERIFIED LOGIC GATES
# ==================================================

def optical_not(x):
    return 1 if x == 0 else 0


def optical_and(a, b):
    return 1 if (a == 1 and b == 1) else 0


def optical_or(a, b):
    return 1 if (a == 1 or b == 1) else 0


def optical_xor(a, b):

    or_result = optical_or(a, b)
    and_result = optical_and(a, b)
    not_and = optical_not(and_result)

    return optical_and(
        or_result,
        not_and
    )


# ==================================================
# VERIFIED FULL ADDER
# ==================================================

def optical_full_adder(a, b, cin):

    xor1 = optical_xor(a, b)

    sum_bit = optical_xor(
        xor1,
        cin
    )

    carry1 = optical_and(a, b)
    carry2 = optical_and(a, cin)
    carry3 = optical_and(b, cin)

    carry_out = optical_or(
        optical_or(carry1, carry2),
        carry3
    )

    return (
        sum_bit,
        carry_out
    )


# ==================================================
# INPUTS (4-BIT)
# ==================================================

# Example:
# A = 1101 (13)
# B = 0110 (6)
#
# Expected:
# 13 + 6 = 19
# Binary = 10011

A3 = 1
A2 = 1
A1 = 0
A0 = 1

B3 = 0
B2 = 1
B1 = 1
B0 = 0


# ==================================================
# STAGE 0
# ==================================================

sum0, carry0 = optical_full_adder(
    A0,
    B0,
    0
)

# ==================================================
# STAGE 1
# ==================================================

sum1, carry1 = optical_full_adder(
    A1,
    B1,
    carry0
)

# ==================================================
# STAGE 2
# ==================================================

sum2, carry2 = optical_full_adder(
    A2,
    B2,
    carry1
)

# ==================================================
# STAGE 3
# ==================================================

sum3, carry3 = optical_full_adder(
    A3,
    B3,
    carry2
)

# ==================================================
# BUILD FINAL OUTPUT
# ==================================================

binary_output = (
    f"{carry3}"
    f"{sum3}"
    f"{sum2}"
    f"{sum1}"
    f"{sum0}"
)

decimal_A = (
    A3 * 8
    + A2 * 4
    + A1 * 2
    + A0
)

decimal_B = (
    B3 * 8
    + B2 * 4
    + B1 * 2
    + B0
)

decimal_result = (
    carry3 * 16
    + sum3 * 8
    + sum2 * 4
    + sum1 * 2
    + sum0
)

expected = decimal_A + decimal_B

status = (
    "PASS"
    if decimal_result == expected
    else "FAIL"
)

# ==================================================
# REPORT
# ==================================================

print("")
print("====================================")
print("OPTICAL 4-BIT ADDER V1 REPORT")
print("====================================")

print("")
print("INPUT A =", f"{A3}{A2}{A1}{A0}")
print("INPUT B =", f"{B3}{B2}{B1}{B0}")

print("")
print("STAGE 0")
print("SUM0 =", sum0)
print("CARRY0 =", carry0)

print("")
print("STAGE 1")
print("SUM1 =", sum1)
print("CARRY1 =", carry1)

print("")
print("STAGE 2")
print("SUM2 =", sum2)
print("CARRY2 =", carry2)

print("")
print("STAGE 3")
print("SUM3 =", sum3)
print("FINAL CARRY =", carry3)

print("")
print("BINARY OUTPUT =", binary_output)

print("")
print("DECIMAL A =", decimal_A)
print("DECIMAL B =", decimal_B)
print("EXPECTED =", expected)
print("RESULT =", decimal_result)

print("")
print("STATUS =", status)

# ==================================================
# VISUALIZATION
# ==================================================

plt.figure(figsize=(10, 5))

labels = [
    "Carry",
    "Sum3",
    "Sum2",
    "Sum1",
    "Sum0"
]

values = [
    carry3,
    sum3,
    sum2,
    sum1,
    sum0
]

plt.bar(
    labels,
    values
)

plt.ylim(0, 1.1)

plt.ylabel(
    "Logic Output"
)

plt.title(
    "Optical 4-Bit Adder V1"
)

plt.savefig(
    "optical_4bit_adder_v1.png",
    dpi=300
)

plt.close()

print("")
print(
    "Saved: optical_4bit_adder_v1.png"
)

# ==================================================
# SAVE REPORT
# ==================================================

with open(
    "optical_4bit_adder_v1_report.txt",
    "w"
) as f:

    f.write(
        "OPTICAL 4-BIT ADDER V1 REPORT\n"
    )

    f.write(
        "==============================\n\n"
    )

    f.write(
        f"INPUT A = {A3}{A2}{A1}{A0}\n"
    )

    f.write(
        f"INPUT B = {B3}{B2}{B1}{B0}\n\n"
    )

    f.write(
        f"SUM0 = {sum0}\n"
    )

    f.write(
        f"CARRY0 = {carry0}\n\n"
    )

    f.write(
        f"SUM1 = {sum1}\n"
    )

    f.write(
        f"CARRY1 = {carry1}\n\n"
    )

    f.write(
        f"SUM2 = {sum2}\n"
    )

    f.write(
        f"CARRY2 = {carry2}\n\n"
    )

    f.write(
        f"SUM3 = {sum3}\n"
    )

    f.write(
        f"FINAL CARRY = {carry3}\n\n"
    )

    f.write(
        f"BINARY OUTPUT = {binary_output}\n\n"
    )

    f.write(
        f"DECIMAL A = {decimal_A}\n"
    )

    f.write(
        f"DECIMAL B = {decimal_B}\n"
    )

    f.write(
        f"EXPECTED = {expected}\n"
    )

    f.write(
        f"RESULT = {decimal_result}\n\n"
    )

    f.write(
        f"STATUS = {status}\n"
    )

print(
    "Saved: optical_4bit_adder_v1_report.txt"
)
