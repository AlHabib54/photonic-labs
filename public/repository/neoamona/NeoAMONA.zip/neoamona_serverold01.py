# -*- coding: utf-8 -*-
import pickle
import numpy as np
import pandas as pd
import io
import time
import uuid
import os
from collections import Counter
from fastapi import FastAPI, UploadFile, File, HTTPException, Header, Form
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import warnings
warnings.filterwarnings('ignore')

# استيراد قلب الخوارزمية
try:
    from neoamona_core import NeoAMONACore
except ImportError:
    print("⚠️  neoamona_core.py غير موجود. تأكد من وجوده في نفس المجلد.")
    NeoAMONACore = None

# ============================================================
# 1. نظام الاشتراكات
# ============================================================

TIER_LIMITS = {
    "free": {
        "name": "Freemium",
        "max_rows_per_upload": 1000,
        "daily_api_requests": 10,
        "allow_threshold_tuning": False,
        "allow_download_report": False,
        "price": "$0 / month",
        "color": "free"
    },
    "basic": {
        "name": "Basic",
        "max_rows_per_upload": 10000,
        "daily_api_requests": 100,
        "allow_threshold_tuning": False,
        "allow_download_report": True,
        "price": "$299 / month",
        "color": "basic"
    },
    "pro": {
        "name": "Professional",
        "max_rows_per_upload": 100000,
        "daily_api_requests": 1000,
        "allow_threshold_tuning": True,
        "allow_download_report": True,
        "price": "$999 / month",
        "color": "pro"
    },
    "enterprise": {
        "name": "Enterprise",
        "max_rows_per_upload": float('inf'),
        "daily_api_requests": float('inf'),
        "allow_threshold_tuning": True,
        "allow_download_report": True,
        "price": "Contact Sales",
        "color": "enterprise"
    }
}

# قاعدة بيانات المفاتيح التجريبية
MOCK_API_KEYS = {
    "free_key_123": {"tier": "free", "expires": None},
    "basic_key_456": {"tier": "basic", "expires": None},
    "pro_key_789": {"tier": "pro", "expires": None},
    "enterprise_key_000": {"tier": "enterprise", "expires": None}
}

request_counter = {tier: 0 for tier in TIER_LIMITS.keys()}

# ============================================================
# 2. تهيئة الخادم
# ============================================================

app = FastAPI(
    title="NeoAMONA Enterprise",
    description="AI-Powered Cybersecurity Detection Platform",
    version="4.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================
# 3. تحميل النموذج
# ============================================================

MODEL_PATH = "neoamona_core_model.pkl"
model = None

@app.on_event("startup")
async def load_model():
    global model
    if NeoAMONACore is None:
        print("❌ NeoAMONACore غير متاح. تأكد من تثبيت neoamona_core.py")
        return
    try:
        if os.path.exists(MODEL_PATH):
            model = NeoAMONACore.load(MODEL_PATH)
            print(f"✅ تم تحميل النموذج: {MODEL_PATH}")
            print(f"   - العقد النشطة: {model.active_nodes}")
            print(f"   - الحد الأدنى للعتبة: {model.best_threshold:.3f}")
        else:
            print(f"⚠️  الملف {MODEL_PATH} غير موجود. قم بتدريب النموذج أولاً.")
    except Exception as e:
        print(f"❌ خطأ في تحميل النموذج: {e}")

# ============================================================
# 4. دوال المساعدة
# ============================================================

def validate_tier(api_key: str) -> str:
    if api_key not in MOCK_API_KEYS:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return MOCK_API_KEYS[api_key]["tier"]

def get_limits(tier: str) -> dict:
    return TIER_LIMITS[tier]

def check_limits(tier: str, requested_rows: int = 0):
    limits = get_limits(tier)
    if request_counter[tier] >= limits["daily_api_requests"]:
        raise HTTPException(
            status_code=429,
            detail=f"Daily request limit exceeded ({limits['daily_api_requests']})"
        )
    if requested_rows > limits["max_rows_per_upload"]:
        raise HTTPException(
            status_code=403,
            detail=f"Row limit exceeded. Your tier allows {limits['max_rows_per_upload']} rows, but {requested_rows} were uploaded."
        )
    request_counter[tier] += 1
    return True

def clean_and_prepare_data(df: pd.DataFrame, target_column: str = None):
    try:
        y = None
        if target_column and target_column in df.columns:
            y_raw = df[target_column].values
            if len(np.unique(y_raw)) == 2:
                y = np.array([0 if str(v).strip().upper() == 'BENIGN' or v == 0 else 1 for v in y_raw])
            else:
                most_common = Counter(y_raw).most_common(1)[0][0]
                y = np.array([0 if v == most_common else 1 for v in y_raw])
            X_raw = df.drop(columns=[target_column]).values
        else:
            X_raw = df.values

        X_cleaned = []
        for i in range(X_raw.shape[1]):
            col = X_raw[:, i]
            col_numeric = pd.to_numeric(col, errors='coerce')
            mean_val = np.nanmean(col_numeric)
            if np.isnan(mean_val):
                mean_val = 0.0
            col_filled = np.where(np.isnan(col_numeric), mean_val, col_numeric)
            X_cleaned.append(col_filled.astype(float))
        
        X_final = np.column_stack(X_cleaned)
        X_final = np.nan_to_num(X_final, nan=0.0, posinf=1e6, neginf=-1e6)
        return X_final, y
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Data cleaning error: {str(e)}")

# ============================================================
# 5. نقاط النهاية (Endpoints)
# ============================================================

@app.get("/", response_class=HTMLResponse)
async def root():
    """الصفحة الرئيسية (Landing + Dashboard)"""
    html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NeoAMONA Enterprise</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --primary-light: #818cf8;
            --bg-dark: #0f172a;
            --text-light: #f1f5f9;
            --text-muted: #94a3b8;
            --border-glass: rgba(255,255,255,0.08);
            --shadow-glow: 0 8px 40px rgba(99,102,241,0.15);
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-dark);
            color: var(--text-light);
            min-height: 100vh;
            overflow-x: hidden;
        }
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background: radial-gradient(ellipse at 20% 50%, rgba(99,102,241,0.12) 0%, transparent 60%),
                        radial-gradient(ellipse at 80% 50%, rgba(34,197,94,0.06) 0%, transparent 60%),
                        var(--bg-dark);
        }
        .glass-card {
            background: rgba(255,255,255,0.04);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid var(--border-glass);
            border-radius: 20px;
            padding: 1.8rem;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .glass-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-glow);
            border-color: var(--primary-light);
        }
        .navbar-glass {
            background: rgba(15,23,42,0.85);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-glass);
            padding: 0.8rem 0;
        }
        .navbar-glass .navbar-brand {
            font-weight: 700;
            font-size: 1.4rem;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .btn-gradient {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border: none;
            color: #fff;
            font-weight: 600;
            padding: 0.6rem 1.8rem;
            border-radius: 12px;
            transition: all 0.3s;
        }
        .btn-gradient:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(99,102,241,0.4);
            color: #fff;
        }
        .btn-outline-glass {
            background: transparent;
            border: 1px solid var(--border-glass);
            color: var(--text-light);
            padding: 0.6rem 1.8rem;
            border-radius: 12px;
            transition: all 0.3s;
        }
        .btn-outline-glass:hover {
            background: rgba(255,255,255,0.05);
            border-color: var(--primary-light);
            color: #fff;
        }
        .tier-badge {
            padding: 0.25rem 1.2rem;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.8rem;
        }
        .tier-free { background: rgba(100,116,139,0.25); color: #94a3b8; }
        .tier-basic { background: rgba(59,130,246,0.25); color: #60a5fa; }
        .tier-pro { background: rgba(139,92,246,0.25); color: #a78bfa; }
        .tier-enterprise { background: rgba(251,191,36,0.25); color: #fbbf24; }
        .upload-zone {
            border: 2px dashed rgba(255,255,255,0.15);
            border-radius: 16px;
            padding: 3rem 2rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.4s;
        }
        .upload-zone:hover { border-color: var(--primary); background: rgba(99,102,241,0.05); }
        .upload-zone.dragover { border-color: #22c55e; background: rgba(34,197,94,0.08); }
        .upload-zone .icon { font-size: 3.5rem; color: var(--primary-light); margin-bottom: 1rem; }
        .stat-card { background: rgba(255,255,255,0.04); border-radius: 16px; padding: 1.5rem; text-align: center; border: 1px solid var(--border-glass); }
        .stat-card .number { font-size: 2.2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-light), var(--primary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .stat-card .label { color: var(--text-muted); font-size: 0.85rem; margin-top: 0.2rem; }
        .feature-grid input {
            width: 52px;
            margin: 2px;
            padding: 4px;
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 6px;
            background: rgba(255,255,255,0.05);
            color: #fff;
            text-align: center;
            font-size: 0.8rem;
        }
        .feature-grid input:focus { border-color: var(--primary); outline: none; }
        .modal-glass .modal-content { background: var(--bg-dark); border: 1px solid var(--border-glass); border-radius: 24px; color: var(--text-light); }
        .modal-glass .modal-header { border-bottom: 1px solid var(--border-glass); }
        .modal-glass .modal-footer { border-top: 1px solid var(--border-glass); }
        .pricing-item { background: rgba(255,255,255,0.04); border: 1px solid var(--border-glass); border-radius: 16px; padding: 1.5rem; text-align: center; transition: all 0.3s; cursor: pointer; }
        .pricing-item:hover { border-color: var(--primary-light); transform: scale(1.02); }
        .pricing-item .price { font-size: 1.5rem; font-weight: 700; color: var(--primary-light); }
        .pricing-item .features { list-style: none; padding: 0; font-size: 0.85rem; color: var(--text-muted); }
        .pricing-item .features li { padding: 0.2rem 0; }
        .toast-container { position: fixed; bottom: 20px; right: 20px; z-index: 9999; }
        .toast { background: rgba(15,23,42,0.95); backdrop-filter: blur(10px); border: 1px solid var(--border-glass); border-radius: 12px; padding: 0.8rem 1.5rem; margin-bottom: 0.5rem; color: #fff; min-width: 250px; font-size: 0.9rem; }
        .toast.success { border-left: 4px solid #22c55e; }
        .toast.error { border-left: 4px solid #ef4444; }
        .toast.info { border-left: 4px solid #6366f1; }
        @keyframes fadeInUp { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0); } }
        .animate-on-load { animation: fadeInUp 0.7s ease forwards; }
        .delay-1 { animation-delay: 0.1s; }
        .delay-2 { animation-delay: 0.2s; }
        .delay-3 { animation-delay: 0.3s; }
        @media (max-width: 768px) { .glass-card { padding: 1.2rem; } .feature-grid input { width: 40px; } }
    </style>
</head>
<body>

<div class="animated-bg"></div>

<!-- ============================== -->
<!-- شريط التنقل -->
<!-- ============================== -->
<nav class="navbar navbar-glass fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="fas fa-shield-halved me-2"></i>NeoAMONA</a>
        <div class="d-flex align-items-center gap-3">
            <span id="tierBadge" class="tier-badge tier-free">🔓 Freemium</span>
            <span id="requestsBadge" class="badge bg-secondary">10 requests left</span>
            <span id="apiKeyDisplay" class="badge bg-dark" style="font-size:0.7rem;">free_key_123</span>
        </div>
    </div>
</nav>

<!-- ============================== -->
<!-- المحتوى الرئيسي -->
<!-- ============================== -->
<div class="container pt-5 mt-5">

    <!-- صف الإحصائيات -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3 animate-on-load">
            <div class="stat-card"><div class="number" id="statTotal">0</div><div class="label">Total Rows</div></div>
        </div>
        <div class="col-6 col-md-3 animate-on-load delay-1">
            <div class="stat-card"><div class="number text-danger" id="statAttacks">0</div><div class="label">Attacks</div></div>
        </div>
        <div class="col-6 col-md-3 animate-on-load delay-2">
            <div class="stat-card"><div class="number text-success" id="statNormal">0</div><div class="label">Normal</div></div>
        </div>
        <div class="col-6 col-md-3 animate-on-load delay-3">
            <div class="stat-card"><div class="number text-warning" id="statRatio">0%</div><div class="label">Attack Ratio</div></div>
        </div>
    </div>

    <!-- منطقة التحكم الرئيسية -->
    <div class="row g-4">

        <!-- رفع الملف -->
        <div class="col-lg-7">
            <div class="glass-card animate-on-load">
                <h5 class="mb-3"><i class="fas fa-upload me-2 text-primary"></i>Upload CSV File</h5>
                <div class="upload-zone" id="uploadZone">
                    <div class="icon"><i class="fas fa-cloud-upload-alt"></i></div>
                    <h6 class="mb-2">Drop your CSV file here or click to browse</h6>
                    <p class="text-muted small">Supports up to <span id="maxRowsDisplay">1,000</span> rows on your current plan</p>
                    <input type="file" id="fileInput" accept=".csv" style="display:none;">
                    <div class="mt-2">
                        <input type="text" id="targetColumn" class="form-control form-control-sm d-inline-block w-auto" placeholder="Target column (optional)" style="max-width:220px;">
                        <button class="btn btn-gradient btn-sm ms-2" id="uploadBtn"><i class="fas fa-arrow-up me-1"></i>Upload</button>
                    </div>
                </div>
                <div id="uploadProgress" style="display:none;" class="mt-3">
                    <div class="progress" style="height:8px; background:rgba(255,255,255,0.1); border-radius:50px;">
                        <div class="progress-bar" style="width:100%; background:linear-gradient(90deg,var(--primary),var(--primary-light)); border-radius:50px;">Analyzing...</div>
                    </div>
                </div>
                <div id="uploadResults" class="mt-3"></div>
            </div>
        </div>

        <!-- التنبؤ الفردي -->
        <div class="col-lg-5">
            <div class="glass-card animate-on-load delay-1">
                <h5 class="mb-3"><i class="fas fa-bolt me-2 text-warning"></i>Single Prediction</h5>
                <p class="text-muted small">Enter 41 numeric features</p>
                <div class="feature-grid" id="featureGrid"></div>
                <div class="d-flex gap-2 mt-3">
                    <button id="predictBtn" class="btn btn-gradient flex-grow-1"><i class="fas fa-play me-1"></i> Predict</button>
                    <button id="fillRandomBtn" class="btn btn-outline-glass" title="Random values"><i class="fas fa-dice"></i></button>
                </div>
                <div id="predictResult" class="mt-3"></div>
            </div>
        </div>
    </div>

    <!-- سجل النتائج -->
    <div class="row mt-4">
        <div class="col">
            <div class="glass-card animate-on-load delay-2">
                <h5 class="mb-3"><i class="fas fa-history me-2 text-muted"></i>Activity Log</h5>
                <div id="logContainer" style="max-height:250px; overflow-y:auto;">
                    <p class="text-muted text-center small">No activity yet. Upload a file or run a prediction.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================== -->
<!-- نافذة الترقية -->
<!-- ============================== -->
<div class="modal fade modal-glass" id="upgradeModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title"><i class="fas fa-crown text-warning me-2"></i>Upgrade Required</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <div class="alert alert-warning bg-transparent text-warning border-warning"><i class="fas fa-exclamation-triangle me-2"></i><strong>File too large!</strong> Your current plan (<span id="modalCurrentTier">Freemium</span>) allows only <span id="modalCurrentLimit">1,000</span> rows.</div>
                <p class="text-muted">Upgrade to unlock higher limits:</p>
                <div class="row g-3">
                    <div class="col-4"><div class="pricing-item" onclick="upgradeTo('basic')"><div class="plan-name">Basic</div><div class="price">$299</div><ul class="features"><li>10k rows</li><li>100 req/day</li></ul><button class="btn btn-outline-glass btn-sm mt-2">Select</button></div></div>
                    <div class="col-4"><div class="pricing-item" onclick="upgradeTo('pro')" style="border-color:var(--primary-light);"><div class="plan-name">Pro</div><div class="price">$999</div><ul class="features"><li>100k rows</li><li>1k req/day</li><li>Export</li></ul><button class="btn btn-gradient btn-sm mt-2">Select</button></div></div>
                    <div class="col-4"><div class="pricing-item" onclick="upgradeTo('enterprise')"><div class="plan-name">Enterprise</div><div class="price">Contact</div><ul class="features"><li>Unlimited</li><li>Unlimited</li></ul><button class="btn btn-outline-glass btn-sm mt-2">Contact</button></div></div>
                </div>
                <div class="mt-3 p-2 rounded text-center" style="background:rgba(99,102,241,0.1);"><small class="text-muted">Use <code>demo_payment</code> as payment token for testing.</small></div>
            </div>
            <div class="modal-footer"><button class="btn btn-outline-glass" data-bs-dismiss="modal">Close</button></div>
        </div>
    </div>
</div>

<!-- نافذة الإشعارات -->
<div class="toast-container" id="toastContainer"></div>

<!-- ============================== -->
<!-- Scripts -->
<!-- ============================== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ============================================================
// STATE
// ============================================================
let STATE = {
    apiKey: 'free_key_123',
    tier: 'free',
    tierLimits: {
        free: { maxRows: 1000, name: 'Freemium', color: 'free' },
        basic: { maxRows: 10000, name: 'Basic', color: 'basic' },
        pro: { maxRows: 100000, name: 'Professional', color: 'pro' },
        enterprise: { maxRows: Infinity, name: 'Enterprise', color: 'enterprise' }
    }
};

const API_BASE = '';

// ============================================================
// دوال مساعدة
// ============================================================
function showToast(msg, type='info') {
    const c = document.getElementById('toastContainer');
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.innerHTML = msg;
    c.appendChild(t);
    setTimeout(() => { t.style.opacity='0'; setTimeout(()=>t.remove(),300); }, 5000);
}

function addLog(msg) {
    const container = document.getElementById('logContainer');
    const placeholder = container.querySelector('.text-muted.text-center');
    if (placeholder) placeholder.remove();
    const entry = document.createElement('div');
    const time = new Date().toLocaleTimeString();
    entry.innerHTML = `<span class="text-muted">[${time}]</span> ${msg}`;
    entry.className = 'border-bottom border-secondary py-1 small';
    container.prepend(entry);
}

function updateTierUI(tier) {
    const limits = STATE.tierLimits[tier];
    if (!limits) return;
    STATE.tier = tier;
    const badge = document.getElementById('tierBadge');
    badge.className = `tier-badge tier-${limits.color}`;
    badge.textContent = `🔓 ${limits.name}`;
    document.getElementById('maxRowsDisplay').textContent = limits.maxRows === Infinity ? '∞' : limits.maxRows.toLocaleString();
    // تحديث الطلبات المتبقية (محاكاة)
    const reqMap = { free:10, basic:100, pro:1000, enterprise:'∞' };
    document.getElementById('requestsBadge').textContent = `Requests: ${reqMap[tier] || '?'}`;
}

function updateStats(data) {
    document.getElementById('statTotal').textContent = data.total_rows || 0;
    document.getElementById('statAttacks').textContent = data.attacks_detected || 0;
    document.getElementById('statNormal').textContent = data.normal_count || 0;
    document.getElementById('statRatio').textContent = data.prediction_summary?.attack_ratio || '0%';
}

function upgradeTo(plan) {
    const planName = STATE.tierLimits[plan]?.name || plan;
    if (confirm(`Upgrade to ${planName}?`)) {
        const token = prompt('Enter payment token (use "demo_payment" for testing):');
        if (token === 'demo_payment') {
            const suffix = Math.random().toString(36).substring(2,6);
            const newKey = `${plan}_key_${suffix}`;
            STATE.apiKey = newKey;
            document.getElementById('apiKeyDisplay').textContent = newKey;
            updateTierUI(plan);
            showToast(`✅ Upgraded to ${planName}! New key: ${newKey}`, 'success');
            const modal = bootstrap.Modal.getInstance(document.getElementById('upgradeModal'));
            if (modal) modal.hide();
        } else {
            showToast('❌ Invalid payment token', 'error');
        }
    }
}

// ============================================================
// إنشاء حقول الميزات (41)
// ============================================================
const grid = document.getElementById('featureGrid');
for (let i=0; i<41; i++) {
    const inp = document.createElement('input');
    inp.type = 'number';
    inp.value = '0';
    inp.step = 'any';
    inp.id = `f${i}`;
    inp.placeholder = i;
    grid.appendChild(inp);
}

// ============================================================
// رفع الملف (Drag & Drop + Click)
// ============================================================
const uploadZone = document.getElementById('uploadZone');
const fileInput = document.getElementById('fileInput');
const uploadBtn = document.getElementById('uploadBtn');

uploadZone.addEventListener('click', () => fileInput.click());
uploadZone.addEventListener('dragover', (e) => { e.preventDefault(); uploadZone.classList.add('dragover'); });
uploadZone.addEventListener('dragleave', () => uploadZone.classList.remove('dragover'));
uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.classList.remove('dragover');
    if (e.dataTransfer.files.length) {
        fileInput.files = e.dataTransfer.files;
        handleFileUpload();
    }
});
fileInput.addEventListener('change', handleFileUpload);
uploadBtn.addEventListener('click', handleFileUpload);

async function handleFileUpload() {
    const file = fileInput.files[0];
    if (!file) return;

    const targetColumn = document.getElementById('targetColumn').value.trim() || undefined;
    const formData = new FormData();
    formData.append('file', file);
    if (targetColumn) formData.append('target_column', targetColumn);

    // قراءة الملف للتحقق من عدد الصفوف
    const reader = new FileReader();
    reader.onload = async function(e) {
        const content = e.target.result;
        const lines = content.split('\n').filter(line => line.trim().length > 0);
        const rowCount = lines.length - 1;
        const tier = STATE.tier || 'free';
        const limits = STATE.tierLimits[tier];
        const maxRows = limits ? limits.maxRows : 1000;

        if (rowCount > maxRows && maxRows !== Infinity) {
            document.getElementById('modalCurrentTier').textContent = limits ? limits.name : 'Freemium';
            document.getElementById('modalCurrentLimit').textContent = maxRows === Infinity ? 'Unlimited' : maxRows.toLocaleString();
            const modal = new bootstrap.Modal(document.getElementById('upgradeModal'));
            modal.show();
            return;
        }

        document.getElementById('uploadProgress').style.display = 'block';
        document.getElementById('uploadResults').innerHTML = '';

        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                headers: { 'x-api-key': STATE.apiKey || 'free_key_123' },
                body: formData
            });
            const data = await response.json();
            if (!response.ok) {
                showToast(`❌ Error: ${data.detail || 'Upload failed'}`, 'error');
                document.getElementById('uploadProgress').style.display = 'none';
                return;
            }
            updateStats(data);
            addLog(`✅ Uploaded ${file.name}: ${data.attacks_detected} attacks, ${data.normal_count} normal`);
            showToast('✅ File analyzed successfully!', 'success');
            const resultsDiv = document.getElementById('uploadResults');
            resultsDiv.innerHTML = `<div class="alert alert-success border-success bg-transparent text-success"><strong>${data.total_rows}</strong> rows · <strong>${data.attacks_detected}</strong> attacks · <strong>${data.normal_count}</strong> normal${data.download_url ? `<br><a href="${data.download_url}" class="btn btn-sm btn-outline-primary mt-2" target="_blank"><i class="fas fa-download me-1"></i>Download Report</a>` : ''}</div>`;
            if (data.remaining_requests !== undefined) {
                document.getElementById('requestsBadge').textContent = `${data.remaining_requests} requests left`;
            }
        } catch (error) {
            showToast(`❌ Connection error: ${error.message}`, 'error');
        }
        document.getElementById('uploadProgress').style.display = 'none';
    };
    reader.readAsText(file);
}

// ============================================================
// التنبؤ الفردي
// ============================================================
document.getElementById('predictBtn').addEventListener('click', async function() {
    const features = [];
    for (let i=0; i<41; i++) {
        const val = parseFloat(document.getElementById(`f${i}`).value);
        features.push(isNaN(val) ? 0 : val);
    }
    try {
        const response = await fetch('/api/predict', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'x-api-key': STATE.apiKey || 'free_key_123' },
            body: JSON.stringify({ features })
        });
        const data = await response.json();
        if (!response.ok) {
            showToast(`❌ ${data.detail || 'Prediction failed'}`, 'error');
            return;
        }
        const resultDiv = document.getElementById('predictResult');
        const color = data.prediction === 'Attack' ? 'danger' : 'success';
        resultDiv.innerHTML = `<div class="alert alert-${color} mt-2"><strong>${data.prediction}</strong> · Probability: ${(data.probability*100).toFixed(2)}%<br><small class="text-muted">Threshold: ${data.threshold_used}</small></div>`;
        addLog(`🔮 Prediction: ${data.prediction} (${(data.probability*100).toFixed(2)}%)`);
        if (data.remaining_requests !== undefined) {
            document.getElementById('requestsBadge').textContent = `${data.remaining_requests} requests left`;
        }
    } catch (error) {
        showToast(`❌ Connection error: ${error.message}`, 'error');
    }
});

document.getElementById('fillRandomBtn').addEventListener('click', function() {
    for (let i=0; i<41; i++) {
        document.getElementById(`f${i}`).value = (Math.random() * 10).toFixed(2);
    }
});

// ============================================================
// تغيير المفتاح (API Key) يدوياً
// ============================================================
document.getElementById('apiKeyDisplay').addEventListener('dblclick', function() {
    const newKey = prompt('Enter new API Key:', STATE.apiKey);
    if (newKey) {
        STATE.apiKey = newKey;
        this.textContent = newKey;
        showToast(`🔑 API Key updated to: ${newKey}`, 'info');
    }
});

// ============================================================
// التهيئة الأولية
// ============================================================
updateTierUI('free');
addLog('🚀 NeoAMONA Enterprise loaded. Upload a CSV or run a prediction.');
showToast('🚀 Ready! Use free_key_123 or upgrade to pro_key_789 for more features.', 'info');

// تصدير دوال الترقية للنطاق العام
window.upgradeTo = upgradeTo;
</script>
</body>
</html>
    """
    return HTMLResponse(content=html_content)

@app.get("/health")
async def health():
    return {"status": "healthy", "model_loaded": model is not None}

@app.get("/api/pricing")
async def pricing():
    return {"tiers": TIER_LIMITS}

@app.post("/api/subscribe")
async def subscribe(plan: str = Form(...), payment_token: str = Form(...)):
    if plan not in TIER_LIMITS:
        raise HTTPException(status_code=400, detail="Invalid plan")
    if not payment_token.startswith("demo_"):
        raise HTTPException(status_code=402, detail="Payment failed. Use 'demo_payment' for testing.")
    new_key = f"{plan}_key_{uuid.uuid4().hex[:8]}"
    MOCK_API_KEYS[new_key] = {"tier": plan, "expires": None}
    return {
        "status": "success",
        "message": f"Upgraded to {TIER_LIMITS[plan]['name']}",
        "api_key": new_key,
        "tier": plan,
        "limits": TIER_LIMITS[plan]
    }

@app.post("/api/predict")
async def predict(
    features: List[float],
    threshold: Optional[float] = None,
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    tier = validate_tier(x_api_key)
    limits = get_limits(tier)
    check_limits(tier)
    
    if threshold is not None and not limits["allow_threshold_tuning"]:
        raise HTTPException(
            status_code=403,
            detail=f"Threshold tuning not allowed for tier {tier}"
        )
    
    if threshold is None:
        threshold = model.best_threshold
    
    features_np = np.array(features).reshape(1, -1)
    proba = model.predict_proba(features_np)[0]
    pred = int(proba >= threshold)
    
    return {
        "prediction": "Attack" if pred == 1 else "Normal",
        "probability": float(proba),
        "threshold_used": float(threshold),
        "tier": tier,
        "remaining_requests": int(limits["daily_api_requests"] - request_counter[tier])
    }

@app.post("/api/upload")
async def upload_file(
    file: UploadFile = File(...),
    target_column: Optional[str] = None,
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    tier = validate_tier(x_api_key)
    limits = get_limits(tier)
    
    contents = await file.read()
    df = pd.read_csv(io.BytesIO(contents))
    if df.empty:
        raise HTTPException(status_code=400, detail="File is empty")
    
    check_limits(tier, requested_rows=df.shape[0])
    
    X, y_true = clean_and_prepare_data(df, target_column)
    proba = model.predict_proba(X)
    y_pred = (proba >= model.best_threshold).astype(int)
    
    attacks = int(np.sum(y_pred))
    normal_count = len(y_pred) - attacks
    
    confusion = None
    if y_true is not None:
        from sklearn.metrics import confusion_matrix
        cm = confusion_matrix(y_true, y_pred)
        confusion = {
            "true_negatives": int(cm[0, 0]),
            "false_positives": int(cm[0, 1]),
            "false_negatives": int(cm[1, 0]),
            "true_positives": int(cm[1, 1])
        }
    
    summary = {
        "total": X.shape[0],
        "features_count": X.shape[1],
        "attacks_detected": attacks,
        "normal_count": normal_count,
        "attack_ratio": f"{attacks / X.shape[0] * 100:.2f}%"
    }
    if confusion:
        summary["confusion_matrix"] = confusion
    
    download_url = None
    if limits["allow_download_report"]:
        results_df = df.copy()
        results_df['prediction'] = ['Attack' if p == 1 else 'Normal' for p in y_pred]
        results_df['probability'] = proba
        output_path = f"predictions_{int(time.time())}.csv"
        results_df.to_csv(output_path, index=False)
        download_url = f"/download/{output_path}"
    
    return {
        "status": "success",
        "tier": tier,
        "total_rows": X.shape[0],
        "attacks_detected": attacks,
        "normal_count": normal_count,
        "prediction_summary": summary,
        "remaining_requests": int(limits["daily_api_requests"] - request_counter[tier]),
        "download_url": download_url
    }

@app.get("/download/{filename}")
async def download_file(filename: str, x_api_key: str = Header(...)):
    tier = validate_tier(x_api_key)
    limits = get_limits(tier)
    if not limits["allow_download_report"]:
        raise HTTPException(status_code=403, detail="Download not allowed for your tier")
    return FileResponse(filename, media_type="text/csv", filename=filename)

# ============================================================
# تشغيل الخادم
# ============================================================
if __name__ == "__main__":
    print("="*70)
    print("🚀 NeoAMONA Enterprise Server - v4.0")
    print("="*70)
    print("📌 Available Tiers:")
    for tier, info in TIER_LIMITS.items():
        print(f"   - {tier.upper()}: {info['name']} - {info['price']}")
    print("="*70)
    uvicorn.run(
        "neoamona_server:app",
        host="0.0.0.0",
        port=8080,
        reload=False
    )