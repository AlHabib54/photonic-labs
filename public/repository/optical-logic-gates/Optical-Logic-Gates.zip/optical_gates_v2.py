import meep as mp
import numpy as np
import csv

# ============================================================
# Optical Logic Gates v2 — مع Bias Phase تصحيحي
# ============================================================
# الاكتشاف: عند Δn=0, Cross=83% (ليس Bar=100%)
# السبب: الـ Coupler غير متوازن → bias طبيعي نحو Cross
#
# الحل: نضيف dn_bias=0.081 (φ=1.25π) على الذراع العلوية
# في كل الحالات — هذا يُحوّل نقطة الصفر إلى Bar=77%
# ثم نُضيف Δn المنطقي فوق الـ bias
#
# منطق القراءة الجديد:
#   Bar > Cross → OUT = 0
#   Cross > Bar → OUT = 1
# ============================================================

resolution = 20
lam        = 1.55
freq       = 1 / lam
n_si       = 3.4
wg_w       = 1.0
gap        = 1.70
c_len      = 6.0
arm_len    = 12.0

dn_pi      = lam / (2 * arm_len)        # 0.0646 → إزاحة π
dn_half    = dn_pi / 2                   # 0.0323 → إزاحة π/2

# نقطة الـ Bias: φ=1.25π → Δn=0.081 (أفضل Bar state من نتائجنا)
dn_bias    = 1.25 * dn_pi               # 0.0808

THRESHOLD  = 0.50   # Cross > 50% → OUT=1

def run_sim(dn_upper_total, dn_lower, label):
    y_up = gap / 2
    y_dn = -gap / 2

    geo = [
        mp.Block(size=mp.Vector3(6, wg_w, mp.inf),
                 center=mp.Vector3(-21, y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(c_len, wg_w, mp.inf),
                 center=mp.Vector3(-14, y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(c_len, wg_w, mp.inf),
                 center=mp.Vector3(-14, y_dn),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(arm_len, wg_w, mp.inf),
                 center=mp.Vector3(0, y_up),
                 material=mp.Medium(index=n_si + dn_upper_total)),
        mp.Block(size=mp.Vector3(arm_len, wg_w, mp.inf),
                 center=mp.Vector3(0, y_dn),
                 material=mp.Medium(index=n_si + dn_lower)),
        mp.Block(size=mp.Vector3(c_len, wg_w, mp.inf),
                 center=mp.Vector3(14, y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(c_len, wg_w, mp.inf),
                 center=mp.Vector3(14, y_dn),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(6, wg_w, mp.inf),
                 center=mp.Vector3(21, y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(6, wg_w, mp.inf),
                 center=mp.Vector3(21, y_dn),
                 material=mp.Medium(index=n_si)),
    ]

    sim = mp.Simulation(
        cell_size=mp.Vector3(50, 12, 0),
        geometry=geo,
        boundary_layers=[mp.PML(1.5)],
        sources=[mp.Source(mp.ContinuousSource(frequency=freq),
                           component=mp.Ez,
                           center=mp.Vector3(-23, y_up))],
        resolution=resolution
    )

    bar_mon   = sim.add_flux(freq, 0, 1,
        mp.FluxRegion(center=mp.Vector3(23, y_up),
                      size=mp.Vector3(0, 2, 0)))
    cross_mon = sim.add_flux(freq, 0, 1,
        mp.FluxRegion(center=mp.Vector3(23, y_dn),
                      size=mp.Vector3(0, 2, 0)))

    sim.run(until=400)

    p_bar   = max(mp.get_fluxes(bar_mon)[0],   0)
    p_cross = max(mp.get_fluxes(cross_mon)[0], 0)
    total   = max(p_bar + p_cross, 1e-10)

    bar_pct   = p_bar   / total * 100
    cross_pct = p_cross / total * 100
    out       = 1 if cross_pct / 100 >= THRESHOLD else 0

    print(f"  {label:22s} Bar={bar_pct:5.1f}%  "
          f"Cross={cross_pct:5.1f}%  OUT={out}")
    return bar_pct, cross_pct, out


def test_gate(name, table):
    print(f"\n{'='*56}")
    print(f"  {name} GATE")
    print(f"{'='*56}")
    results, correct = [], 0
    for A, B, dn_u_logic, dn_l, expected in table:
        # الـ Bias يُضاف دائماً فوق القيمة المنطقية
        dn_u_total = dn_bias + dn_u_logic
        label = f"A={A} B={B}"
        bar, cross, got = run_sim(dn_u_total, dn_l, label)
        ok = (got == expected)
        if ok:
            correct += 1
        print(f"    {'✓' if ok else '✗ exp=' + str(expected)}")
        results.append([name, A, B, round(bar,1), round(cross,1),
                        got, expected, ok])
    print(f"\n  {correct}/{len(table)} correct")
    return results


# ── جداول الحقيقة مع Bias ──
# dn_u_logic هو الـ Δn الإضافي فوق الـ Bias
# φ_total = φ_bias + φ_logic

gates = {
    # AND: نريد Cross=1 فقط عند A=1,B=1
    # φ_bias = 1.25π → Bar state
    # عند A=1: نضيف +π → φ=2.25π → يدور دورة كاملة تقريباً → Cross
    # عند A=0,B=1: الـ lower يتغير → تداخل جزئي
    "AND": [
        (0, 0,    0,          0,          0),
        (0, 1,    0,          dn_pi,      0),
        (1, 0,    dn_pi,      0,          0),
        (1, 1,    dn_pi,      dn_pi,      1),
    ],

    # OR: نريد Cross=1 إذا A=1 أو B=1
    "OR": [
        (0, 0,    0,          0,          0),
        (0, 1,    0,          dn_half,    1),
        (1, 0,    dn_half,    0,          1),
        (1, 1,    dn_half,    dn_half,    1),
    ],

    # XOR: نريد Cross=1 فقط إذا A≠B
    "XOR": [
        (0, 0,    0,          0,          0),
        (0, 1,    0,          dn_pi,      1),
        (1, 0,    dn_pi,      0,          1),
        (1, 1,    dn_pi,      dn_pi,      0),
    ],

    # NOT: عاكس بسيط
    "NOT": [
        (0, 0,    0,          0,          0),
        (1, 0,    dn_pi,      0,          1),
    ],
}

all_results = []
for gname, table in gates.items():
    r = test_gate(gname, table)
    all_results.extend(r)

with open("optical_gates_v2_results.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["Gate","A","B","Bar_%","Cross_%",
                "Got","Expected","Correct"])
    w.writerows(all_results)

print("\n" + "="*56)
print("OPTICAL LOGIC GATES v2 — SUMMARY")
print("="*56)
for gname in gates:
    rows = [r for r in all_results if r[0] == gname]
    ok   = sum(r[7] for r in rows)
    bar  = "✓ PASS" if ok == len(rows) else f"✗ {ok}/{len(rows)}"
    print(f"  {gname:6s}: {bar}")

total = sum(r[7] for r in all_results)
print(f"\n  Total: {total}/{len(all_results)}")
if total == len(all_results):
    print("  *** ALL PASS — معالج بوليني ضوئي مكتمل ***")
else:
    print("  → cat optical_gates_v2_results.csv للتحليل")
print("="*56)
