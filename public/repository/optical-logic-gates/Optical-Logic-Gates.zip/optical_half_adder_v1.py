import matplotlib.pyplot as plt
from datetime import datetime

# =====================================================
# OPTICAL HALF ADDER V1
#
# VERIFIED COMPONENTS:
# XOR Gate V1
# AND Gate V1
#
# SUM   = XOR(A,B)
# CARRY = AND(A,B)
# =====================================================

print("")
print("====================================")
print("OPTICAL HALF ADDER V1")
print("Built on Verified Gates")
print("====================================")

# =====================================================
# INPUT CASES
# =====================================================

logic_cases = {

    "00": (0, 0),
    "01": (0, 1),
    "10": (1, 0),
    "11": (1, 1)
}

sum_results = {}
carry_results = {}

# =====================================================
# VERIFIED LOGIC FUNCTIONS
# =====================================================

def optical_or(a, b):

    if a == 0 and b == 0:
        return 0

    return 1


def optical_and(a, b):

    if a == 1 and b == 1:
        return 1

    return 0


def optical_not(x):

    return 1 - x


def optical_xor(a, b):

    or_output = optical_or(
        a,
        b
    )

    and_output = optical_and(
        a,
        b
    )

    not_and_output = optical_not(
        and_output
    )

    xor_output = (
        or_output
        * not_and_output
    )

    return xor_output


# =====================================================
# RUN ALL STATES
# =====================================================

for case_name, (A, B) in logic_cases.items():

    print("")
    print("------------------------------------")
    print("CASE =", case_name)
    print("A =", A, "B =", B)
    print("------------------------------------")

    # ================================================
    # SUM = XOR(A,B)
    # ================================================

    sum_output = optical_xor(
        A,
        B
    )

    # ================================================
    # CARRY = AND(A,B)
    # ================================================

    carry_output = optical_and(
        A,
        B
    )

    sum_results[
        case_name
    ] = sum_output

    carry_results[
        case_name
    ] = carry_output

    print(
        "SUM =",
        sum_output
    )

    print(
        "CARRY =",
        carry_output
    )

# =====================================================
# VERIFICATION
# =====================================================

sum_verified = (

    sum_results["00"] == 0
    and sum_results["01"] == 1
    and sum_results["10"] == 1
    and sum_results["11"] == 0
)

carry_verified = (

    carry_results["00"] == 0
    and carry_results["01"] == 0
    and carry_results["10"] == 0
    and carry_results["11"] == 1
)

verified = (
    sum_verified
    and carry_verified
)

status = (
    "PASS"
    if verified
    else "FAIL"
)

# =====================================================
# PLOTS
# =====================================================

labels = [
    "00",
    "01",
    "10",
    "11"
]

sum_values = [
    sum_results["00"],
    sum_results["01"],
    sum_results["10"],
    sum_results["11"]
]

carry_values = [
    carry_results["00"],
    carry_results["01"],
    carry_results["10"],
    carry_results["11"]
]

# =====================================================
# SUM CHART
# =====================================================

plt.figure(
    figsize=(7,4)
)

plt.bar(
    labels,
    sum_values
)

plt.ylabel(
    "Logic Output"
)

plt.title(
    "Optical Half Adder V1 - SUM"
)

plt.savefig(
    "optical_half_adder_v1_sum.png",
    dpi=250
)

plt.close()

# =====================================================
# CARRY CHART
# =====================================================

plt.figure(
    figsize=(7,4)
)

plt.bar(
    labels,
    carry_values
)

plt.ylabel(
    "Logic Output"
)

plt.title(
    "Optical Half Adder V1 - CARRY"
)

plt.savefig(
    "optical_half_adder_v1_carry.png",
    dpi=250
)

plt.close()

# =====================================================
# TXT REPORT
# =====================================================

with open(
    "optical_half_adder_v1_report.txt",
    "w"
) as f:

    f.write(
        "OPTICAL HALF ADDER V1 REPORT\n"
    )

    f.write(
        "====================================\n"
    )

    f.write(
        f"DATE: {datetime.now()}\n\n"
    )

    for case in labels:

        f.write(
            f"CASE {case}\n"
        )

        f.write(
            f"SUM = "
            f"{sum_results[case]}\n"
        )

        f.write(
            f"CARRY = "
            f"{carry_results[case]}\n\n"
        )

    f.write(
        f"STATUS = {status}\n"
    )

# =====================================================
# FINAL REPORT
# =====================================================

print("")
print("====================================")
print("OPTICAL HALF ADDER V1 REPORT")
print("====================================")

for case in labels:

    print(
        "CASE",
        case
    )

    print(
        "SUM =",
        sum_results[case]
    )

    print(
        "CARRY =",
        carry_results[case]
    )

    print("")

print(
    "STATUS =",
    status
)

print("")
print("Saved Files:")

print(
    "optical_half_adder_v1_sum.png"
)

print(
    "optical_half_adder_v1_carry.png"
)

print(
    "optical_half_adder_v1_report.txt"
)

print("====================================")
