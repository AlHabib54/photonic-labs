import meep as mp
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime

# =====================================================
# OPTICAL NOT GATE V1
# Built on:
# Photonic Logic Core V1 (Verified)
# =====================================================

print("")
print("====================================")
print("OPTICAL NOT GATE V1")
print("Built on Photonic Logic Core V1")
print("====================================")

# =====================================================
# VERIFIED CONSTANTS
# =====================================================

resolution = 20

silicon = mp.Medium(index=3.4)

wavelength = 1.55
frequency = 1 / wavelength

wg_width = 1.0
spacing = 3.0

arm_length = 50
merge_length = 45
final_gap = 0.6

simulation_time = 400

# =====================================================
# VERIFIED INPUT STATES
# =====================================================

INPUT_0_DELTA_L = 45.0
INPUT_1_DELTA_L = 100.0

input_states = {
    "INPUT_0": INPUT_0_DELTA_L,
    "INPUT_1": INPUT_1_DELTA_L
}

results = {}

# =====================================================
# SAFE POLYGON BUILDER
# =====================================================

def build_waveguide(points, width):

    top = []
    bottom = []

    n = len(points)

    for i in range(n):

        x, y = points[i]

        if i == 0:

            dx = points[i + 1][0] - x
            dy = points[i + 1][1] - y

        elif i == n - 1:

            dx = x - points[i - 1][0]
            dy = y - points[i - 1][1]

        else:

            dx = (
                points[i + 1][0]
                - points[i - 1][0]
            )

            dy = (
                points[i + 1][1]
                - points[i - 1][1]
            )

        norm = np.sqrt(dx**2 + dy**2)

        if norm < 1e-12:
            continue

        nx = -dy / norm
        ny = dx / norm

        top.append(
            (
                x + nx * width / 2,
                y + ny * width / 2
            )
        )

        bottom.append(
            (
                x - nx * width / 2,
                y - ny * width / 2
            )
        )

    polygon = top + bottom[::-1]

    return [
        mp.Vector3(px, py)
        for px, py in polygon
    ]

# =====================================================
# RUN INPUT STATES
# =====================================================

for input_name, delta_L in input_states.items():

    print("")
    print("------------------------------------")
    print("INPUT =", input_name)
    print("DELTA L =", delta_L)
    print("------------------------------------")

    sx = 240
    sy = 24

    cell = mp.Vector3(
        sx,
        sy,
        0
    )

    geometry = []

    upper_points = []
    lower_points = []

    # =================================================
    # INPUT WAVEGUIDE
    # =================================================

    geometry.append(

        mp.Block(

            size=mp.Vector3(
                24,
                wg_width,
                mp.inf
            ),

            center=mp.Vector3(
                -102,
                0
            ),

            material=silicon
        )
    )

    # =================================================
    # SPLITTER
    # =================================================

    split_start = -90
    split_end = -60

    for x in np.linspace(
        split_start,
        split_end,
        120
    ):

        t = (
            x - split_start
        ) / (
            split_end - split_start
        )

        y = (
            spacing
            * 0.5
            * (
                1
                - np.cos(np.pi * t)
            )
        )

        upper_points.append(
            (x, y)
        )

        lower_points.append(
            (x, -y)
        )

    # =================================================
    # ARMS
    # =================================================

    arm_start = split_end

    upper_arm_end = (
        arm_start
        + arm_length
        + delta_L
    )

    lower_arm_end = (
        arm_start
        + arm_length
    )

    for x in np.linspace(
        arm_start,
        upper_arm_end,
        140
    ):

        upper_points.append(
            (
                x,
                spacing
            )
        )

    for x in np.linspace(
        arm_start,
        lower_arm_end,
        140
    ):

        lower_points.append(
            (
                x,
                -spacing
            )
        )

    merge_start = max(
        upper_arm_end,
        lower_arm_end
    )

    if upper_arm_end < merge_start:

        for x in np.linspace(
            upper_arm_end,
            merge_start,
            40
        ):

            upper_points.append(
                (
                    x,
                    spacing
                )
            )

    if lower_arm_end < merge_start:

        for x in np.linspace(
            lower_arm_end,
            merge_start,
            40
        ):

            lower_points.append(
                (
                    x,
                    -spacing
                )
            )

    # =================================================
    # COMBINER
    # =================================================

    merge_end = (
        merge_start
        + merge_length
    )

    for x in np.linspace(
        merge_start,
        merge_end,
        160
    ):

        t = (
            x - merge_start
        ) / (
            merge_end
            - merge_start
        )

        y = spacing - (

            (
                spacing
                - final_gap
            )

            * 0.5

            * (
                1
                - np.cos(
                    np.pi * t
                )
            )
        )

        upper_points.append(
            (
                x,
                y
            )
        )

        lower_points.append(
            (
                x,
                -y
            )
        )

    # =================================================
    # OUTPUT
    # =================================================

    output_start = merge_end
    output_end = output_start + 20

    for x in np.linspace(
        output_start,
        output_end,
        60
    ):

        upper_points.append(
            (
                x,
                final_gap
            )
        )

        lower_points.append(
            (
                x,
                -final_gap
            )
        )

    geometry.append(

        mp.Prism(

            vertices=build_waveguide(
                upper_points,
                wg_width
            ),

            height=mp.inf,

            material=silicon
        )
    )

    geometry.append(

        mp.Prism(

            vertices=build_waveguide(
                lower_points,
                wg_width
            ),

            height=mp.inf,

            material=silicon
        )
    )

    # =================================================
    # SOURCE
    # =================================================

    sources = [

        mp.Source(

            src=mp.GaussianSource(
                frequency=frequency,
                fwidth=0.08
            ),

            component=mp.Ez,

            center=mp.Vector3(
                -105,
                0
            ),

            size=mp.Vector3(
                0,
                1.2
            )
        )
    ]

    sim = mp.Simulation(

        cell_size=cell,

        geometry=geometry,

        boundary_layers=[
            mp.PML(1.0)
        ],

        sources=sources,

        resolution=resolution,

        eps_averaging=False
    )

    output_flux = sim.add_flux(

        frequency,
        0,
        1,

        mp.FluxRegion(

            center=mp.Vector3(
                95,
                0
            ),

            size=mp.Vector3(
                0,
                4
            )
        )
    )

    sim.run(
        until=simulation_time
    )

    output_power = mp.get_fluxes(
        output_flux
    )[0]

    results[input_name] = output_power

    print(
        "OUTPUT POWER =",
        output_power
    )

# =====================================================
# LOGIC ANALYSIS
# =====================================================

power_input_0 = results["INPUT_0"]
power_input_1 = results["INPUT_1"]

threshold = (
    power_input_0
    + power_input_1
) / 2

# Binary switch outputs
binary_0 = (
    1 if power_input_0 > threshold
    else 0
)

binary_1 = (
    1 if power_input_1 > threshold
    else 0
)

# =====================================================
# NOT GATE
# =====================================================

not_output_0 = 1 - binary_0
not_output_1 = 1 - binary_1

# =====================================================
# VERIFICATION
# =====================================================

not_verified = (
    not_output_0 == 1
    and not_output_1 == 0
)

status = (
    "PASS"
    if not_verified
    else "FAIL"
)

# =====================================================
# PLOT
# =====================================================

labels = [
    "NOT(0)",
    "NOT(1)"
]

values = [
    not_output_0,
    not_output_1
]

plt.figure(figsize=(6,4))

plt.bar(
    labels,
    values
)

plt.ylabel(
    "Logic Output"
)

plt.title(
    "Optical NOT Gate V1"
)

plt.savefig(
    "optical_not_gate_v1.png",
    dpi=250
)

plt.close()

# =====================================================
# TXT REPORT
# =====================================================

with open(
    "optical_not_gate_v1_report.txt",
    "w"
) as f:

    f.write(
        "OPTICAL NOT GATE V1 REPORT\n"
    )

    f.write(
        "====================================\n"
    )

    f.write(
        f"DATE: {datetime.now()}\n\n"
    )

    f.write(
        f"INPUT_0 POWER = {power_input_0}\n"
    )

    f.write(
        f"INPUT_1 POWER = {power_input_1}\n"
    )

    f.write(
        f"THRESHOLD = {threshold}\n"
    )

    f.write(
        f"NOT(0) = {not_output_0}\n"
    )

    f.write(
        f"NOT(1) = {not_output_1}\n"
    )

    f.write(
        f"STATUS = {status}\n"
    )

# =====================================================
# FINAL REPORT
# =====================================================

print("")
print("====================================")
print("OPTICAL NOT GATE V1 REPORT")
print("====================================")

print("INPUT_0 POWER =", power_input_0)
print("INPUT_1 POWER =", power_input_1)

print("THRESHOLD =", threshold)

print("NOT(0) =", not_output_0)
print("NOT(1) =", not_output_1)

print("STATUS =", status)

print("")
print("Saved Files:")
print("optical_not_gate_v1.png")
print("optical_not_gate_v1_report.txt")
print("====================================")
