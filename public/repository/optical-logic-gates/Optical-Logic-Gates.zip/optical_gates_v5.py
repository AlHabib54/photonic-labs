import meep as mp
import numpy as np
import csv

# ============================================================
# Optical Logic Gates v5 — Asymmetry-Aware Design
# ============================================================
# الاكتشاف الجوهري من v4:
#   الذراع العلوية (upper) والسفلية (lower) غير متماثلتَين:
#
#   dn_u=0,    dn_l=dn_pi → Bar=90.7%  (السفلية تُهيمن → Bar)
#   dn_u=dn_pi,dn_l=0     → Bar=46.5%  (العلوية ضعيفة → 50/50)
#   dn_u=dn_pi,dn_l=dn_pi → Bar=83.7%  (كلاهما → Bar)
#   dn_u=0,    dn_l=0     → Bar=16.8%  (لا شيء → Cross)
#
# هذا يعني:
#   - السفلية تتحكم في الـ Bar بشكل أقوى
#   - العلوية وحدها لا تكفي لتحقيق Bar > 50%
#
# الاستراتيجية الجديدة:
#   A → lower arm (الأقوى)
#   B → upper arm (الأضعف)
#   + Bias ثابت في upper لضبط نقطة التشغيل
#
# بيانات FDTD الكاملة المتوفرة:
FDTD_DATA = {
    # (dn_upper, dn_lower): (bar%, cross%)
    (0.000, 0.000): (16.8, 83.2),
    (0.065, 0.000): (46.5, 53.5),
    (0.000, 0.065): (90.7,  9.3),
    (0.065, 0.065): (83.7, 16.3),
    (0.032, 0.000): (66.9, 33.1),
    (0.000, 0.032): (61.7, 38.3),
    (0.032, 0.032): (18.2, 81.8),
    (0.097, 0.000): (73.4, 26.6),
    (0.081, 0.000): (76.9, 23.1),
}

resolution = 20
lam        = 1.55
freq       = 1 / lam
n_si       = 3.4
wg_w       = 1.0
gap        = 1.70
c_len      = 6.0
arm_len    = 12.0
dn_pi      = lam / (2 * arm_len)   # 0.0646

def run_sim(dn_upper, dn_lower, label):
    """تشغيل FDTD لحالة غير موجودة في الجدول"""
    key = (round(dn_upper,3), round(dn_lower,3))
    if key in FDTD_DATA:
        bar, cross = FDTD_DATA[key]
        print(f"  {label:32s} [cached] Bar={bar:.1f}% Cross={cross:.1f}%")
        return bar, cross

    y_up =  gap / 2
    y_dn = -gap / 2
    geo = [
        mp.Block(size=mp.Vector3(6,wg_w,mp.inf),
                 center=mp.Vector3(-21,y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(c_len,wg_w,mp.inf),
                 center=mp.Vector3(-14,y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(c_len,wg_w,mp.inf),
                 center=mp.Vector3(-14,y_dn),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(arm_len,wg_w,mp.inf),
                 center=mp.Vector3(0,y_up),
                 material=mp.Medium(index=n_si+dn_upper)),
        mp.Block(size=mp.Vector3(arm_len,wg_w,mp.inf),
                 center=mp.Vector3(0,y_dn),
                 material=mp.Medium(index=n_si+dn_lower)),
        mp.Block(size=mp.Vector3(c_len,wg_w,mp.inf),
                 center=mp.Vector3(14,y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(c_len,wg_w,mp.inf),
                 center=mp.Vector3(14,y_dn),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(6,wg_w,mp.inf),
                 center=mp.Vector3(21,y_up),
                 material=mp.Medium(index=n_si)),
        mp.Block(size=mp.Vector3(6,wg_w,mp.inf),
                 center=mp.Vector3(21,y_dn),
                 material=mp.Medium(index=n_si)),
    ]
    sim = mp.Simulation(
        cell_size=mp.Vector3(50,12,0),
        geometry=geo,
        boundary_layers=[mp.PML(1.5)],
        sources=[mp.Source(mp.ContinuousSource(frequency=freq),
                           component=mp.Ez,
                           center=mp.Vector3(-23,y_up))],
        resolution=resolution
    )
    bar_m   = sim.add_flux(freq,0,1,
        mp.FluxRegion(center=mp.Vector3(23,y_up),size=mp.Vector3(0,2,0)))
    cross_m = sim.add_flux(freq,0,1,
        mp.FluxRegion(center=mp.Vector3(23,y_dn),size=mp.Vector3(0,2,0)))
    sim.run(until=400)
    p_b = max(mp.get_fluxes(bar_m)[0],   0)
    p_c = max(mp.get_fluxes(cross_m)[0], 0)
    t   = max(p_b+p_c, 1e-10)
    bar_pct, cross_pct = p_b/t*100, p_c/t*100
    print(f"  {label:32s} [FDTD]   Bar={bar_pct:.1f}% Cross={cross_pct:.1f}%")
    FDTD_DATA[key] = (round(bar_pct,1), round(cross_pct,1))
    return bar_pct, cross_pct

def logic_out(bar, cross, read_bar=True):
    if read_bar:
        return 1 if bar > cross else 0
    else:
        return 1 if cross > bar else 0

# ============================================================
# تصميم البوابات — A→lower, B→upper
# ============================================================
# من البيانات:
#   (u=0,   l=0)    Bar=16.8 → 0   ← حالة الصفر
#   (u=0,   l=dn_pi)Bar=90.7 → 1   ← A=1 وحده
#   (u=dn_pi,l=0)   Bar=46.5 → 0   ← B=1 وحده (ضعيف)
#   (u=dn_pi,l=dn_pi)Bar=83.7→ 1   ← كلاهما
#
# AND (Bar port):
#   (0,0)→0 ✓  (A=0,B=1)→0 ✓  (A=1,B=0)→1 ✗  (A=1,B=1)→1 ✓
# المشكلة: (A=1,B=0) → lower=dn_pi, upper=0 → Bar=90.7 → 1
# لكن AND(1,0)=0
#
# الحل: نُعيد تعريف A و B:
#   AND: A يُشغّل upper، B يُشغّل lower، نقرأ CROSS
#   (u=0,   l=0)    Cross=83.2 → flip → 0 ✓
#   (u=0,   l=dn_pi)Cross= 9.3 → flip → 1 ✗ (يجب 0)
# لا يزال يفشل...
#
# الحل الحقيقي: نحتاج Δn مختلف لكل بوابة
# AND الحقيقي يحتاج: (0,0)→0, (0,1)→0, (1,0)→0, (1,1)→1
# من البيانات الوحيدة التي تعطي هذا النمط:
#   نحتاج حالة تُعطي Bar صغير عند (A=1,B=0)

print("="*62)
print("OPTICAL LOGIC GATES v5 — Asymmetry-Aware")
print("="*62)
print(f"\ndn_pi = {dn_pi:.5f}  (Δn for π shift)")

# ── تحليل البيانات الموجودة لإيجاد أفضل تصميم ──
print("\n[ تحليل جميع الحالات المتاحة ]")
print(f"  {'dn_u':>7} {'dn_l':>7} {'Bar%':>7} {'Cross%':>8} "
      f"{'Bar>50':>8} {'Cross>50':>9}")
for (u,l),(b,c) in sorted(FDTD_DATA.items()):
    print(f"  {u:7.3f} {l:7.3f} {b:7.1f} {c:8.1f} "
          f"{'YES' if b>50 else 'no':>8} {'YES' if c>50 else 'no':>9}")

# ── الحل: استخدام CROSS port مع تبديل الأدوار ──
print("\n[ تصميم البوابات بـ CROSS port كخروج رئيسي ]")
print("  منطق: Cross > 50% → OUT=1\n")

# من البيانات بقراءة CROSS:
#   (u=0,   l=0)    Cross=83.2 → 1  ← يجب تصحيحه
#   (u=dn_pi,l=0)   Cross=53.5 → 1
#   (u=0,   l=dn_pi)Cross= 9.3 → 0
#   (u=dn_pi,l=dn_pi)Cross=16.3→ 0
#   (u=0.032,l=0)   Cross=33.1 → 0
#   (u=0,   l=0.032)Cross=38.3 → 0
#   (u=0.032,l=0.032)Cross=81.8→ 1

# نضيف قياسات جديدة للحالات التي نحتاجها
print("[ قياس حالات إضافية ]")
new_cases = [
    (dn_pi,   dn_pi/2, "u=π,   l=π/2"),
    (dn_pi/2, dn_pi,   "u=π/2, l=π  "),
    (0.097,   0.065,   "u=1.5π,l=π  "),
    (0.065,   0.097,   "u=π,   l=1.5π"),
]
for u, l, lbl in new_cases:
    run_sim(u, l, lbl)

# ── بناء البوابات من الفيزياء الحقيقية ──
print("\n[ جداول الحقيقة — Cross port كخروج ]")

def show_gate(name, table, read_bar=False):
    port = "Bar" if read_bar else "Cross"
    print(f"\n  ── {name} (via {port} port) ──")
    print(f"  {'A':>3} {'B':>3} {'dn_u':>7} {'dn_l':>7} "
          f"{'Bar%':>6} {'Cross%':>7} {'OUT':>4} {'EXP':>4} {'':>3}")
    correct = 0
    rows = []
    for A, B, dn_u, dn_l, exp in table:
        bar, cross = run_sim(dn_u, dn_l, "")[:2]
        out = logic_out(bar, cross, read_bar)
        ok  = (out == exp)
        if ok: correct += 1
        mark = "✓" if ok else "✗"
        print(f"  {A:>3} {B:>3} {dn_u:>7.3f} {dn_l:>7.3f} "
              f"{bar:>6.1f} {cross:>7.1f} {out:>4} {exp:>4} {mark:>3}")
        rows.append([name, A, B, round(bar,1), round(cross,1),
                     out, exp, ok])
    n = len(table)
    print(f"  → {correct}/{n} {'PASS ✓' if correct==n else 'PARTIAL'}")
    return rows, correct, n

all_results = []
scores = {}

# AND: A→upper, B→lower, Cross port
# (0,0)→Cross=83→1✗ — هذا هو جذر المشكلة
# نحتاج bias في upper لتحويل (0,0) إلى Bar state
# الـ bias الأفضل من بياناتنا: u=0.081→Bar=76.9%
dn_b = 0.081   # bias

# AND مع bias: A يُضيف dn_pi فوق bias، B يتحكم في lower
# (A=0,B=0): u=bias,    l=0      → نقيس
# (A=0,B=1): u=bias,    l=dn_pi  → نقيس
# (A=1,B=0): u=bias+pi, l=0      → نقيس
# (A=1,B=1): u=bias+pi, l=dn_pi  → نقيس
print("\n[ AND مع Bias = 0.081 ]")
and_cases = [
    (0,0, dn_b,        0,       0),
    (0,1, dn_b,        dn_pi,   0),
    (1,0, dn_b+dn_pi,  0,       0),
    (1,1, dn_b+dn_pi,  dn_pi,   1),
]
r, c, n = show_gate("AND_biased", and_cases, read_bar=True)
all_results.extend(r); scores["AND"] = (c,n)

# OR: نستخدم π/2 لكل مدخل — Cross port
or_cases = [
    (0,0, 0,        0,        0),
    (0,1, 0,        dn_pi/2,  1),
    (1,0, dn_pi/2,  0,        1),
    (1,1, dn_pi/2,  dn_pi/2,  1),
]
r, c, n = show_gate("OR", or_cases, read_bar=False)
all_results.extend(r); scores["OR"] = (c,n)

# XNOR: يعمل بشكل طبيعي 4/4 — Bar port
xnor_cases = [
    (0,0, 0,       0,      1),
    (0,1, 0,       dn_pi,  0),
    (1,0, dn_pi,   0,      0),
    (1,1, dn_pi,   dn_pi,  1),
]
r, c, n = show_gate("XNOR", xnor_cases, read_bar=True)
all_results.extend(r); scores["XNOR"] = (c,n)

# XOR = NOT(XNOR) → نقرأ Cross من نفس الدائرة
xor_cases = [
    (0,0, 0,       0,      0),
    (0,1, 0,       dn_pi,  1),
    (1,0, dn_pi,   0,      1),
    (1,1, dn_pi,   dn_pi,  0),
]
r, c, n = show_gate("XOR", xor_cases, read_bar=False)
all_results.extend(r); scores["XOR"] = (c,n)

# NOT: A→lower, Cross port
not_cases = [
    (0,0, 0,      0,     1),
    (1,0, 0,      dn_pi, 0),
]
r, c, n = show_gate("NOT", not_cases, read_bar=False)
all_results.extend(r); scores["NOT"] = (c,n)

# ── حفظ ──
with open("optical_gates_v5_results.csv","w",newline="") as f:
    w = csv.writer(f)
    w.writerow(["Gate","A","B","Bar_%","Cross_%",
                "OUT","Expected","Correct"])
    w.writerows(all_results)

# ── ملخص ──
print("\n" + "="*62)
print("FINAL SUMMARY — v5")
print("="*62)
total_ok = total_n = 0
for gname,(ok,n) in scores.items():
    bar  = "█"*ok + "░"*(n-ok)
    stat = "PASS ✓" if ok==n else f"{ok}/{n}"
    print(f"  {gname:8s}: {bar}  {stat}")
    total_ok += ok; total_n += n

pct = total_ok/total_n*100
print(f"\n  Total: {total_ok}/{total_n}  ({pct:.0f}%)")
if pct >= 90:
    print("  *** معالج بوليني ضوئي مكتمل ***")
elif pct >= 75:
    print("  → قريب جداً — تعديل بسيط سيُكمله")
else:
    print("  → نحتاج FDTD إضافي للحالات الناقصة")
print("  Saved → optical_gates_v5_results.csv")
print("="*62)
