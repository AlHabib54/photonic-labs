import matplotlib.pyplot as plt
from datetime import datetime

# =====================================================
# OPTICAL XOR GATE V1
# Built on Verified Gates:
#
# NOT Gate V1
# AND Gate V1
# OR Gate V1
#
# XOR = (A OR B) AND NOT(A AND B)
# =====================================================

print("")
print("====================================")
print("OPTICAL XOR GATE V1")
print("Built on Verified Logic Gates")
print("====================================")

# =====================================================
# INPUT CASES
# =====================================================

logic_cases = {

    "00": (0, 0),
    "01": (0, 1),
    "10": (1, 0),
    "11": (1, 1)
}

xor_results = {}

# =====================================================
# VERIFIED LOGIC FUNCTIONS
# =====================================================

def optical_or(a, b):

    if a == 0 and b == 0:
        return 0

    return 1


def optical_and(a, b):

    if a == 1 and b == 1:
        return 1

    return 0


def optical_not(x):

    return 1 - x


# =====================================================
# RUN ALL STATES
# =====================================================

for case_name, (A, B) in logic_cases.items():

    print("")
    print("------------------------------------")
    print("CASE =", case_name)
    print("A =", A, "B =", B)
    print("------------------------------------")

    # ================================================
    # VERIFIED OR
    # ================================================

    or_output = optical_or(
        A,
        B
    )

    # ================================================
    # VERIFIED AND
    # ================================================

    and_output = optical_and(
        A,
        B
    )

    # ================================================
    # VERIFIED NOT
    # ================================================

    not_and_output = optical_not(
        and_output
    )

    # ================================================
    # XOR COMPOSITION
    # ================================================

    xor_output = (
        or_output
        * not_and_output
    )

    xor_results[
        case_name
    ] = xor_output

    print("OR =", or_output)
    print("AND =", and_output)
    print("NOT(AND) =", not_and_output)
    print("XOR =", xor_output)

# =====================================================
# VERIFICATION
# =====================================================

verified = (

    xor_results["00"] == 0
    and xor_results["01"] == 1
    and xor_results["10"] == 1
    and xor_results["11"] == 0
)

status = (
    "PASS"
    if verified
    else "FAIL"
)

# =====================================================
# PLOT
# =====================================================

labels = [
    "00",
    "01",
    "10",
    "11"
]

values = [
    xor_results["00"],
    xor_results["01"],
    xor_results["10"],
    xor_results["11"]
]

plt.figure(
    figsize=(7,4)
)

plt.bar(
    labels,
    values
)

plt.ylabel(
    "Logic Output"
)

plt.title(
    "Optical XOR Gate V1"
)

plt.savefig(
    "optical_xor_gate_v1.png",
    dpi=250
)

plt.close()

# =====================================================
# TXT REPORT
# =====================================================

with open(
    "optical_xor_gate_v1_report.txt",
    "w"
) as f:

    f.write(
        "OPTICAL XOR GATE V1 REPORT\n"
    )

    f.write(
        "====================================\n"
    )

    f.write(
        f"DATE: {datetime.now()}\n\n"
    )

    for case in labels:

        f.write(
            f"XOR{case} = "
            f"{xor_results[case]}\n"
        )

    f.write("\n")

    f.write(
        f"STATUS = {status}\n"
    )

# =====================================================
# FINAL REPORT
# =====================================================

print("")
print("====================================")
print("OPTICAL XOR GATE V1 REPORT")
print("====================================")

for case in labels:

    print(
        "XOR" + case,
        "=",
        xor_results[case]
    )

print("")
print(
    "STATUS =",
    status
)

print("")
print("Saved Files:")
print(
    "optical_xor_gate_v1.png"
)

print(
    "optical_xor_gate_v1_report.txt"
)

print("====================================")
