# -*- coding: utf-8 -*-
"""
NeoAMONA Enterprise Core v4.0
قلب الخوارزمية - خالٍ من أي منطق تجاري، جاهز للتضمين في أي نظام
"""

import numpy as np
import pickle
import time
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.feature_selection import SelectKBest, f_classif
import warnings
warnings.filterwarnings('ignore')

try:
    from xgboost import XGBClassifier
    XGB_AVAILABLE = True
except ImportError:
    XGB_AVAILABLE = False

try:
    from imblearn.over_sampling import SMOTE
    IMB_AVAILABLE = True
except ImportError:
    IMB_AVAILABLE = False


# ============================================================
# 1. العقد (Nodes)
# ============================================================

class BaseNode:
    def __init__(self, name): self.name = name

class DenoiseNode(BaseNode):
    def __init__(self):
        super().__init__("denoise")
        self.pca = None
    def fit_transform(self, X):
        n_comp = min(25, X.shape[1])
        self.pca = PCA(n_components=n_comp, random_state=42)
        return self.pca.fit_transform(X)
    def transform(self, X):
        return self.pca.transform(X)

class FeatureSelectNode(BaseNode):
    def __init__(self, k=20):
        super().__init__("feature_select")
        self.selector = None
        self.k = k
    def fit_transform(self, X, y):
        if X.shape[1] <= self.k:
            self.selector = None
            return X
        self.selector = SelectKBest(f_classif, k=min(self.k, X.shape[1]-1))
        return self.selector.fit_transform(X, y)
    def transform(self, X):
        if self.selector is None:
            return X
        return self.selector.transform(X)

class RandomForestNode(BaseNode):
    def __init__(self):
        super().__init__("rf")
        self.model = None
    def fit(self, X, y):
        base = RandomForestClassifier(n_estimators=150, class_weight='balanced', random_state=42)
        self.model = CalibratedClassifierCV(base, method='isotonic', cv=3)
        self.model.fit(X, y)
        return self
    def predict_proba(self, X):
        return self.model.predict_proba(X)[:, 1]

class XGBoostNode(BaseNode):
    def __init__(self):
        super().__init__("xgboost")
        self.model = None
    def fit(self, X, y):
        if not XGB_AVAILABLE:
            base = RandomForestClassifier(n_estimators=100, class_weight='balanced', random_state=42)
        else:
            base = XGBClassifier(n_estimators=200, learning_rate=0.05, max_depth=6,
                                 scale_pos_weight=(len(y)-sum(y))/sum(y),
                                 use_label_encoder=False, eval_metric='logloss',
                                 random_state=42, verbosity=0)
        self.model = CalibratedClassifierCV(base, method='isotonic', cv=3)
        self.model.fit(X, y)
        return self
    def predict_proba(self, X):
        return self.model.predict_proba(X)[:, 1]

class StackingNode(BaseNode):
    def __init__(self):
        super().__init__("stacking")
        self.model = None
    def fit(self, X, y):
        estimators = [
            ('rf', RandomForestClassifier(n_estimators=80, class_weight='balanced', random_state=42)),
            ('xgb', XGBClassifier(n_estimators=80, use_label_encoder=False, eval_metric='logloss',
                                  random_state=42) if XGB_AVAILABLE else RandomForestClassifier(n_estimators=80))
        ]
        final_est = LogisticRegression(class_weight='balanced', max_iter=500)
        base = StackingClassifier(estimators=estimators, final_estimator=final_est,
                                  cv=3, stack_method='predict_proba')
        self.model = CalibratedClassifierCV(base, method='isotonic', cv=3)
        self.model.fit(X, y)
        return self
    def predict_proba(self, X):
        return self.model.predict_proba(X)[:, 1]


# ============================================================
# 2. محرك NeoAMONA الأساسي
# ============================================================

class NeoAMONACore:
    def __init__(self):
        self.nodes = {
            'denoise': DenoiseNode(),
            'feature_select': FeatureSelectNode(k=20),
            'rf': RandomForestNode(),
            'xgboost': XGBoostNode(),
            'stacking': StackingNode()
        }
        self.active_nodes = []
        self.best_threshold = 0.5
        self.scaler = None
        self.training_time = 0
        self.version = "4.0.0"

    def _validate_combo(self, X_train, y_train, X_val, y_val, combo):
        try:
            X_curr = X_train.copy()
            for name in combo:
                node = self.nodes[name]
                if name == 'denoise':
                    X_curr = node.fit_transform(X_curr)
                elif name == 'feature_select':
                    X_curr = node.fit_transform(X_curr, y_train)
                else:
                    node.fit(X_curr, y_train)
            X_val_curr = X_val.copy()
            for name in combo:
                node = self.nodes[name]
                if name == 'denoise':
                    X_val_curr = node.transform(X_val_curr)
                elif name == 'feature_select':
                    X_val_curr = node.transform(X_val_curr)
                else:
                    proba = node.predict_proba(X_val_curr)
                    if name == combo[-1]:
                        f1 = f1_score(y_val, (proba >= 0.5).astype(int))
                        roc = roc_auc_score(y_val, proba)
                        return f1, roc
            return 0, 0
        except Exception:
            return 0, 0

    def _find_best_threshold(self, X_val, y_val, combo):
        X_curr = X_val.copy()
        for name in combo:
            node = self.nodes[name]
            if name == 'denoise':
                X_curr = node.transform(X_curr)
            elif name == 'feature_select':
                X_curr = node.transform(X_curr)
            else:
                proba = node.predict_proba(X_curr)
                if name == combo[-1]:
                    best_t, best_f1 = 0.5, 0
                    for t in np.linspace(0.01, 0.99, 99):
                        pred = (proba >= t).astype(int)
                        f = f1_score(y_val, pred)
                        if f > best_f1:
                            best_f1, best_t = f, t
                    return best_t
        return 0.5

    def fit(self, X, y, validation_size=0.25, use_smote=True):
        start_time = time.time()
        try:
            X_train, X_val, y_train, y_val = train_test_split(
                X, y, test_size=validation_size, random_state=42, stratify=y
            )
        except ValueError:
            X_train, X_val, y_train, y_val = train_test_split(
                X, y, test_size=validation_size, random_state=42
            )

        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_val_scaled = self.scaler.transform(X_val)

        if IMB_AVAILABLE and use_smote and np.sum(y_train) > 0:
            try:
                smote = SMOTE(random_state=42)
                X_train_res, y_train_res = smote.fit_resample(X_train_scaled, y_train)
                print(f"📊 بعد SMOTE: {X_train_res.shape[0]} عينة متوازنة")
                X_train_scaled = X_train_res
                y_train = y_train_res
            except Exception as e:
                print(f"⚠️  فشل SMOTE: {e}")

        combos = [
            ['denoise', 'rf'],
            ['denoise', 'xgboost'],
            ['denoise', 'stacking'],
            ['denoise', 'feature_select', 'rf'],
            ['denoise', 'feature_select', 'xgboost'],
            ['denoise', 'feature_select', 'stacking']
        ]

        print("\n🧪 اختيار أفضل عقدة...")
        scores = []
        for combo in combos:
            f1, roc = self._validate_combo(X_train_scaled, y_train, X_val_scaled, y_val, combo)
            scores.append((combo, f1, roc))
            print(f"   - {combo} → F1={f1:.4f}, ROC-AUC={roc:.4f}")

        best_combo, best_f1, best_roc = max(scores, key=lambda x: x[1])
        self.active_nodes = best_combo
        print(f"✅ تم اختيار العقد: {best_combo} (F1={best_f1:.4f}, ROC-AUC={best_roc:.4f})")

        X_full = np.vstack([X_train_scaled, X_val_scaled])
        y_full = np.hstack([y_train, y_val])

        X_curr = X_full.copy()
        for name in self.active_nodes:
            node = self.nodes[name]
            if name == 'denoise':
                X_curr = node.fit_transform(X_curr)
            elif name == 'feature_select':
                X_curr = node.fit_transform(X_curr, y_full)
            else:
                node.fit(X_curr, y_full)

        self.best_threshold = self._find_best_threshold(X_val_scaled, y_val, self.active_nodes)
        self.training_time = time.time() - start_time
        print(f"⏱️  وقت التدريب: {self.training_time:.2f} ثانية")
        print(f"🎯 العتبة المثلى: {self.best_threshold:.3f}")
        return self

    def predict_proba(self, X):
        X_scaled = self.scaler.transform(X)
        X_curr = X_scaled.copy()
        for name in self.active_nodes:
            node = self.nodes[name]
            if name == 'denoise':
                X_curr = node.transform(X_curr)
            elif name == 'feature_select':
                X_curr = node.transform(X_curr)
            else:
                return node.predict_proba(X_curr)
        return np.ones(X.shape[0]) * 0.5

    def predict(self, X, threshold=None):
        if threshold is None:
            threshold = self.best_threshold
        proba = self.predict_proba(X)
        return (proba >= threshold).astype(int)

    def save(self, path="neoamona_core_model.pkl"):
        with open(path, 'wb') as f:
            pickle.dump(self, f)
        return path

    @staticmethod
    def load(path="neoamona_core_model.pkl"):
        with open(path, 'rb') as f:
            return pickle.load(f)