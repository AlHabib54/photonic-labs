# -*- coding: utf-8 -*-
"""
NeoAMONA Enterprise Server - نسخة متكاملة مع معالجة البيانات وواجهة كاملة
"""

import pickle
import numpy as np
import pandas as pd
import io
import os
from typing import List, Optional
from fastapi import FastAPI, UploadFile, File, HTTPException, Header
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from sklearn.preprocessing import LabelEncoder
import uvicorn
import warnings
warnings.filterwarnings('ignore')

try:
    from neoamona_core import NeoAMONACore
except ImportError:
    print("⚠️  neoamona_core.py not found")
    exit(1)

# ============================================================
# 1. نظام الاشتراكات
# ============================================================

TIER_LIMITS = {
    "free": {"max_rows": 1000, "name": "Freemium", "color": "#94a3b8"},
    "pro": {"max_rows": 100000, "name": "Professional", "color": "#818cf8"}
}

MOCK_API_KEYS = {
    "free_key_123": "free",
    "pro_key_789": "pro"
}

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

MODEL_PATH = "models/neoamona_core_model.pkl"
model = None

@app.on_event("startup")
async def load_model():
    global model
    if os.path.exists(MODEL_PATH):
        model = NeoAMONACore.load(MODEL_PATH)
        print(f"✅ Model loaded")
    else:
        print(f"⚠️  Model not found")

def validate_key(api_key: str) -> str:
    if api_key not in MOCK_API_KEYS:
        raise HTTPException(401, "Invalid API key")
    return MOCK_API_KEYS[api_key]

# ============================================================
# 2. دالة تنظيف البيانات المحسنة
# ============================================================

def clean_data(df: pd.DataFrame, target_col: Optional[str] = None):
    """
    تنظيف البيانات بشكل قوي:
    - تحويل الأعمدة النصية إلى أرقام باستخدام LabelEncoder
    - معالجة القيم المفقودة (NaN) باستبدالها بالمتوسط
    - إزالة الأعمدة التي تحتوي على قيم غير قابلة للتحويل
    """
    # 1. التعامل مع العمود الهدف
    y = None
    if target_col and target_col in df.columns:
        y_raw = df[target_col].values
        # محاولة تحويل الهدف إلى 0/1
        try:
            y = np.array([0 if str(v).strip().upper() == 'BENIGN' or v == 0 else 1 for v in y_raw])
        except:
            y = np.array([0 if str(v).strip() == 'normal' or v == 0 else 1 for v in y_raw])
        X_raw = df.drop(columns=[target_col])
    else:
        X_raw = df.copy()

    # 2. معالجة كل عمود
    X_clean = []
    for col_name in X_raw.columns:
        col = X_raw[col_name]

        # 2a. إذا كان العمود نصياً، نحوله إلى أرقام باستخدام LabelEncoder
        if col.dtype == 'object' or col.dtype.name == 'category':
            try:
                le = LabelEncoder()
                # معالجة القيم المفقودة في الأعمدة النصية
                col_filled = col.fillna('missing').astype(str)
                col_encoded = le.fit_transform(col_filled)
                X_clean.append(col_encoded.astype(float))
                continue
            except:
                # إذا فشل الترميز، نتجاوز العمود
                print(f"⚠️  Skipping column {col_name} (text encoding failed)")
                continue

        # 2b. تحويل إلى أرقام
        try:
            col_numeric = pd.to_numeric(col, errors='coerce')
        except:
            print(f"⚠️  Skipping column {col_name} (conversion failed)")
            continue

        # 2c. معالجة القيم المفقودة (NaN)
        mean_val = np.nanmean(col_numeric)
        if np.isnan(mean_val):
            mean_val = 0.0
        col_filled = np.nan_to_num(col_numeric, nan=mean_val)

        # 2d. إزالة القيم اللانهائية
        col_filled = np.clip(col_filled, -1e6, 1e6)
        X_clean.append(col_filled.astype(float))

    # 3. تجميع الأعمدة
    if len(X_clean) == 0:
        raise ValueError("No valid columns found in the data")

    X_final = np.column_stack(X_clean)

    # 4. معالجة أي قيم NaN متبقية (كحل أخير)
    X_final = np.nan_to_num(X_final, nan=0.0)

    return X_final, y

# ============================================================
# 3. HTML مع واجهة كاملة (اختيار مفتاح، ترقية، حدود)
# ============================================================

HTML_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NeoAMONA Enterprise</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #0f172a; color: #e2e8f0; padding: 20px; margin: 0; }
        .container { max-width: 1100px; margin: 0 auto; }
        .header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 20px; }
        .logo { font-size: 28px; font-weight: bold; color: #818cf8; }
        .badge { background: #334155; padding: 6px 16px; border-radius: 50px; font-size: 13px; color: #94a3b8; display: inline-block; }
        .badge-pro { background: rgba(99,102,241,0.2); color: #818cf8; }
        .card { background: #1e293b; border-radius: 16px; padding: 24px; margin: 16px 0; box-shadow: 0 4px 20px rgba(0,0,0,0.3); }
        .card h2 { color: #818cf8; margin-top: 0; font-size: 20px; }
        .stats { display: flex; gap: 16px; flex-wrap: wrap; }
        .stat { background: #0f172a; padding: 12px 24px; border-radius: 12px; flex: 1; min-width: 100px; text-align: center; }
        .stat .num { font-size: 28px; font-weight: bold; }
        .stat .lbl { color: #94a3b8; font-size: 14px; }
        .upload-zone { border: 2px dashed #334155; border-radius: 16px; padding: 40px 20px; text-align: center; cursor: pointer; transition: 0.3s; }
        .upload-zone:hover { border-color: #818cf8; background: rgba(99,102,241,0.05); }
        .upload-zone.dragover { border-color: #22c55e; background: rgba(34,197,94,0.05); }
        .upload-zone input[type="file"] { display: none; }
        .upload-zone .icon { font-size: 40px; }
        .feature-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(48px, 1fr)); gap: 4px; margin: 12px 0; }
        .feature-grid input { width: 100%; padding: 4px; text-align: center; border-radius: 6px; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; font-size: 12px; }
        .btn { background: #818cf8; border: none; color: #0f172a; padding: 10px 24px; border-radius: 8px; font-weight: bold; cursor: pointer; transition: 0.3s; }
        .btn:hover { background: #6366f1; }
        .btn-secondary { background: transparent; border: 1px solid #334155; color: #e2e8f0; }
        .btn-secondary:hover { background: #334155; }
        .btn-upgrade { background: #f59e0b; color: #0f172a; }
        .btn-upgrade:hover { background: #d97706; }
        .flex { display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }
        .mt-2 { margin-top: 16px; }
        .text-muted { color: #94a3b8; font-size: 14px; }
        .result-box { padding: 12px; border-radius: 8px; margin-top: 12px; }
        .result-box.success { background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); }
        .result-box.danger { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); }
        .log { background: #0f172a; padding: 12px; border-radius: 8px; max-height: 200px; overflow-y: auto; }
        .log div { padding: 4px 0; border-bottom: 1px solid #1e293b; font-size: 13px; }
        .toast { position: fixed; bottom: 20px; right: 20px; background: #1e293b; padding: 12px 24px; border-radius: 12px; border-left: 4px solid #818cf8; max-width: 400px; z-index: 999; }
        .toast.error { border-left-color: #ef4444; }
        .toast.success { border-left-color: #22c55e; }
        .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); justify-content: center; align-items: center; z-index: 1000; }
        .modal-overlay.active { display: flex; }
        .modal { background: #1e293b; padding: 32px; border-radius: 16px; max-width: 450px; width: 90%; border: 1px solid #334155; }
        .modal .plan { background: #0f172a; padding: 16px; border-radius: 12px; text-align: center; border: 1px solid #334155; margin: 8px 0; }
        .modal .plan:hover { border-color: #818cf8; }
        .modal .plan .price { font-size: 24px; font-weight: bold; color: #818cf8; }
        .modal .plan .name { font-weight: bold; font-size: 18px; }
        .modal .plan ul { list-style: none; padding: 0; font-size: 13px; color: #94a3b8; }
        input[type="text"], input[type="password"] { padding: 8px 12px; border-radius: 8px; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; width: 100%; }
        select { padding: 8px 12px; border-radius: 8px; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; }
        .key-selector { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
        .key-selector select { flex: 1; min-width: 180px; }
        @media (max-width: 600px) { .stats { flex-direction: column; } .feature-grid { grid-template-columns: repeat(8, 1fr); } }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="logo">🛡️ NeoAMONA</div>
        <div>
            <span class="badge" id="tierBadge">🔓 Freemium</span>
            <span class="badge" id="reqBadge" style="margin-left:8px;">Requests: 10</span>
        </div>
    </div>

    <!-- مفتاح API وزر الترقية -->
    <div class="card">
        <div class="key-selector">
            <div style="flex:1;">
                <label style="color:#94a3b8; font-size:14px;">🔑 API Key</label>
                <select id="apiKeySelect">
                    <option value="free_key_123">Free Key (Freemium)</option>
                    <option value="pro_key_789">Pro Key (Professional)</option>
                </select>
            </div>
            <div>
                <label style="color:#94a3b8; font-size:14px;">&nbsp;</label>
                <button class="btn btn-upgrade" onclick="openUpgradeModal()">⬆️ Upgrade</button>
            </div>
        </div>
        <div style="margin-top:8px; font-size:13px; color:#94a3b8;">
            💡 Current plan: <span id="currentPlanDisplay">Freemium</span> · Max rows: <span id="maxRowsDisplay">1,000</span>
        </div>
    </div>

    <!-- Stats -->
    <div class="stats" id="stats">
        <div class="stat"><div class="num" id="statTotal">0</div><div class="lbl">Total Rows</div></div>
        <div class="stat"><div class="num" style="color:#ef4444;" id="statAttacks">0</div><div class="lbl">Attacks</div></div>
        <div class="stat"><div class="num" style="color:#22c55e;" id="statNormal">0</div><div class="lbl">Normal</div></div>
        <div class="stat"><div class="num" style="color:#f59e0b;" id="statRatio">0%</div><div class="lbl">Attack Ratio</div></div>
    </div>

    <!-- Upload -->
    <div class="card">
        <h2>📤 Upload CSV</h2>
        <div class="upload-zone" id="uploadZone">
            <div class="icon">📁</div>
            <p><strong>Drop CSV here</strong> or click to browse</p>
            <p class="text-muted">Max rows: <span id="maxRowsDisplay2">1,000</span></p>
            <input type="file" id="fileInput" accept=".csv">
            <div style="margin-top:12px;">
                <input type="text" id="targetCol" placeholder="Target column (optional)" style="width:200px; display:inline-block;">
            </div>
        </div>
        <div id="uploadProgress" style="display:none; margin-top:12px;">
            <p class="text-muted">Analyzing...</p>
            <div style="height:4px; background:#334155; border-radius:4px; overflow:hidden;">
                <div style="width:100%; height:100%; background:#818cf8;"></div>
            </div>
        </div>
        <div id="uploadResult" class="mt-2"></div>
    </div>

    <!-- Predict -->
    <div class="card">
        <h2>⚡ Single Prediction</h2>
        <p class="text-muted">Enter 41 numeric features</p>
        <div class="feature-grid" id="featureGrid"></div>
        <div class="flex mt-2">
            <button class="btn" id="predictBtn">Predict</button>
            <button class="btn btn-secondary" id="randomBtn">🎲 Random</button>
        </div>
        <div id="predictResult" class="mt-2"></div>
    </div>

    <!-- Log -->
    <div class="card">
        <h2>📋 Activity Log</h2>
        <div class="log" id="logContainer"><div class="text-muted" style="text-align:center;">No activity yet.</div></div>
    </div>
</div>

<!-- Upgrade Modal -->
<div class="modal-overlay" id="upgradeModal">
    <div class="modal">
        <h2>⬆️ Upgrade to Professional</h2>
        <div class="plan">
            <div class="name">Professional</div>
            <div class="price">$999</div>
            <ul>
                <li>✅ 100,000 rows per upload</li>
                <li>✅ 1,000 API requests / day</li>
                <li>✅ Threshold tuning</li>
                <li>✅ CSV report export</li>
                <li>✅ Priority support</li>
            </ul>
        </div>
        <div style="margin:16px 0;">
            <label style="color:#94a3b8;">Payment Token</label>
            <input type="text" id="paymentToken" placeholder="Enter payment token" value="demo_payment">
            <div style="font-size:12px; color:#94a3b8; margin-top:4px;">🔑 Use <code>demo_payment</code> for testing</div>
        </div>
        <div class="flex" style="justify-content:flex-end;">
            <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
            <button class="btn btn-upgrade" onclick="confirmUpgrade()">Confirm Upgrade</button>
        </div>
    </div>
</div>

<div id="toastContainer" style="position:fixed; bottom:20px; right:20px; z-index:999;"></div>

<script>
// ============================================================
// State
// ============================================================
let state = {
    apiKey: 'free_key_123',
    tier: 'free',
    limits: { free: 1000, pro: 100000 },
    names: { free: 'Freemium', pro: 'Professional' }
};

// ============================================================
// DOM References
// ============================================================
const tierBadge = document.getElementById('tierBadge');
const reqBadge = document.getElementById('reqBadge');
const maxRowsDisplay = document.getElementById('maxRowsDisplay');
const maxRowsDisplay2 = document.getElementById('maxRowsDisplay2');
const currentPlanDisplay = document.getElementById('currentPlanDisplay');
const apiKeySelect = document.getElementById('apiKeySelect');
const uploadZone = document.getElementById('uploadZone');
const fileInput = document.getElementById('fileInput');
const targetCol = document.getElementById('targetCol');
const uploadProgress = document.getElementById('uploadProgress');
const uploadResult = document.getElementById('uploadResult');
const featureGrid = document.getElementById('featureGrid');
const predictBtn = document.getElementById('predictBtn');
const randomBtn = document.getElementById('randomBtn');
const predictResult = document.getElementById('predictResult');
const logContainer = document.getElementById('logContainer');
const upgradeModal = document.getElementById('upgradeModal');
const paymentToken = document.getElementById('paymentToken');
const toastContainer = document.getElementById('toastContainer');

// ============================================================
// Create feature grid (41 fields)
// ============================================================
for (let i = 0; i < 41; i++) {
    let inp = document.createElement('input');
    inp.type = 'number';
    inp.value = '0';
    inp.step = 'any';
    inp.id = 'f'+i;
    inp.placeholder = i;
    featureGrid.appendChild(inp);
}

// ============================================================
// UI Update Functions
// ============================================================
function updateTier(tier) {
    state.tier = tier;
    tierBadge.textContent = '🔓 ' + state.names[tier];
    currentPlanDisplay.textContent = state.names[tier];
    const limit = state.limits[tier];
    maxRowsDisplay.textContent = limit === Infinity ? '∞' : limit;
    maxRowsDisplay2.textContent = limit === Infinity ? '∞' : limit;
    const reqs = tier === 'free' ? 10 : tier === 'pro' ? 1000 : '∞';
    reqBadge.textContent = 'Requests: ' + reqs;

    // Update API key select if needed
    if (tier === 'pro') {
        apiKeySelect.value = 'pro_key_789';
        state.apiKey = 'pro_key_789';
    } else {
        apiKeySelect.value = 'free_key_123';
        state.apiKey = 'free_key_123';
    }
}

function showToast(msg, type='info') {
    let div = document.createElement('div');
    div.className = 'toast ' + type;
    div.textContent = msg;
    toastContainer.appendChild(div);
    setTimeout(() => { div.style.opacity = '0'; setTimeout(() => div.remove(), 300); }, 4000);
}

function addLog(msg) {
    let placeholder = logContainer.querySelector('.text-muted');
    if (placeholder) placeholder.remove();
    let div = document.createElement('div');
    let time = new Date().toLocaleTimeString();
    div.innerHTML = '<span style="color:#94a3b8;">['+time+']</span> '+msg;
    logContainer.prepend(div);
}

function updateStats(data) {
    document.getElementById('statTotal').textContent = data.total_rows || 0;
    document.getElementById('statAttacks').textContent = data.attacks_detected || 0;
    document.getElementById('statNormal').textContent = data.normal_count || 0;
    document.getElementById('statRatio').textContent = data.attack_ratio || '0%';
}

// ============================================================
// API Key Selector
// ============================================================
apiKeySelect.addEventListener('change', function() {
    state.apiKey = this.value;
    const tier = this.value === 'free_key_123' ? 'free' : 'pro';
    updateTier(tier);
    showToast('🔑 Switched to ' + state.names[tier], 'info');
    addLog('🔑 API key changed to ' + tier);
});

// ============================================================
// Upgrade Modal
// ============================================================
function openUpgradeModal() {
    upgradeModal.classList.add('active');
    paymentToken.value = 'demo_payment';
}

function closeModal() {
    upgradeModal.classList.remove('active');
}

function confirmUpgrade() {
    const token = paymentToken.value.trim();
    if (token === 'demo_payment') {
        state.apiKey = 'pro_key_789';
        updateTier('pro');
        showToast('✅ Upgraded to Professional!', 'success');
        addLog('⬆️ Upgraded to Professional plan');
        closeModal();
        reqBadge.textContent = 'Requests: ∞';
        // Also update the select
        apiKeySelect.value = 'pro_key_789';
    } else {
        showToast('❌ Invalid payment token. Use "demo_payment" for testing.', 'error');
    }
}

// Close modal on outside click
upgradeModal.addEventListener('click', (e) => {
    if (e.target === upgradeModal) closeModal();
});

// ============================================================
// File Upload Handler
// ============================================================
async function uploadFile(file) {
    if (!file) return;

    let reader = new FileReader();
    reader.onload = async function(e) {
        let lines = e.target.result.split('\\n').filter(l => l.trim() !== '');
        let rows = lines.length - 1;
        let limit = state.limits[state.tier];
        if (rows > limit && limit !== Infinity) {
            showToast('❌ Your tier allows only '+limit+' rows. Upgrade to Pro.', 'error');
            return;
        }

        let formData = new FormData();
        formData.append('file', file);
        let tc = targetCol.value.trim();
        if (tc) formData.append('target_column', tc);

        uploadProgress.style.display = 'block';
        uploadResult.innerHTML = '';

        try {
            let resp = await fetch('/api/upload', {
                method: 'POST',
                headers: { 'x-api-key': state.apiKey },
                body: formData
            });
            let data = await resp.json();
            if (!resp.ok) {
                showToast('❌ ' + (data.detail || 'Upload failed'), 'error');
                uploadProgress.style.display = 'none';
                return;
            }
            updateStats(data);
            addLog('✅ Uploaded '+file.name+': '+data.attacks_detected+' attacks, '+data.normal_count+' normal');
            showToast('✅ File analyzed successfully!', 'success');
            uploadResult.innerHTML = '<div style="background:rgba(34,197,94,0.1); padding:12px; border-radius:8px; border:1px solid rgba(34,197,94,0.3);">'+
                '<strong>'+data.total_rows+'</strong> rows · <strong>'+data.attacks_detected+'</strong> attacks · <strong>'+data.normal_count+'</strong> normal'+
                (data.download_url ? '<br><a href="'+data.download_url+'" style="color:#818cf8;">Download Report</a>' : '')+
                '</div>';
            if (data.remaining_requests !== undefined) {
                reqBadge.textContent = 'Requests: '+data.remaining_requests;
            }
        } catch(err) {
            showToast('❌ Connection error: '+err.message, 'error');
            console.error(err);
        }
        uploadProgress.style.display = 'none';
    };
    reader.readAsText(file);
}

// ============================================================
// Drag & Drop
// ============================================================
uploadZone.addEventListener('click', () => fileInput.click());

uploadZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadZone.classList.add('dragover');
});

uploadZone.addEventListener('dragleave', () => {
    uploadZone.classList.remove('dragover');
});

uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.classList.remove('dragover');
    if (e.dataTransfer.files.length) {
        uploadFile(e.dataTransfer.files[0]);
    }
});

fileInput.addEventListener('change', () => {
    if (fileInput.files.length) {
        uploadFile(fileInput.files[0]);
    }
});

// ============================================================
// Prediction
// ============================================================
predictBtn.addEventListener('click', async function() {
    let feats = [];
    for (let i=0; i<41; i++) {
        let v = parseFloat(document.getElementById('f'+i).value);
        feats.push(isNaN(v) ? 0 : v);
    }
    try {
        let resp = await fetch('/api/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': state.apiKey
            },
            body: JSON.stringify({ features: feats })
        });
        let data = await resp.json();
        if (!resp.ok) {
            showToast('❌ ' + (data.detail || 'Prediction failed'), 'error');
            return;
        }
        let cls = data.prediction === 'Attack' ? 'danger' : 'success';
        predictResult.innerHTML = '<div class="result-box '+cls+'"><strong>'+data.prediction+'</strong> · Probability: '+(data.probability*100).toFixed(2)+'%<br><span class="text-muted">Threshold: '+data.threshold_used+'</span></div>';
        addLog('🔮 Prediction: '+data.prediction+' ('+(data.probability*100).toFixed(2)+'%)');
        if (data.remaining_requests !== undefined) {
            reqBadge.textContent = 'Requests: '+data.remaining_requests;
        }
    } catch(err) {
        showToast('❌ Connection error: '+err.message, 'error');
        console.error(err);
    }
});

// Random fill
randomBtn.addEventListener('click', () => {
    for (let i=0; i<41; i++) {
        document.getElementById('f'+i).value = (Math.random()*10).toFixed(2);
    }
});

// ============================================================
// Initialization
// ============================================================
updateTier('free');
addLog('🚀 NeoAMONA ready. Upload CSV or try prediction.');
console.log('✅ NeoAMONA loaded');
</script>
</body>
</html>
"""

# ============================================================
# 4. نقاط النهاية (Endpoints)
# ============================================================

@app.get("/", response_class=HTMLResponse)
async def root():
    return HTML_PAGE

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard():
    return HTML_PAGE

@app.get("/health")
async def health():
    return {"status": "ok", "model_loaded": model is not None}

@app.post("/api/predict")
async def predict(
    features: List[float],
    threshold: Optional[float] = None,
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(503, "Model not loaded")
    tier = validate_key(x_api_key)
    th = threshold if threshold is not None else model.best_threshold
    X = np.array(features).reshape(1, -1)
    proba = model.predict_proba(X)[0]
    pred = int(proba >= th)
    return {
        "prediction": "Attack" if pred else "Normal",
        "probability": float(proba),
        "threshold_used": float(th),
        "tier": tier,
        "remaining_requests": 999
    }

@app.post("/api/upload")
async def upload_file(
    file: UploadFile = File(...),
    target_column: Optional[str] = None,
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(503, "Model not loaded")
    tier = validate_key(x_api_key)
    contents = await file.read()
    df = pd.read_csv(io.BytesIO(contents))
    if df.empty:
        raise HTTPException(400, "Empty file")
    limit = 1000 if tier == "free" else 100000
    if df.shape[0] > limit:
        raise HTTPException(403, f"Row limit exceeded. Your tier allows {limit} rows.")

    # معالجة البيانات المحسنة
    try:
        X, y_true = clean_data(df, target_column)
    except Exception as e:
        raise HTTPException(400, f"Data cleaning error: {str(e)}")

    # التحقق من أن X يحتوي على بيانات صالحة
    if X.shape[0] == 0 or X.shape[1] == 0:
        raise HTTPException(400, "No valid features found in the data")

    proba = model.predict_proba(X)
    y_pred = (proba >= model.best_threshold).astype(int)
    attacks = int(np.sum(y_pred))
    normal = len(y_pred) - attacks
    attack_ratio = f"{attacks/len(y_pred)*100:.2f}%" if len(y_pred) > 0 else "0%"

    # حساب مصفوفة الارتباك إن وجدت
    confusion = None
    if y_true is not None:
        from sklearn.metrics import confusion_matrix
        try:
            cm = confusion_matrix(y_true, y_pred)
            confusion = {
                "tn": int(cm[0, 0]) if cm.shape == (2, 2) else 0,
                "fp": int(cm[0, 1]) if cm.shape == (2, 2) else 0,
                "fn": int(cm[1, 0]) if cm.shape == (2, 2) else 0,
                "tp": int(cm[1, 1]) if cm.shape == (2, 2) else 0
            }
        except:
            pass

    return {
        "status": "success",
        "tier": tier,
        "total_rows": X.shape[0],
        "attacks_detected": attacks,
        "normal_count": normal,
        "attack_ratio": attack_ratio,
        "confusion_matrix": confusion,
        "remaining_requests": 999,
        "download_url": None
    }

# ============================================================
# 5. تشغيل الخادم
# ============================================================

if __name__ == "__main__":
    print("="*50)
    print("🚀 NeoAMONA Server (with Upgrade & API Key)")
    print("="*50)
    uvicorn.run("neoamona_server:app", host="0.0.0.0", port=8080, reload=False)