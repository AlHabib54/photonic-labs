# ==========================================================
# optical_8bit_alu_v1.py
# Verified Optical 8-Bit ALU V1
# Stable + Defensive + Low Execution Risk
# Built only on verified modules
# ==========================================================

import matplotlib.pyplot as plt


# ==========================================================
# VERIFIED LOGIC GATES
# ==========================================================

def optical_and(a, b):
    return a & b


def optical_or(a, b):
    return a | b


def optical_xor(a, b):
    return a ^ b


# ==========================================================
# VERIFIED FULL ADDER
# ==========================================================

def optical_full_adder(a, b, cin):

    xor1 = optical_xor(a, b)

    sum_bit = optical_xor(
        xor1,
        cin
    )

    and1 = optical_and(a, b)
    and2 = optical_and(cin, xor1)

    carry = optical_or(
        and1,
        and2
    )

    return sum_bit, carry


# ==========================================================
# VERIFIED 8-BIT ADDER
# ==========================================================

def optical_8bit_adder(a_bits, b_bits):

    if len(a_bits) != 8:
        raise ValueError(
            "A input must be 8 bits"
        )

    if len(b_bits) != 8:
        raise ValueError(
            "B input must be 8 bits"
        )

    result = [0] * 8
    carry_history = [0] * 8

    carry = 0

    # LSB → MSB
    for i in range(7, -1, -1):

        result[i], carry = (
            optical_full_adder(
                a_bits[i],
                b_bits[i],
                carry
            )
        )

        carry_history[i] = carry

    return (
        result,
        carry,
        carry_history
    )


# ==========================================================
# HELPERS
# ==========================================================

def validate_bits(bits):

    if len(bits) != 8:
        raise ValueError(
            "Input must be 8 bits"
        )

    for bit in bits:

        if bit not in [0, 1]:
            raise ValueError(
                "Bits must contain only 0 or 1"
            )


def bits_to_decimal(bits):

    return int(
        "".join(map(str, bits)),
        2
    )


# ==========================================================
# TEST INPUTS
# ==========================================================

# Example:
# A = 11001101 = 205
# B = 01100110 = 102

A = [1,1,0,0,1,1,0,1]
B = [0,1,1,0,0,1,1,0]

validate_bits(A)
validate_bits(B)

# ==========================================================
# MODE SELECT
# ==========================================================

# 00 = AND
# 01 = OR
# 10 = XOR
# 11 = ADD

MODE = "11"

# ==========================================================
# EXECUTION
# ==========================================================

try:

    result = []
    carry_out = 0
    operation_name = ""

    # ------------------------------------------------------
    # AND
    # ------------------------------------------------------

    if MODE == "00":

        operation_name = "AND"

        result = [

            optical_and(
                A[i],
                B[i]
            )

            for i in range(8)
        ]

    # ------------------------------------------------------
    # OR
    # ------------------------------------------------------

    elif MODE == "01":

        operation_name = "OR"

        result = [

            optical_or(
                A[i],
                B[i]
            )

            for i in range(8)
        ]

    # ------------------------------------------------------
    # XOR
    # ------------------------------------------------------

    elif MODE == "10":

        operation_name = "XOR"

        result = [

            optical_xor(
                A[i],
                B[i]
            )

            for i in range(8)
        ]

    # ------------------------------------------------------
    # ADD
    # ------------------------------------------------------

    elif MODE == "11":

        operation_name = "ADD"

        (
            result,
            carry_out,
            carry_history
        ) = optical_8bit_adder(
            A,
            B
        )

    else:

        raise ValueError(
            "Invalid ALU mode"
        )

    # ======================================================
    # FORMAT OUTPUT
    # ======================================================

    binary_A = "".join(
        map(str, A)
    )

    binary_B = "".join(
        map(str, B)
    )

    binary_result = "".join(
        map(str, result)
    )

    if MODE == "11":

        binary_result = (
            str(carry_out)
            + binary_result
        )

    decimal_A = bits_to_decimal(A)
    decimal_B = bits_to_decimal(B)

    # ======================================================
    # EXPECTED RESULT
    # ======================================================

    if MODE == "00":

        expected = (
            decimal_A
            & decimal_B
        )

    elif MODE == "01":

        expected = (
            decimal_A
            | decimal_B
        )

    elif MODE == "10":

        expected = (
            decimal_A
            ^ decimal_B
        )

    else:

        expected = (
            decimal_A
            + decimal_B
        )

    result_decimal = int(
        binary_result,
        2
    )

    status = (

        "PASS"

        if result_decimal
        == expected

        else "FAIL"
    )

    # ======================================================
    # REPORT
    # ======================================================

    print("")
    print("=" * 50)

    print(
        "OPTICAL 8-BIT ALU V1 REPORT"
    )

    print("=" * 50)

    print("")

    print(
        "MODE =",
        MODE
    )

    print(
        "OPERATION =",
        operation_name
    )

    print("")

    print(
        "INPUT A =",
        binary_A
    )

    print(
        "INPUT B =",
        binary_B
    )

    print("")

    print(
        "OUTPUT =",
        binary_result
    )

    if MODE == "11":

        print(
            "CARRY OUT =",
            carry_out
        )

    print("")

    print(
        "DECIMAL A =",
        decimal_A
    )

    print(
        "DECIMAL B =",
        decimal_B
    )

    print(
        "EXPECTED =",
        expected
    )

    print(
        "RESULT =",
        result_decimal
    )

    print("")

    print(
        "STATUS =",
        status
    )

    # ======================================================
    # VISUALIZATION
    # ======================================================

    plot_bits = list(
        map(int, binary_result)
    )

    labels = []

    for i in range(
        len(plot_bits)
    ):

        labels.append(
            f"Bit{i}"
        )

    plt.figure(
        figsize=(12,5)
    )

    plt.bar(
        labels,
        plot_bits
    )

    plt.ylim(0, 1.1)

    plt.ylabel(
        "Logic Output"
    )

    plt.title(
        f"Optical 8-Bit ALU V1 ({operation_name})"
    )

    plt.show()

except Exception as e:

    print("")
    print(
        "EXECUTION ERROR:"
    )

    print(str(e))
