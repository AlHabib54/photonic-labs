# -*- coding: utf-8 -*-
"""
NeoAMONA Enterprise Server - Simplified & Reliable (v4.0)
"""

import pickle
import numpy as np
import pandas as pd
import io
import os
import time
import uuid
from typing import List, Optional
from collections import Counter
import warnings
warnings.filterwarnings('ignore')

from fastapi import FastAPI, UploadFile, File, HTTPException, Header, Form
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# استيراد قلب الخوارزمية
try:
    from neoamona_core import NeoAMONACore
except ImportError:
    print("⚠️  neoamona_core.py not found. Make sure it's in the backend directory.")
    exit(1)

# ============================================================
# 1. نظام الاشتراكات
# ============================================================

TIER_LIMITS = {
    "free": {"max_rows": 1000, "name": "Freemium"},
    "basic": {"max_rows": 10000, "name": "Basic"},
    "pro": {"max_rows": 100000, "name": "Professional"},
    "enterprise": {"max_rows": float('inf'), "name": "Enterprise"}
}

MOCK_API_KEYS = {
    "free_key_123": "free",
    "basic_key_456": "basic",
    "pro_key_789": "pro",
    "enterprise_key_000": "enterprise"
}

request_counter = {tier: 0 for tier in TIER_LIMITS}

# ============================================================
# 2. التطبيق
# ============================================================

app = FastAPI(title="NeoAMONA Enterprise")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

MODEL_PATH = "models/neoamona_core_model.pkl"
model = None

@app.on_event("startup")
async def load_model():
    global model
    if os.path.exists(MODEL_PATH):
        model = NeoAMONACore.load(MODEL_PATH)
        print(f"✅ Model loaded from {MODEL_PATH}")
    else:
        print(f"⚠️  Model not found at {MODEL_PATH}")

# ============================================================
# 3. دوال المساعدة
# ============================================================

def validate_key(api_key: str) -> str:
    if api_key not in MOCK_API_KEYS:
        raise HTTPException(401, "Invalid API key")
    return MOCK_API_KEYS[api_key]

def check_limits(tier: str, rows: int = 0):
    limit = TIER_LIMITS[tier]["max_rows"]
    if rows > limit:
        raise HTTPException(403, f"Row limit exceeded. Your tier allows {limit} rows.")
    if request_counter[tier] >= 1000:
        raise HTTPException(429, "Daily request limit exceeded")
    request_counter[tier] += 1

def clean_data(df: pd.DataFrame, target_col: Optional[str] = None):
    y = None
    if target_col and target_col in df.columns:
        y_raw = df[target_col].values
        y = np.array([0 if str(v).strip().upper() == 'BENIGN' or v == 0 else 1 for v in y_raw])
        X_raw = df.drop(columns=[target_col]).values
    else:
        X_raw = df.values
    X_clean = []
    for i in range(X_raw.shape[1]):
        col = pd.to_numeric(X_raw[:, i], errors='coerce')
        mean = np.nanmean(col)
        col = np.nan_to_num(col, nan=mean)
        X_clean.append(col)
    X_final = np.column_stack(X_clean).astype(float)
    return X_final, y

# ============================================================
# 4. HTML الرئيسي (بسيط ومضمون)
# ============================================================

HTML_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NeoAMONA</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #0f172a; color: #e2e8f0; padding: 20px; margin: 0; }
        .container { max-width: 1100px; margin: 0 auto; }
        .header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; }
        .logo { font-size: 28px; font-weight: bold; color: #818cf8; }
        .badge { background: #334155; padding: 4px 14px; border-radius: 50px; font-size: 13px; color: #94a3b8; }
        .badge.pro { background: rgba(99,102,241,0.2); color: #818cf8; }
        .card { background: #1e293b; border-radius: 16px; padding: 24px; margin: 20px 0; box-shadow: 0 4px 20px rgba(0,0,0,0.3); }
        .card h2 { color: #818cf8; margin-top: 0; font-size: 20px; }
        .stats { display: flex; gap: 16px; flex-wrap: wrap; }
        .stat { background: #0f172a; padding: 12px 24px; border-radius: 12px; flex: 1; min-width: 100px; text-align: center; }
        .stat .num { font-size: 28px; font-weight: bold; }
        .stat .lbl { color: #94a3b8; font-size: 14px; }
        .upload-zone { border: 2px dashed #334155; border-radius: 16px; padding: 40px 20px; text-align: center; cursor: pointer; transition: 0.3s; }
        .upload-zone:hover { border-color: #818cf8; background: rgba(99,102,241,0.05); }
        .upload-zone.dragover { border-color: #22c55e; background: rgba(34,197,94,0.05); }
        .upload-zone input[type="file"] { display: none; }
        .upload-zone .icon { font-size: 40px; }
        .feature-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(48px, 1fr)); gap: 4px; margin: 12px 0; }
        .feature-grid input { width: 100%; padding: 4px; text-align: center; border-radius: 6px; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; font-size: 12px; }
        .btn { background: #818cf8; border: none; color: #0f172a; padding: 10px 24px; border-radius: 8px; font-weight: bold; cursor: pointer; transition: 0.3s; }
        .btn:hover { background: #6366f1; }
        .btn-secondary { background: transparent; border: 1px solid #334155; color: #e2e8f0; }
        .btn-secondary:hover { background: #334155; }
        .flex { display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }
        .mt-2 { margin-top: 16px; }
        .text-muted { color: #94a3b8; font-size: 14px; }
        .result-box { padding: 12px; border-radius: 8px; margin-top: 12px; }
        .result-box.success { background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); }
        .result-box.danger { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); }
        .log { background: #0f172a; padding: 12px; border-radius: 8px; max-height: 200px; overflow-y: auto; }
        .log div { padding: 4px 0; border-bottom: 1px solid #1e293b; font-size: 13px; }
        .toast { position: fixed; bottom: 20px; right: 20px; background: #1e293b; padding: 12px 24px; border-radius: 12px; border-left: 4px solid #818cf8; max-width: 400px; z-index: 999; }
        .toast.error { border-left-color: #ef4444; }
        .toast.success { border-left-color: #22c55e; }
        .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); justify-content: center; align-items: center; z-index: 1000; }
        .modal-overlay.active { display: flex; }
        .modal { background: #1e293b; padding: 32px; border-radius: 16px; max-width: 500px; width: 90%; border: 1px solid #334155; }
        .modal .plan-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; margin: 16px 0; }
        .modal .plan { background: #0f172a; padding: 12px; border-radius: 12px; text-align: center; cursor: pointer; border: 1px solid #334155; }
        .modal .plan:hover { border-color: #818cf8; }
        .modal .plan .price { font-size: 20px; font-weight: bold; color: #818cf8; }
        .modal .plan .name { font-weight: bold; }
        .modal .plan ul { list-style: none; padding: 0; font-size: 12px; color: #94a3b8; }
        input[type="text"] { padding: 8px; border-radius: 8px; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; width: 200px; }
        @media (max-width: 600px) { .modal .plan-grid { grid-template-columns: 1fr; } .feature-grid { grid-template-columns: repeat(8, 1fr); } }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="logo">🛡️ NeoAMONA</div>
        <div>
            <span class="badge" id="tierBadge">🔓 Freemium</span>
            <span class="badge" id="reqBadge" style="margin-left:8px;">Requests: 10</span>
        </div>
    </div>

    <!-- Stats -->
    <div class="stats" id="stats">
        <div class="stat"><div class="num" id="statTotal">0</div><div class="lbl">Total Rows</div></div>
        <div class="stat"><div class="num" style="color:#ef4444;" id="statAttacks">0</div><div class="lbl">Attacks</div></div>
        <div class="stat"><div class="num" style="color:#22c55e;" id="statNormal">0</div><div class="lbl">Normal</div></div>
        <div class="stat"><div class="num" style="color:#f59e0b;" id="statRatio">0%</div><div class="lbl">Attack Ratio</div></div>
    </div>

    <!-- Upload -->
    <div class="card">
        <h2>📤 Upload CSV</h2>
        <div class="upload-zone" id="uploadZone">
            <div class="icon">📁</div>
            <p><strong>Drop CSV here</strong> or click to browse</p>
            <p class="text-muted">Max rows: <span id="maxRowsDisplay">1,000</span></p>
            <input type="file" id="fileInput" accept=".csv">
            <div style="margin-top:12px;">
                <input type="text" id="targetCol" placeholder="Target column (optional)">
            </div>
        </div>
        <div id="uploadProgress" style="display:none; margin-top:12px;">
            <p class="text-muted">Analyzing...</p>
            <div style="height:4px; background:#334155; border-radius:4px; overflow:hidden;">
                <div style="width:100%; height:100%; background:#818cf8;"></div>
            </div>
        </div>
        <div id="uploadResult" class="mt-2"></div>
    </div>

    <!-- Predict -->
    <div class="card">
        <h2>⚡ Single Prediction</h2>
        <p class="text-muted">Enter 41 numeric features</p>
        <div class="feature-grid" id="featureGrid"></div>
        <div class="flex mt-2">
            <button class="btn" id="predictBtn">Predict</button>
            <button class="btn btn-secondary" id="randomBtn">🎲 Random</button>
        </div>
        <div id="predictResult" class="mt-2"></div>
    </div>

    <!-- Log -->
    <div class="card">
        <h2>📋 Activity Log</h2>
        <div class="log" id="logContainer"><div class="text-muted" style="text-align:center;">No activity yet.</div></div>
    </div>
</div>

<!-- Upgrade Modal -->
<div class="modal-overlay" id="upgradeModal">
    <div class="modal">
        <h2>⬆️ Upgrade Required</h2>
        <p class="text-muted">Your plan (<span id="modalTier">Freemium</span>) allows only <span id="modalLimit">1,000</span> rows.</p>
        <div class="plan-grid">
            <div class="plan" onclick="upgradeTo('basic')"><div class="name">Basic</div><div class="price">$299</div><ul><li>10k rows</li><li>100 req/day</li><li>CSV export</li></ul><button class="btn btn-secondary" style="width:100%;">Select</button></div>
            <div class="plan" style="border-color:#818cf8;" onclick="upgradeTo('pro')"><div class="name">Pro</div><div class="price">$999</div><ul><li>100k rows</li><li>1000 req/day</li><li>Threshold tuning</li><li>CSV export</li></ul><button class="btn" style="width:100%;">Select</button></div>
            <div class="plan" onclick="upgradeTo('enterprise')"><div class="name">Enterprise</div><div class="price">Contact</div><ul><li>Unlimited</li><li>Unlimited</li><li>Custom nodes</li></ul><button class="btn btn-secondary" style="width:100%;">Contact</button></div>
        </div>
        <div style="background:rgba(99,102,241,0.1); padding:8px; border-radius:8px; margin-top:12px;">
            <small>🔑 Use <code>demo_payment</code> for testing</small>
        </div>
        <button class="btn btn-secondary" style="margin-top:12px;" onclick="closeModal()">Close</button>
    </div>
</div>

<div id="toastContainer" style="position:fixed; bottom:20px; right:20px; z-index:999;"></div>

<script>
// ============================================================
// State
// ============================================================
let state = {
    apiKey: 'free_key_123',
    tier: 'free',
    limits: { free: 1000, basic: 10000, pro: 100000, enterprise: Infinity }
};

// ============================================================
// DOM References
// ============================================================
const tierBadge = document.getElementById('tierBadge');
const reqBadge = document.getElementById('reqBadge');
const maxRowsDisplay = document.getElementById('maxRowsDisplay');
const uploadZone = document.getElementById('uploadZone');
const fileInput = document.getElementById('fileInput');
const targetCol = document.getElementById('targetCol');
const uploadProgress = document.getElementById('uploadProgress');
const uploadResult = document.getElementById('uploadResult');
const featureGrid = document.getElementById('featureGrid');
const predictBtn = document.getElementById('predictBtn');
const randomBtn = document.getElementById('randomBtn');
const predictResult = document.getElementById('predictResult');
const logContainer = document.getElementById('logContainer');
const upgradeModal = document.getElementById('upgradeModal');
const modalTier = document.getElementById('modalTier');
const modalLimit = document.getElementById('modalLimit');
const toastContainer = document.getElementById('toastContainer');

// ============================================================
// Create feature grid (41 fields)
// ============================================================
for (let i = 0; i < 41; i++) {
    let inp = document.createElement('input');
    inp.type = 'number';
    inp.value = '0';
    inp.step = 'any';
    inp.id = 'f'+i;
    inp.placeholder = i;
    featureGrid.appendChild(inp);
}

// ============================================================
// UI Update Functions
// ============================================================
function updateTier(tier) {
    state.tier = tier;
    const names = { free: 'Freemium', basic: 'Basic', pro: 'Professional', enterprise: 'Enterprise' };
    tierBadge.textContent = '🔓 ' + names[tier];
    maxRowsDisplay.textContent = state.limits[tier] === Infinity ? '∞' : state.limits[tier];
    const reqs = tier === 'free' ? 10 : tier === 'basic' ? 100 : tier === 'pro' ? 1000 : '∞';
    reqBadge.textContent = 'Requests: ' + reqs;
}

function showToast(msg, type='info') {
    let div = document.createElement('div');
    div.className = 'toast ' + type;
    div.textContent = msg;
    toastContainer.appendChild(div);
    setTimeout(() => { div.style.opacity = '0'; setTimeout(() => div.remove(), 300); }, 4000);
}

function addLog(msg) {
    let placeholder = logContainer.querySelector('.text-muted');
    if (placeholder) placeholder.remove();
    let div = document.createElement('div');
    let time = new Date().toLocaleTimeString();
    div.innerHTML = '<span style="color:#94a3b8;">['+time+']</span> '+msg;
    logContainer.prepend(div);
}

function updateStats(data) {
    document.getElementById('statTotal').textContent = data.total_rows || 0;
    document.getElementById('statAttacks').textContent = data.attacks_detected || 0;
    document.getElementById('statNormal').textContent = data.normal_count || 0;
    document.getElementById('statRatio').textContent = data.prediction_summary?.attack_ratio || '0%';
}

// ============================================================
// File Upload Handler (Core)
// ============================================================
async function uploadFile(file) {
    if (!file) return;

    // Quick row count to check limits
    let reader = new FileReader();
    reader.onload = async function(e) {
        let lines = e.target.result.split('\n').filter(l => l.trim() !== '');
        let rows = lines.length - 1;
        let limit = state.limits[state.tier];
        if (rows > limit && limit !== Infinity) {
            modalTier.textContent = state.tier.charAt(0).toUpperCase() + state.tier.slice(1);
            modalLimit.textContent = limit;
            upgradeModal.classList.add('active');
            return;
        }

        let formData = new FormData();
        formData.append('file', file);
        let tc = targetCol.value.trim();
        if (tc) formData.append('target_column', tc);

        uploadProgress.style.display = 'block';
        uploadResult.innerHTML = '';

        try {
            let resp = await fetch('/api/upload', {
                method: 'POST',
                headers: { 'x-api-key': state.apiKey },
                body: formData
            });
            let data = await resp.json();
            if (!resp.ok) {
                showToast('❌ ' + (data.detail || 'Upload failed'), 'error');
                uploadProgress.style.display = 'none';
                return;
            }
            updateStats(data);
            addLog('✅ Uploaded '+file.name+': '+data.attacks_detected+' attacks, '+data.normal_count+' normal');
            showToast('✅ File analyzed successfully!', 'success');
            uploadResult.innerHTML = '<div style="background:rgba(34,197,94,0.1); padding:12px; border-radius:8px; border:1px solid rgba(34,197,94,0.3);">'+
                '<strong>'+data.total_rows+'</strong> rows · <strong>'+data.attacks_detected+'</strong> attacks · <strong>'+data.normal_count+'</strong> normal'+
                (data.download_url ? '<br><a href="'+data.download_url+'" style="color:#818cf8;">Download Report</a>' : '')+
                '</div>';
            if (data.remaining_requests !== undefined) {
                reqBadge.textContent = 'Requests: '+data.remaining_requests;
            }
        } catch(err) {
            showToast('❌ Connection error: '+err.message, 'error');
        }
        uploadProgress.style.display = 'none';
    };
    reader.readAsText(file);
}

// ============================================================
// Drag & Drop Events
// ============================================================
uploadZone.addEventListener('click', () => fileInput.click());

uploadZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadZone.classList.add('dragover');
});

uploadZone.addEventListener('dragleave', () => {
    uploadZone.classList.remove('dragover');
});

uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.classList.remove('dragover');
    if (e.dataTransfer.files.length) {
        uploadFile(e.dataTransfer.files[0]);
    }
});

fileInput.addEventListener('change', () => {
    if (fileInput.files.length) {
        uploadFile(fileInput.files[0]);
    }
});

// ============================================================
// Prediction
// ============================================================
predictBtn.addEventListener('click', async function() {
    let feats = [];
    for (let i=0; i<41; i++) {
        let v = parseFloat(document.getElementById('f'+i).value);
        feats.push(isNaN(v) ? 0 : v);
    }
    try {
        let resp = await fetch('/api/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': state.apiKey
            },
            body: JSON.stringify({ features: feats })
        });
        let data = await resp.json();
        if (!resp.ok) {
            showToast('❌ ' + (data.detail || 'Prediction failed'), 'error');
            return;
        }
        let cls = data.prediction === 'Attack' ? 'danger' : 'success';
        predictResult.innerHTML = '<div class="result-box '+cls+'"><strong>'+data.prediction+'</strong> · Probability: '+(data.probability*100).toFixed(2)+'%<br><span class="text-muted">Threshold: '+data.threshold_used+'</span></div>';
        addLog('🔮 Prediction: '+data.prediction+' ('+(data.probability*100).toFixed(2)+'%)');
        if (data.remaining_requests !== undefined) {
            reqBadge.textContent = 'Requests: '+data.remaining_requests;
        }
    } catch(err) {
        showToast('❌ Connection error: '+err.message, 'error');
    }
});

// Random fill
randomBtn.addEventListener('click', () => {
    for (let i=0; i<41; i++) {
        document.getElementById('f'+i).value = (Math.random()*10).toFixed(2);
    }
});

// ============================================================
// Upgrade Modal
// ============================================================
function closeModal() {
    upgradeModal.classList.remove('active');
}

function upgradeTo(plan) {
    if (confirm('Upgrade to '+plan.charAt(0).toUpperCase()+plan.slice(1)+'?')) {
        let token = prompt('Enter payment token (use "demo_payment"):');
        if (token === 'demo_payment') {
            let suffix = Math.random().toString(36).substring(2,6);
            let newKey = plan+'_key_'+suffix;
            state.apiKey = newKey;
            updateTier(plan);
            showToast('✅ Upgraded to '+plan.charAt(0).toUpperCase()+plan.slice(1)+'! New key: '+newKey, 'success');
            closeModal();
            reqBadge.textContent = 'Requests: ∞';
        } else {
            showToast('❌ Invalid token', 'error');
        }
    }
}

// Close modal on outside click
upgradeModal.addEventListener('click', (e) => {
    if (e.target === upgradeModal) closeModal();
});

// ============================================================
// Initialization
// ============================================================
updateTier('free');
addLog('🚀 NeoAMONA ready. Upload CSV or try prediction.');
</script>
</body>
</html>
"""

# ============================================================
# 5. نقاط النهاية (Endpoints)
# ============================================================

@app.get("/", response_class=HTMLResponse)
async def root():
    return HTML_PAGE

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard():
    return HTML_PAGE

@app.get("/health")
async def health():
    return {"status": "ok", "model_loaded": model is not None}

@app.post("/api/predict")
async def predict(
    features: List[float],
    threshold: Optional[float] = None,
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(503, "Model not loaded")
    tier = validate_key(x_api_key)
    check_limits(tier)
    th = threshold if threshold is not None else model.best_threshold
    X = np.array(features).reshape(1, -1)
    proba = model.predict_proba(X)[0]
    pred = int(proba >= th)
    return {
        "prediction": "Attack" if pred else "Normal",
        "probability": float(proba),
        "threshold_used": float(th),
        "tier": tier,
        "remaining_requests": max(0, 1000 - request_counter[tier])
    }

@app.post("/api/upload")
async def upload_file(
    file: UploadFile = File(...),
    target_column: Optional[str] = None,
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(503, "Model not loaded")
    tier = validate_key(x_api_key)
    contents = await file.read()
    df = pd.read_csv(io.BytesIO(contents))
    if df.empty:
        raise HTTPException(400, "Empty file")
    check_limits(tier, rows=df.shape[0])
    X, y_true = clean_data(df, target_column)
    proba = model.predict_proba(X)
    y_pred = (proba >= model.best_threshold).astype(int)
    attacks = int(np.sum(y_pred))
    normal = len(y_pred) - attacks
    summary = {
        "total": X.shape[0],
        "attacks_detected": attacks,
        "normal_count": normal,
        "attack_ratio": f"{attacks/X.shape[0]*100:.2f}%"
    }
    return {
        "status": "success",
        "tier": tier,
        **summary,
        "remaining_requests": max(0, 1000 - request_counter[tier]),
        "download_url": None
    }

# ============================================================
# 6. تشغيل الخادم
# ============================================================

if __name__ == "__main__":
    print("="*60)
    print("🚀 NeoAMONA Enterprise Server v4.0")
    print("="*60)
    uvicorn.run("neoamona_server:app", host="0.0.0.0", port=8080, reload=False)