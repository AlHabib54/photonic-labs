# -*- coding: utf-8 -*-
"""
NeoAMONA Enterprise Server - Minimal & Working
"""

import pickle
import numpy as np
import pandas as pd
import io
import os
from typing import List, Optional
from fastapi import FastAPI, UploadFile, File, HTTPException, Header
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

try:
    from neoamona_core import NeoAMONACore
except ImportError:
    print("⚠️  neoamona_core.py not found")
    exit(1)

# ============================================================
# 1. نظام الاشتراكات المبسط
# ============================================================

TIER_LIMITS = {
    "free": {"max_rows": 1000, "name": "Freemium"},
    "pro": {"max_rows": 100000, "name": "Professional"}
}

MOCK_API_KEYS = {
    "free_key_123": "free",
    "pro_key_789": "pro"
}

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

MODEL_PATH = "models/neoamona_core_model.pkl"
model = None

@app.on_event("startup")
async def load_model():
    global model
    if os.path.exists(MODEL_PATH):
        model = NeoAMONACore.load(MODEL_PATH)
        print(f"✅ Model loaded")
    else:
        print(f"⚠️  Model not found")

def validate_key(api_key: str) -> str:
    if api_key not in MOCK_API_KEYS:
        raise HTTPException(401, "Invalid API key")
    return MOCK_API_KEYS[api_key]

def clean_data(df: pd.DataFrame, target_col: Optional[str] = None):
    if target_col and target_col in df.columns:
        y = df[target_col].values
        y = np.array([0 if str(v).strip().upper() == 'BENIGN' or v == 0 else 1 for v in y])
        X_raw = df.drop(columns=[target_col]).values
    else:
        X_raw = df.values
        y = None
    X_clean = []
    for i in range(X_raw.shape[1]):
        col = pd.to_numeric(X_raw[:, i], errors='coerce')
        mean = np.nanmean(col)
        col = np.nan_to_num(col, nan=mean)
        X_clean.append(col)
    return np.column_stack(X_clean).astype(float), y

# ============================================================
# 2. HTML بسيط مع كود JS واضح
# ============================================================

HTML_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>NeoAMONA</title>
    <style>
        body { font-family: Arial; background: #0f172a; color: #e2e8f0; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; }
        .card { background: #1e293b; border-radius: 12px; padding: 20px; margin: 16px 0; }
        .upload-zone { border: 2px dashed #334155; padding: 30px; text-align: center; cursor: pointer; }
        .upload-zone.dragover { border-color: #818cf8; background: rgba(99,102,241,0.05); }
        .btn { background: #818cf8; border: none; color: #0f172a; padding: 8px 20px; border-radius: 6px; cursor: pointer; }
        .btn-secondary { background: transparent; border: 1px solid #334155; color: #e2e8f0; }
        .feature-grid { display: grid; grid-template-columns: repeat(10, 1fr); gap: 4px; margin: 10px 0; }
        .feature-grid input { width: 100%; padding: 4px; text-align: center; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; border-radius: 4px; }
        .log { background: #0f172a; padding: 10px; border-radius: 6px; max-height: 150px; overflow-y: auto; }
        .stat { display: inline-block; background: #0f172a; padding: 8px 20px; border-radius: 8px; margin-right: 10px; }
        .stat .num { font-size: 24px; font-weight: bold; }
        .result-box { padding: 10px; border-radius: 6px; margin-top: 10px; }
        .result-box.success { background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); }
        .result-box.danger { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); }
        input[type="text"] { padding: 6px; border-radius: 6px; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; }
        .toast { position: fixed; bottom: 20px; right: 20px; background: #1e293b; padding: 10px 20px; border-radius: 8px; border-left: 4px solid #818cf8; }
        .toast.error { border-left-color: #ef4444; }
        .toast.success { border-left-color: #22c55e; }
    </style>
</head>
<body>
<div class="container">
    <h1 style="color:#818cf8;">🛡️ NeoAMONA</h1>
    <div>
        <span id="tierBadge" style="background:#334155; padding:4px 14px; border-radius:50px;">🔓 Freemium</span>
        <span id="reqBadge" style="background:#334155; padding:4px 14px; border-radius:50px; margin-left:8px;">Requests: 10</span>
    </div>

    <!-- Stats -->
    <div style="margin:16px 0;">
        <div class="stat"><div class="num" id="statTotal">0</div><div style="color:#94a3b8;">Rows</div></div>
        <div class="stat"><div class="num" style="color:#ef4444;" id="statAttacks">0</div><div style="color:#94a3b8;">Attacks</div></div>
        <div class="stat"><div class="num" style="color:#22c55e;" id="statNormal">0</div><div style="color:#94a3b8;">Normal</div></div>
    </div>

    <!-- Upload -->
    <div class="card">
        <h3>📤 Upload CSV</h3>
        <div class="upload-zone" id="uploadZone">
            <p><strong>Drop CSV here</strong> or click to browse</p>
            <p style="color:#94a3b8;">Max rows: <span id="maxRowsDisplay">1,000</span></p>
            <input type="file" id="fileInput" accept=".csv" style="display:none;">
            <div style="margin-top:10px;">
                <input type="text" id="targetCol" placeholder="Target column (optional)">
            </div>
        </div>
        <div id="uploadResult" style="margin-top:10px;"></div>
    </div>

    <!-- Predict -->
    <div class="card">
        <h3>⚡ Predict</h3>
        <div class="feature-grid" id="featureGrid"></div>
        <button class="btn" id="predictBtn">Predict</button>
        <button class="btn btn-secondary" id="randomBtn">Random</button>
        <div id="predictResult" style="margin-top:10px;"></div>
    </div>

    <!-- Log -->
    <div class="card">
        <h3>📋 Log</h3>
        <div class="log" id="logContainer"><div style="color:#94a3b8;">Ready.</div></div>
    </div>
</div>

<script>
// ============================================================
// Simple and reliable JS
// ============================================================
document.addEventListener('DOMContentLoaded', function() {

    console.log('✅ Page loaded');

    // State
    let apiKey = 'free_key_123';
    let tier = 'free';
    const limits = { free: 1000, pro: 100000 };

    // DOM refs
    const uploadZone = document.getElementById('uploadZone');
    const fileInput = document.getElementById('fileInput');
    const targetCol = document.getElementById('targetCol');
    const uploadResult = document.getElementById('uploadResult');
    const featureGrid = document.getElementById('featureGrid');
    const predictBtn = document.getElementById('predictBtn');
    const randomBtn = document.getElementById('randomBtn');
    const predictResult = document.getElementById('predictResult');
    const logContainer = document.getElementById('logContainer');
    const tierBadge = document.getElementById('tierBadge');
    const reqBadge = document.getElementById('reqBadge');
    const maxRowsDisplay = document.getElementById('maxRowsDisplay');

    // Create feature grid (41 fields)
    for (let i = 0; i < 41; i++) {
        let inp = document.createElement('input');
        inp.type = 'number';
        inp.value = '0';
        inp.step = 'any';
        inp.id = 'f'+i;
        inp.placeholder = i;
        featureGrid.appendChild(inp);
    }

    // Update tier display
    function updateTier(t) {
        tier = t;
        const names = { free: 'Freemium', pro: 'Professional' };
        tierBadge.textContent = '🔓 ' + names[t];
        maxRowsDisplay.textContent = limits[t];
        reqBadge.textContent = 'Requests: ' + (t === 'free' ? 10 : 1000);
    }

    // Toast
    function toast(msg, type='info') {
        let div = document.createElement('div');
        div.className = 'toast ' + type;
        div.textContent = msg;
        document.body.appendChild(div);
        setTimeout(() => { div.style.opacity = '0'; setTimeout(() => div.remove(), 300); }, 3000);
    }

    // Log
    function log(msg) {
        let placeholder = logContainer.querySelector('div[style*="color:#94a3b8;"]');
        if (placeholder) placeholder.remove();
        let div = document.createElement('div');
        let time = new Date().toLocaleTimeString();
        div.innerHTML = '<span style="color:#94a3b8;">['+time+']</span> '+msg;
        logContainer.prepend(div);
    }

    // Update stats
    function updateStats(data) {
        document.getElementById('statTotal').textContent = data.total_rows || 0;
        document.getElementById('statAttacks').textContent = data.attacks_detected || 0;
        document.getElementById('statNormal').textContent = data.normal_count || 0;
    }

    // Upload handler
    async function uploadFile(file) {
        if (!file) return;
        console.log('📤 Uploading file:', file.name);

        let reader = new FileReader();
        reader.onload = async function(e) {
            let lines = e.target.result.split('\\n').filter(l => l.trim() !== '');
            let rows = lines.length - 1;
            console.log('Rows:', rows);
            let limit = limits[tier];
            if (rows > limit) {
                toast('❌ Your tier allows only '+limit+' rows. Upgrade to Pro.', 'error');
                return;
            }

            let formData = new FormData();
            formData.append('file', file);
            let tc = targetCol.value.trim();
            if (tc) formData.append('target_column', tc);

            try {
                let resp = await fetch('/api/upload', {
                    method: 'POST',
                    headers: { 'x-api-key': apiKey },
                    body: formData
                });
                let data = await resp.json();
                if (!resp.ok) {
                    toast('❌ ' + (data.detail || 'Upload failed'), 'error');
                    return;
                }
                updateStats(data);
                log('✅ Uploaded '+file.name+': '+data.attacks_detected+' attacks, '+data.normal_count+' normal');
                toast('✅ File analyzed!', 'success');
                uploadResult.innerHTML = '<div style="background:rgba(34,197,94,0.1); padding:10px; border-radius:6px;">'+
                    '<strong>'+data.total_rows+'</strong> rows · <strong>'+data.attacks_detected+'</strong> attacks · <strong>'+data.normal_count+'</strong> normal'+
                    '</div>';
                if (data.remaining_requests !== undefined) {
                    reqBadge.textContent = 'Requests: '+data.remaining_requests;
                }
            } catch(err) {
                toast('❌ Connection error', 'error');
                console.error(err);
            }
        };
        reader.readAsText(file);
    }

    // === Drag & Drop ===
    uploadZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadZone.classList.add('dragover');
    });
    uploadZone.addEventListener('dragleave', () => {
        uploadZone.classList.remove('dragover');
    });
    uploadZone.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadZone.classList.remove('dragover');
        if (e.dataTransfer.files.length) {
            uploadFile(e.dataTransfer.files[0]);
        }
    });
    uploadZone.addEventListener('click', () => {
        fileInput.click();
    });
    fileInput.addEventListener('change', () => {
        if (fileInput.files.length) {
            uploadFile(fileInput.files[0]);
        }
    });

    // === Predict ===
    predictBtn.addEventListener('click', async function() {
        let feats = [];
        for (let i=0; i<41; i++) {
            let v = parseFloat(document.getElementById('f'+i).value);
            feats.push(isNaN(v) ? 0 : v);
        }
        try {
            let resp = await fetch('/api/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-api-key': apiKey
                },
                body: JSON.stringify({ features: feats })
            });
            let data = await resp.json();
            if (!resp.ok) {
                toast('❌ ' + (data.detail || 'Prediction failed'), 'error');
                return;
            }
            let cls = data.prediction === 'Attack' ? 'danger' : 'success';
            predictResult.innerHTML = '<div class="result-box '+cls+'"><strong>'+data.prediction+'</strong> · '+(data.probability*100).toFixed(2)+'%</div>';
            log('🔮 Prediction: '+data.prediction+' ('+(data.probability*100).toFixed(2)+'%)');
            if (data.remaining_requests !== undefined) {
                reqBadge.textContent = 'Requests: '+data.remaining_requests;
            }
        } catch(err) {
            toast('❌ Connection error', 'error');
            console.error(err);
        }
    });

    // === Random ===
    randomBtn.addEventListener('click', function() {
        for (let i=0; i<41; i++) {
            document.getElementById('f'+i).value = (Math.random()*10).toFixed(2);
        }
    });

    // === Upgrade (simple) ===
    window.upgradeToPro = function() {
        let key = prompt('Enter payment token (use "demo_payment"):');
        if (key === 'demo_payment') {
            apiKey = 'pro_key_789';
            updateTier('pro');
            toast('✅ Upgraded to Professional!', 'success');
            reqBadge.textContent = 'Requests: ∞';
        } else {
            toast('❌ Invalid token', 'error');
        }
    };

    // Show upgrade option (if needed)
    console.log('💡 To upgrade, run: upgradeToPro() in console');

    // Init
    updateTier('free');
    log('🚀 NeoAMONA ready');
    console.log('✅ All events registered');
});
</script>
</body>
</html>
"""

# ============================================================
# 3. Endpoints
# ============================================================

@app.get("/", response_class=HTMLResponse)
async def root():
    return HTML_PAGE

@app.post("/api/predict")
async def predict(features: List[float], x_api_key: str = Header(...)):
    if model is None:
        raise HTTPException(503, "Model not loaded")
    tier = validate_key(x_api_key)
    X = np.array(features).reshape(1, -1)
    proba = model.predict_proba(X)[0]
    pred = int(proba >= model.best_threshold)
    return {
        "prediction": "Attack" if pred else "Normal",
        "probability": float(proba),
        "threshold_used": float(model.best_threshold),
        "tier": tier,
        "remaining_requests": 999
    }

@app.post("/api/upload")
async def upload_file(file: UploadFile = File(...), target_column: Optional[str] = None, x_api_key: str = Header(...)):
    if model is None:
        raise HTTPException(503, "Model not loaded")
    tier = validate_key(x_api_key)
    contents = await file.read()
    df = pd.read_csv(io.BytesIO(contents))
    if df.empty:
        raise HTTPException(400, "Empty file")
    limit = 1000 if tier == "free" else 100000
    if df.shape[0] > limit:
        raise HTTPException(403, f"Row limit exceeded. Your tier allows {limit} rows.")
    X, y_true = clean_data(df, target_column)
    proba = model.predict_proba(X)
    y_pred = (proba >= model.best_threshold).astype(int)
    return {
        "status": "success",
        "tier": tier,
        "total_rows": X.shape[0],
        "attacks_detected": int(np.sum(y_pred)),
        "normal_count": int(len(y_pred) - np.sum(y_pred)),
        "remaining_requests": 999
    }

# ============================================================
# 4. Run
# ============================================================

if __name__ == "__main__":
    print("="*50)
    print("🚀 NeoAMONA Server (Minimal)")
    print("="*50)
    uvicorn.run("neoamona_server:app", host="0.0.0.0", port=8080, reload=False)