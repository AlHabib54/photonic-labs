# -*- coding: utf-8 -*-
"""
NeoAMONA Enterprise Server - النسخة النهائية مع دعم وضعي التشغيل (Fast / Normal)
"""

import pickle
import numpy as np
import pandas as pd
import io
import os
import time
import logging
import base64
from typing import List, Optional
from fastapi import FastAPI, UploadFile, File, HTTPException, Header, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from sklearn.preprocessing import LabelEncoder
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import uvicorn
import warnings
warnings.filterwarnings('ignore')

# استيراد الخوارزمية الأساسية
from neoamona_core import NeoAMONACore

# ============================================================
# 1. نظام التسجيل (Logging)
# ============================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("neoamona.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("NeoAMONA")

# ============================================================
# 2. نظام الاشتراكات والتراخيص
# ============================================================
TIER_LIMITS = {
    "free": {"max_rows": 1000, "name": "Freemium", "color": "#94a3b8"},
    "pro": {"max_rows": 100000, "name": "Professional", "color": "#818cf8"},
    "enterprise": {"max_rows": float('inf'), "name": "Enterprise", "color": "#fbbf24"}
}

MOCK_API_KEYS = {
    "free_key_123": "free",
    "pro_key_789": "pro",
    "enterprise_key_000": "enterprise"
}

app = FastAPI(title="NeoAMONA Enterprise")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

MODEL_PATH = "models/neoamona_core_model.pkl"
ENCRYPTED_MODEL_PATH = "models/neoamona_core_model.pkl.enc"
ENCRYPTION_PASSWORD = "NeoAMONA_Secure_Key_2026"  # يجب تغييرها في الإنتاج

model = None

# ============================================================
# 3. دوال التشفير وفك التشفير
# ============================================================

def generate_key(password: str, salt: bytes = None) -> tuple:
    if salt is None:
        salt = os.urandom(16)
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    return key, salt

def decrypt_model_file(encrypted_path: str, password: str) -> bytes:
    if not os.path.exists(encrypted_path):
        raise FileNotFoundError(f"Encrypted model not found: {encrypted_path}")
    with open(encrypted_path, 'rb') as f:
        salt = f.read(16)
        encrypted_data = f.read()
    key, _ = generate_key(password, salt)
    cipher = Fernet(key)
    return cipher.decrypt(encrypted_data)

def load_encrypted_model(encrypted_path: str, password: str):
    try:
        decrypted_data = decrypt_model_file(encrypted_path, password)
        model = pickle.loads(decrypted_data)
        logger.info("✅ Model decrypted and loaded successfully")
        return model
    except Exception as e:
        logger.error(f"❌ Failed to decrypt model: {str(e)}")
        return None

# ============================================================
# 4. تحميل النموذج عند بدء التشغيل
# ============================================================

@app.on_event("startup")
async def load_model():
    global model
    if os.path.exists(ENCRYPTED_MODEL_PATH):
        logger.info(f"🔐 Attempting to load encrypted model: {ENCRYPTED_MODEL_PATH}")
        model = load_encrypted_model(ENCRYPTED_MODEL_PATH, ENCRYPTION_PASSWORD)
        if model is not None:
            logger.info("✅ Encrypted model loaded successfully")
            logger.info(f"   - Active nodes: {model.active_nodes}")
            logger.info(f"   - Threshold: {model.best_threshold:.3f}")
            return
    if os.path.exists(MODEL_PATH):
        try:
            model = NeoAMONACore.load(MODEL_PATH)
            logger.info(f"✅ Plain model loaded from {MODEL_PATH}")
            logger.info(f"   - Active nodes: {model.active_nodes}")
            logger.info(f"   - Threshold: {model.best_threshold:.3f}")
            return
        except Exception as e:
            logger.error(f"❌ Failed to load plain model: {e}")
    else:
        logger.warning(f"⚠️  Model not found. Please train first.")

# ============================================================
# 5. دوال التحقق والمساعدة
# ============================================================

def validate_key(api_key: str) -> str:
    if api_key not in MOCK_API_KEYS:
        raise HTTPException(401, detail="❌ Invalid API key")
    return MOCK_API_KEYS[api_key]

def check_tier_limit(tier: str, rows: int):
    limit = TIER_LIMITS[tier]["max_rows"]
    if rows > limit:
        raise HTTPException(403, detail=f"❌ Row limit exceeded. Your tier allows {limit} rows.")

def adapt_to_41_features(X: np.ndarray) -> np.ndarray:
    if X.ndim == 1:
        X = X.reshape(1, -1)
    target_features = 41
    current = X.shape[1]
    if current < target_features:
        pad = target_features - current
        return np.pad(X, ((0,0), (0,pad)), 'constant')
    elif current > target_features:
        return X[:, :target_features]
    return X

def clean_data_smart(df: pd.DataFrame, target_col: Optional[str] = None):
    logger.info("🔄 Starting data cleaning...")
    start = time.time()
    # إذا لم يحدد العمود الهدف، نأخذ العمود الأخير
    if target_col is None:
        target_col = df.columns[-1]
        logger.info(f"ℹ️  Using last column as target: '{target_col}'")

    # فصل الميزات والهدف
    X_raw = df.drop(columns=[target_col])
    y_raw = df[target_col]

    # تحويل الهدف إلى ثنائي
    try:
        y = np.array([0 if str(v).strip().upper() in ['BENIGN', 'NORMAL', '0'] else 1 for v in y_raw])
    except:
        y = np.array([0 if str(v).strip().lower() in ['normal', 'benign'] else 1 for v in y_raw])

    # تنظيف الأعمدة
    X_clean = []
    for col in X_raw.columns:
        if X_raw[col].dtype == 'object':
            le = LabelEncoder()
            col_filled = X_raw[col].fillna('missing').astype(str)
            X_clean.append(le.fit_transform(col_filled).astype(float))
        else:
            col_numeric = pd.to_numeric(X_raw[col], errors='coerce')
            mean_val = np.nanmean(col_numeric)
            if np.isnan(mean_val):
                mean_val = 0.0
            col_filled = np.nan_to_num(col_numeric, nan=mean_val)
            col_filled = np.clip(col_filled, -1e6, 1e6)
            X_clean.append(col_filled.astype(float))

    X = np.column_stack(X_clean)
    X = adapt_to_41_features(X)
    X = np.nan_to_num(X, nan=0.0)

    logger.info(f"✅ Data cleaning completed in {time.time()-start:.2f}s")
    return X, y

# ============================================================
# 6. معالجة الملفات الكبيرة (Chunking) مع دعم الوضع
# ============================================================

def process_large_file_chunked(file_bytes: bytes, target_col: Optional[str] = None,
                               mode: str = 'normal', chunk_size: int = 100000):
    logger.info(f"🔄 Starting chunked processing (mode={mode}, chunk_size={chunk_size})")
    start_time = time.time()

    all_proba = []
    total_rows = 0
    total_attacks = 0

    # نمرر `mode` إلى الدالة التي ستستخدمها داخل الحلقة إذا أردنا إعادة التدريب لكل دفعة
    # لكن في هذا التطبيق، نريد تدريب نموذج واحد على كل البيانات.
    # لذا سنستخدم أول دفعة للتدريب (أو ندمج كل الدفعات ثم نتدرب).
    # لكن لتوفير الوقت، سنستخدم الدفعة الأولى كعينة لتدريب النموذج.
    # ثم نطبق النموذج على باقي الدفعات.

    try:
        df_iter = pd.read_csv(io.BytesIO(file_bytes), chunksize=chunk_size, low_memory=False)
    except Exception as e:
        raise ValueError(f"❌ Invalid CSV format: {str(e)}")

    # نجمع كل الدفعات في قائمة لتدريب النموذج عليها كاملة (أو على عينة منها)
    # لكن هذا قد يستهلك ذاكرة. بدلاً من ذلك، ندمج البيانات في مصفوفة واحدة.
    # لتوفير الذاكرة، سنستخدم الدفعة الأولى كعينة تدريب (في الوضع السريع)
    # وفي الوضع العادي سندمج كل الدفعات.
    chunks = []
    for chunk in df_iter:
        chunks.append(chunk)

    # دمج كل الدفعات في DataFrame واحد
    df_full = pd.concat(chunks, ignore_index=True)
    logger.info(f"📦 Total rows after merging: {len(df_full)}")

    # تنظيف البيانات كاملة
    X_full, y_full = clean_data_smart(df_full, target_col)
    logger.info(f"✅ Data ready: {X_full.shape[0]} samples, {X_full.shape[1]} features")

    # تدريب نموذج NeoAMONA على البيانات كاملة (أو على عينة حسب الوضع)
    # نستخدم فقط البيانات الأولى للتدريب (لتوفير الوقت)
    # في الوضع العادي نستخدم كل البيانات
    # في الوضع السريع نستخدم عينة صغيرة
    from sklearn.model_selection import train_test_split

    if mode == 'fast':
        # استخدام 5000 عينة فقط لتدريب النموذج (لتسريع العملية)
        sample_size = min(5000, X_full.shape[0])
        idx = np.random.choice(X_full.shape[0], sample_size, replace=False)
        X_sample = X_full[idx]
        y_sample = y_full[idx]
        logger.info(f"⚡ Fast mode: training on {sample_size} samples")
    else:
        X_sample = X_full
        y_sample = y_full
        logger.info(f"🐢 Normal mode: training on {X_full.shape[0]} samples")

    # تقسيم البيانات إلى تدريب واختبار (لتقييم النموذج)
    X_train, X_test, y_train, y_test = train_test_split(
        X_sample, y_sample, test_size=0.2, random_state=42, stratify=y_sample
    )

    # تدريب نموذج NeoAMONA
    neo = NeoAMONACore()
    neo.fit(X_train, y_train, mode=mode)

    # التنبؤ على مجموعة الاختبار
    y_pred = neo.predict(X_test)
    y_proba = neo.predict_proba(X_test)
    from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
    acc = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    roc = roc_auc_score(y_test, y_proba)
    logger.info(f"✅ Model evaluation on test set: Acc={acc:.4f}, F1={f1:.4f}, ROC-AUC={roc:.4f}")

    # نعيد التنبؤ على كامل البيانات (للمخرجات) باستخدام النموذج المدرب
    # لكننا نريد التنبؤ على جميع البيانات، وليس فقط عينة الاختبار.
    # هنا سنستخدم النموذج المدرب للتنبؤ على كل البيانات (X_full)
    y_pred_full = neo.predict(X_full)
    total_attacks = int(np.sum(y_pred_full))
    total_rows = X_full.shape[0]

    logger.info(f"✅ File processing completed in {time.time()-start_time:.2f} seconds")
    logger.info(f"   - Total rows: {total_rows}")
    logger.info(f"   - Total attacks detected: {total_attacks}")

    return None, total_rows, total_attacks

# ============================================================
# 7. نقاط النهاية (Endpoints)
# ============================================================

@app.get("/", response_class=HTMLResponse)
async def root():
    with open("dashboard.html", "r") as f:
        return f.read()

@app.get("/health")
async def health():
    return {"status": "ok", "model_loaded": model is not None}

@app.post("/api/upload")
async def upload_file(
    file: UploadFile = File(...),
    target_column: Optional[str] = Form(None),
    mode: str = Form('normal'),
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(503, detail="❌ Model not loaded. Please train first.")

    try:
        tier = validate_key(x_api_key)
        contents = await file.read()
        # قراءة أول بضعة أسطر لتحديد عدد الأعمدة (للتحقق من الصلاحية)
        df_sample = pd.read_csv(io.BytesIO(contents), nrows=5)
        if df_sample.empty:
            raise HTTPException(400, detail="❌ File is empty")

        # التحقق من الحد الأقصى للصفوف (باستخدام عدد الأسطر في الملف)
        total_rows_estimate = sum(1 for _ in io.StringIO(contents.decode('utf-8'))) - 1  # ناقص الرأس
        check_tier_limit(tier, total_rows_estimate)

        # معالجة الملف باستخدام الدالة المخصصة
        _, total_rows, total_attacks = process_large_file_chunked(
            contents, target_column, mode=mode, chunk_size=100000
        )

        normal = total_rows - total_attacks
        attack_ratio = f"{total_attacks/total_rows*100:.2f}%" if total_rows > 0 else "0%"

        return {
            "status": "success",
            "tier": tier,
            "total_rows": total_rows,
            "attacks_detected": total_attacks,
            "normal_count": normal,
            "attack_ratio": attack_ratio,
            "remaining_requests": 999,
            "mode": mode
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Upload error: {str(e)}")
        raise HTTPException(400, detail=f"❌ Error: {str(e)}")

# ============================================================
# 8. تشغيل الخادم
# ============================================================
if __name__ == "__main__":
    print("="*60)
    print("🚀 NeoAMONA Enterprise Server v5.1 - مع دعم وضعي التشغيل")
    print("="*60)
    print("✅ Fast mode: اختيار العقد باستخدام عينة صغيرة (سرعة)")
    print("✅ Normal mode: اختيار العقد باستخدام كامل البيانات (دقة)")
    print("="*60)
    uvicorn.run("neoamona_server:app", host="0.0.0.0", port=8080, reload=False)