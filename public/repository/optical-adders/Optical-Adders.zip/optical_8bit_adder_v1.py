# ==========================================================
# optical_8bit_adder_v1.py
# Verified Optical 8-Bit Adder V1
# Built only on verified Full Adder
# Stable + Defensive + Low Execution Risk
# ==========================================================

import matplotlib.pyplot as plt


# ==========================================================
# VERIFIED LOGIC GATES
# ==========================================================

def optical_and(a, b):
    return a & b


def optical_or(a, b):
    return a | b


def optical_xor(a, b):
    return a ^ b


# ==========================================================
# VERIFIED FULL ADDER
# ==========================================================

def optical_full_adder(a, b, cin):

    xor1 = optical_xor(a, b)
    sum_bit = optical_xor(xor1, cin)

    and1 = optical_and(a, b)
    and2 = optical_and(cin, xor1)

    carry = optical_or(and1, and2)

    return sum_bit, carry


# ==========================================================
# HELPER FUNCTIONS
# ==========================================================

def bits_to_decimal(bits):
    return int("".join(map(str, bits)), 2)


def decimal_to_8bit(value):

    if value < 0 or value > 255:
        raise ValueError(
            "Decimal value must be between 0 and 255"
        )

    return list(
        map(int, format(value, '08b'))
    )


def validate_bits(bits):

    if len(bits) != 8:
        raise ValueError(
            "Input must be exactly 8 bits"
        )

    for bit in bits:
        if bit not in [0, 1]:
            raise ValueError(
                "Bits must contain only 0 or 1"
            )


# ==========================================================
# VERIFIED 8-BIT RIPPLE CARRY ADDER
# ==========================================================

def optical_8bit_adder(a_bits, b_bits):

    validate_bits(a_bits)
    validate_bits(b_bits)

    result = [0] * 8
    carry_history = [0] * 8

    carry = 0

    # Ripple Carry (LSB -> MSB)
    for i in range(7, -1, -1):

        result[i], carry = optical_full_adder(
            a_bits[i],
            b_bits[i],
            carry
        )

        carry_history[i] = carry

    final_carry = carry

    return result, final_carry, carry_history


# ==========================================================
# TEST CASE
# ==========================================================

def run_test():

    try:

        # --------------------------------------------------
        # CHANGE TEST VALUES HERE
        # Example:
        # 11001101 (205)
        # 01100110 (102)
        # Expected = 307
        # --------------------------------------------------

        a_bits = [1,1,0,0,1,1,0,1]
        b_bits = [0,1,1,0,0,1,1,0]

        result, final_carry, carry_history = (
            optical_8bit_adder(
                a_bits,
                b_bits
            )
        )

        # ==================================================
        # DECIMAL VERIFICATION
        # ==================================================

        a_decimal = bits_to_decimal(a_bits)
        b_decimal = bits_to_decimal(b_bits)

        result_decimal = bits_to_decimal(result)

        if final_carry == 1:
            result_decimal += 256

        expected_result = (
            a_decimal + b_decimal
        )

        binary_output = (
            str(final_carry)
            + "".join(map(str, result))
        )

        status = (
            "PASS"
            if result_decimal
               == expected_result
            else "FAIL"
        )

        # ==================================================
        # REPORT
        # ==================================================

        print("=" * 50)
        print(
            "OPTICAL 8-BIT ADDER V1 REPORT"
        )
        print("=" * 50)

        print()

        print(
            "INPUT A =",
            "".join(map(str, a_bits))
        )

        print(
            "INPUT B =",
            "".join(map(str, b_bits))
        )

        print()

        # Stage-by-stage report
        for i in range(8):

            bit_index = 7 - i

            print(
                f"STAGE {i}"
            )

            print(
                f"SUM{bit_index} = "
                f"{result[bit_index]}"
            )

            print(
                f"CARRY{bit_index} = "
                f"{carry_history[bit_index]}"
            )

            print()

        print(
            "FINAL CARRY =",
            final_carry
        )

        print()

        print(
            "BINARY OUTPUT =",
            binary_output
        )

        print()

        print(
            "DECIMAL A =",
            a_decimal
        )

        print(
            "DECIMAL B =",
            b_decimal
        )

        print(
            "EXPECTED =",
            expected_result
        )

        print(
            "RESULT =",
            result_decimal
        )

        print()

        print(
            "STATUS =",
            status
        )

        # ==================================================
        # VISUALIZATION
        # ==================================================

        labels = (
            ["Carry"]
            + [f"Bit{i}"
               for i in range(7, -1, -1)]
        )

        values = (
            [final_carry]
            + result
        )

        plt.figure(
            figsize=(12, 5)
        )

        plt.bar(
            labels,
            values
        )

        plt.title(
            "Optical 8-Bit Adder V1"
        )

        plt.ylabel(
            "Logic Output"
        )

        plt.ylim(0, 1.1)

        plt.show()

    except Exception as e:

        print()
        print("EXECUTION ERROR:")
        print(str(e))


# ==========================================================
# MAIN
# ==========================================================

if __name__ == "__main__":
    run_test()
