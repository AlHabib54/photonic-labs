# -*- coding: utf-8 -*-
"""
أداة تشفير النموذج - حماية الخوارزمية من النسخ
"""

import pickle
import base64
import os
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

# ============================================================
# 1. توليد مفتاح التشفير من كلمة مرور + ملح (Salt)
# ============================================================
def generate_key(password: str, salt: bytes = None) -> bytes:
    if salt is None:
        salt = os.urandom(16)
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    return key, salt

# ============================================================
# 2. تشفير النموذج
# ============================================================
def encrypt_model(model_path: str, password: str, output_path: str = None):
    """تشفير ملف النموذج (pkl) بحيث لا يمكن استخدامه بدون المفتاح"""
    # قراءة النموذج
    with open(model_path, 'rb') as f:
        model_data = f.read()
    
    # توليد المفتاح
    key, salt = generate_key(password)
    cipher = Fernet(key)
    encrypted_data = cipher.encrypt(model_data)
    
    # حفظ البيانات المشفرة مع الملح
    if output_path is None:
        output_path = model_path + '.enc'
    with open(output_path, 'wb') as f:
        f.write(salt + encrypted_data)
    
    print(f"✅ تم تشفير النموذج: {output_path}")
    print(f"🔑 احتفظ بكلمة المرور: {password}")
    return output_path

# ============================================================
# 3. فك تشفير النموذج
# ============================================================
def decrypt_model(encrypted_path: str, password: str) -> bytes:
    """فك تشفير النموذج وإرجاع البيانات الأصلية"""
    with open(encrypted_path, 'rb') as f:
        salt = f.read(16)
        encrypted_data = f.read()
    
    key, _ = generate_key(password, salt)
    cipher = Fernet(key)
    decrypted_data = cipher.decrypt(encrypted_data)
    return decrypted_data

# ============================================================
# 4. مثال على الاستخدام
# ============================================================
if __name__ == "__main__":
    # تشفير النموذج (نفّذ هذا مرة واحدة فقط)
    # encrypt_model("models/neoamona_core_model.pkl", "MyStrongPassword123!")
    
    # فك التشفير (سيتم داخل الخادم عند تحميل النموذج)
    # data = decrypt_model("models/neoamona_core_model.pkl.enc", "MyStrongPassword123!")
    # model = pickle.loads(data)
    print("✅ أداة تشفير النموذج جاهزة")