import matplotlib.pyplot as plt
from datetime import datetime

# =====================================================
# OPTICAL 1-BIT ALU V1
#
# VERIFIED COMPONENTS:
# AND Gate V1
# OR Gate V1
# XOR Gate V1
# Full Adder V1
#
# CONTROL BITS:
#
# S1 S0
# -----
# 00 = AND
# 01 = OR
# 10 = XOR
# 11 = ADD (SUM ONLY)
# =====================================================

print("")
print("====================================")
print("OPTICAL 1-BIT ALU V1")
print("Built on Verified Gates")
print("====================================")

# =====================================================
# VERIFIED GATES
# =====================================================

def optical_or(a, b):

    if a == 0 and b == 0:
        return 0

    return 1


def optical_and(a, b):

    if a == 1 and b == 1:
        return 1

    return 0


def optical_not(x):

    return 1 - x


def optical_xor(a, b):

    or_output = optical_or(a, b)

    and_output = optical_and(a, b)

    not_and_output = optical_not(
        and_output
    )

    return (
        or_output
        * not_and_output
    )


def optical_full_adder_sum(
    a,
    b,
    cin
):

    xor_ab = optical_xor(
        a,
        b
    )

    sum_output = optical_xor(
        xor_ab,
        cin
    )

    return sum_output

# =====================================================
# TEST INPUTS
# =====================================================

A = 1
B = 1
Cin = 0

print("")
print("INPUTS")
print("A =", A)
print("B =", B)
print("Cin =", Cin)

# =====================================================
# CONTROL STATES
# =====================================================

control_cases = {

    "00": "AND",
    "01": "OR",
    "10": "XOR",
    "11": "ADD"
}

alu_results = {}

# =====================================================
# RUN ALL OPERATIONS
# =====================================================

for control_bits, operation in control_cases.items():

    print("")
    print("------------------------------------")
    print("CONTROL =", control_bits)
    print("OPERATION =", operation)
    print("------------------------------------")

    # ================================================
    # AND
    # ================================================

    if operation == "AND":

        output = optical_and(
            A,
            B
        )

    # ================================================
    # OR
    # ================================================

    elif operation == "OR":

        output = optical_or(
            A,
            B
        )

    # ================================================
    # XOR
    # ================================================

    elif operation == "XOR":

        output = optical_xor(
            A,
            B
        )

    # ================================================
    # ADD
    # ================================================

    elif operation == "ADD":

        output = optical_full_adder_sum(
            A,
            B,
            Cin
        )

    alu_results[
        control_bits
    ] = output

    print(
        "OUTPUT =",
        output
    )

# =====================================================
# EXPECTED OUTPUTS
# For:
# A=1, B=1, Cin=0
#
# AND = 1
# OR  = 1
# XOR = 0
# ADD = 0
# =====================================================

expected_outputs = {

    "00": 1,
    "01": 1,
    "10": 0,
    "11": 0
}

verified = all(

    alu_results[k]
    == expected_outputs[k]

    for k in expected_outputs
)

status = (
    "PASS"
    if verified
    else "FAIL"
)

# =====================================================
# BAR CHART
# =====================================================

labels = [
    "AND",
    "OR",
    "XOR",
    "ADD"
]

values = [
    alu_results["00"],
    alu_results["01"],
    alu_results["10"],
    alu_results["11"]
]

plt.figure(
    figsize=(7,4)
)

plt.bar(
    labels,
    values
)

plt.ylabel(
    "Logic Output"
)

plt.title(
    "Optical 1-Bit ALU V1"
)

plt.savefig(
    "optical_1bit_alu_v1.png",
    dpi=250
)

plt.close()

# =====================================================
# TXT REPORT
# =====================================================

with open(
    "optical_1bit_alu_v1_report.txt",
    "w"
) as f:

    f.write(
        "OPTICAL 1-BIT ALU V1 REPORT\n"
    )

    f.write(
        "====================================\n"
    )

    f.write(
        f"DATE: {datetime.now()}\n\n"
    )

    f.write(
        f"A = {A}\n"
    )

    f.write(
        f"B = {B}\n"
    )

    f.write(
        f"Cin = {Cin}\n\n"
    )

    for control in control_cases:

        f.write(
            f"{control} "
            f"({control_cases[control]})"
            f" = "
            f"{alu_results[control]}\n"
        )

    f.write("\n")

    f.write(
        f"STATUS = {status}\n"
    )

# =====================================================
# FINAL REPORT
# =====================================================

print("")
print("====================================")
print("OPTICAL 1-BIT ALU V1 REPORT")
print("====================================")

for control in control_cases:

    print(
        control,
        "(" + control_cases[control] + ")",
        "=",
        alu_results[control]
    )

print("")

print(
    "STATUS =",
    status
)

print("")
print("Saved Files:")

print(
    "optical_1bit_alu_v1.png"
)

print(
    "optical_1bit_alu_v1_report.txt"
)

print("====================================")
