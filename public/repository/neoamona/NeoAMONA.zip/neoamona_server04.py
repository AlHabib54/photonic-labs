# ============================================================
# MAIN_HTML مبسط ويعمل
# ============================================================
MAIN_HTML = """
<!DOCTYPE html>
<html>
<head><title>NeoAMONA</title>
<style>
  body{font-family:sans-serif;background:#0f172a;color:#e2e8f0;padding:20px;max-width:900px;margin:auto;}
  .card{background:#1e293b;border-radius:16px;padding:20px;margin-bottom:20px;border:1px solid #334155;}
  button{background:#6366f1;border:none;color:#fff;padding:10px 24px;border-radius:8px;cursor:pointer;font-weight:600;}
  button.secondary{background:#475569;}
  input[type=file]{display:block;margin:10px 0;}
  .upload-zone{border:2px dashed #64748b;padding:40px;text-align:center;border-radius:12px;cursor:pointer;}
  .upload-zone.dragover{border-color:#818cf8;background:#1e293b;}
  .stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:20px;}
  .stat{background:#1e293b;padding:12px;border-radius:10px;text-align:center;border:1px solid #334155;}
  .stat .num{font-size:24px;font-weight:700;}
  .stat .lbl{color:#94a3b8;font-size:14px;}
  .feature-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(50px,1fr));gap:4px;margin:8px 0;}
  .feature-grid input{width:100%;padding:4px;text-align:center;background:#0f172a;border:1px solid #334155;color:#fff;border-radius:4px;}
  .log{max-height:150px;overflow-y:auto;background:#0f172a;padding:10px;border-radius:8px;}
  .log div{padding:4px 0;border-bottom:1px solid #1e293b;font-size:14px;}
  .badge{background:#6366f1;padding:4px 12px;border-radius:20px;font-size:14px;}
  .flex{display:flex;gap:10px;flex-wrap:wrap;align-items:center;}
  .mt-2{margin-top:10px;}
  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);justify-content:center;align-items:center;z-index:999;}
  .modal.active{display:flex;}
  .modal-content{background:#1e293b;padding:30px;border-radius:16px;max-width:500px;width:90%;}
</style>
</head>
<body>

<h1 style="display:flex;justify-content:space-between;align-items:center;">
  <span>🛡️ NeoAMONA</span>
  <span><span class="badge" id="tierBadge">🔓 Freemium</span> <span id="reqBadge" style="margin-left:10px;color:#94a3b8;">10 req left</span></span>
</h1>

<!-- Stats -->
<div class="stat-grid">
  <div class="stat"><div class="num" id="sTotal">0</div><div class="lbl">Total</div></div>
  <div class="stat"><div class="num" style="color:#f87171" id="sAttacks">0</div><div class="lbl">Attacks</div></div>
  <div class="stat"><div class="num" style="color:#4ade80" id="sNormal">0</div><div class="lbl">Normal</div></div>
  <div class="stat"><div class="num" style="color:#fbbf24" id="sRatio">0%</div><div class="lbl">Attack %</div></div>
</div>

<!-- Upload -->
<div class="card">
  <h3>📤 Upload CSV</h3>
  <div class="upload-zone" id="dropZone">
    <p>Drop CSV here or click to browse</p>
    <p style="font-size:14px;color:#94a3b8;">Max rows: <span id="maxRowsDisplay">1,000</span></p>
    <input type="file" id="fileInput" accept=".csv" style="display:none;">
    <input type="text" id="targetCol" placeholder="Target column (optional)" style="margin-top:8px;padding:6px 12px;border-radius:6px;border:1px solid #334155;background:#0f172a;color:#fff;width:auto;">
  </div>
  <div id="uploadProgress" style="display:none;margin-top:10px;">⏳ Analyzing...</div>
  <div id="uploadResult" class="mt-2"></div>
</div>

<!-- Predict -->
<div class="card">
  <h3>⚡ Single Prediction</h3>
  <p style="font-size:14px;color:#94a3b8;">Enter 41 features</p>
  <div class="feature-grid" id="featureGrid"></div>
  <div class="flex mt-2">
    <button id="predictBtn">Predict</button>
    <button class="secondary" id="randomBtn">🎲 Random</button>
  </div>
  <div id="predictResult" class="mt-2"></div>
</div>

<!-- Log -->
<div class="card">
  <h3>📋 Activity Log</h3>
  <div class="log" id="logContainer"><div style="color:#94a3b8;text-align:center;">No activity</div></div>
</div>

<!-- Modal -->
<div class="modal" id="upgradeModal">
  <div class="modal-content">
    <h3>⬆️ Upgrade Required</h3>
    <p>Your plan (<span id="modalTier">Freemium</span>) allows only <span id="modalLimit">1,000</span> rows.</p>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:16px 0;">
      <div style="border:1px solid #334155;padding:10px;border-radius:8px;text-align:center;cursor:pointer;" onclick="upgradeTo('basic')">
        <div style="font-weight:bold;">Basic</div><div>$299</div><div style="font-size:12px;color:#94a3b8;">10k rows</div>
      </div>
      <div style="border:1px solid #6366f1;padding:10px;border-radius:8px;text-align:center;cursor:pointer;" onclick="upgradeTo('pro')">
        <div style="font-weight:bold;">Pro</div><div>$999</div><div style="font-size:12px;color:#94a3b8;">100k rows</div>
      </div>
    </div>
    <div style="background:#1e293b;padding:8px;border-radius:6px;font-size:13px;color:#94a3b8;">Use <code>demo_payment</code> for test</div>
    <button class="secondary" style="margin-top:12px;" onclick="closeModal()">Close</button>
  </div>
</div>

<script>
// ============================================================
// State
// ============================================================
const state = {
  apiKey: 'free_key_123',
  tier: 'free',
  limits: {
    free: { maxRows: 1000, name: 'Freemium' },
    basic: { maxRows: 10000, name: 'Basic' },
    pro: { maxRows: 100000, name: 'Professional' },
    enterprise: { maxRows: Infinity, name: 'Enterprise' }
  }
};

// ============================================================
// Elements
// ============================================================
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const targetCol = document.getElementById('targetCol');
const uploadProgress = document.getElementById('uploadProgress');
const uploadResult = document.getElementById('uploadResult');
const logContainer = document.getElementById('logContainer');
const featureGrid = document.getElementById('featureGrid');
const predictBtn = document.getElementById('predictBtn');
const randomBtn = document.getElementById('randomBtn');
const predictResult = document.getElementById('predictResult');
const tierBadge = document.getElementById('tierBadge');
const reqBadge = document.getElementById('reqBadge');
const modal = document.getElementById('upgradeModal');
const modalTier = document.getElementById('modalTier');
const modalLimit = document.getElementById('modalLimit');

// ============================================================
// Init
// ============================================================
function initFeatureGrid() {
  for (let i=0; i<41; i++) {
    let inp = document.createElement('input');
    inp.type = 'number';
    inp.value = '0';
    inp.step = 'any';
    inp.id = 'f'+i;
    inp.placeholder = i;
    featureGrid.appendChild(inp);
  }
}
initFeatureGrid();
updateUI('free');
addLog('🚀 NeoAMONA ready');

// ============================================================
// UI Updates
// ============================================================
function updateUI(tier) {
  state.tier = tier;
  const info = state.limits[tier] || state.limits.free;
  tierBadge.textContent = '🔓 ' + info.name;
  document.getElementById('maxRowsDisplay').textContent = info.maxRows === Infinity ? '∞' : info.maxRows.toLocaleString();
  const maxReqs = tier==='free'?10: tier==='basic'?100: tier==='pro'?1000:'∞';
  reqBadge.textContent = maxReqs + ' req left';
}

function addLog(msg) {
  const placeholder = logContainer.querySelector('.text-muted');
  if (placeholder) placeholder.remove();
  const d = document.createElement('div');
  const t = new Date().toLocaleTimeString();
  d.innerHTML = '<span style="color:#94a3b8;">['+t+']</span> '+msg;
  logContainer.prepend(d);
}

function showToast(msg) {
  // simple alert for demo
  alert(msg);
}

function updateStats(data) {
  document.getElementById('sTotal').textContent = data.total_rows || 0;
  document.getElementById('sAttacks').textContent = data.attacks_detected || 0;
  document.getElementById('sNormal').textContent = data.normal_count || 0;
  document.getElementById('sRatio').textContent = data.prediction_summary?.attack_ratio || '0%';
}

// ============================================================
// Upload
// ============================================================
async function doUpload(file) {
  if (!file) return;
  const target = targetCol.value.trim() || undefined;
  // quick row check
  const text = await file.text();
  const lines = text.split('\n').filter(l=>l.trim());
  const rowCount = Math.max(0, lines.length-1);
  const limit = state.limits[state.tier].maxRows;
  if (rowCount > limit && limit !== Infinity) {
    modalTier.textContent = state.limits[state.tier].name;
    modalLimit.textContent = limit.toLocaleString();
    modal.classList.add('active');
    return;
  }
  const fd = new FormData();
  fd.append('file', file);
  if (target) fd.append('target_column', target);
  uploadProgress.style.display = 'block';
  uploadResult.innerHTML = '';
  try {
    const resp = await fetch('/api/upload', {
      method: 'POST',
      headers: { 'x-api-key': state.apiKey },
      body: fd
    });
    const data = await resp.json();
    if (!resp.ok) {
      showToast('❌ '+ (data.detail || 'error'));
      uploadProgress.style.display = 'none';
      return;
    }
    updateStats(data);
    addLog('✅ Uploaded '+file.name+': '+data.attacks_detected+' attacks');
    uploadResult.innerHTML = '<div style="background:#1e293b;padding:8px 12px;border-radius:8px;">'+
      data.total_rows+' rows, '+data.attacks_detected+' attacks, '+data.normal_count+' normal'+
      (data.download_url ? ' <a href="'+data.download_url+'" style="color:#818cf8;">Download</a>' : '')+
      '</div>';
    if (data.remaining_requests !== undefined) {
      reqBadge.textContent = data.remaining_requests + ' req left';
    }
  } catch(e) {
    showToast('❌ '+e.message);
  }
  uploadProgress.style.display = 'none';
}

dropZone.addEventListener('click', ()=>fileInput.click());
dropZone.addEventListener('dragover', e=>{e.preventDefault(); dropZone.classList.add('dragover');});
dropZone.addEventListener('dragleave', ()=>dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', e=>{
  e.preventDefault();
  dropZone.classList.remove('dragover');
  if(e.dataTransfer.files.length) doUpload(e.dataTransfer.files[0]);
});
fileInput.addEventListener('change', ()=>{
  if(fileInput.files.length) doUpload(fileInput.files[0]);
});

// ============================================================
// Predict
// ============================================================
predictBtn.addEventListener('click', async ()=>{
  const feats = [];
  for(let i=0;i<41;i++){
    let v = parseFloat(document.getElementById('f'+i).value);
    feats.push(isNaN(v)?0:v);
  }
  try {
    const resp = await fetch('/api/predict', {
      method: 'POST',
      headers: { 'Content-Type':'application/json', 'x-api-key': state.apiKey },
      body: JSON.stringify({features: feats})
    });
    const data = await resp.json();
    if(!resp.ok){ showToast('❌ '+data.detail); return; }
    const color = data.prediction==='Attack' ? '#ef4444' : '#4ade80';
    predictResult.innerHTML = '<div style="background:#1e293b;padding:10px;border-radius:8px;border-left:4px solid '+color+';">'+
      '<strong>'+data.prediction+'</strong> probability: '+(data.probability*100).toFixed(2)+'%'+
      '</div>';
    addLog('🔮 Prediction: '+data.prediction);
    if(data.remaining_requests !== undefined) reqBadge.textContent = data.remaining_requests + ' req left';
  } catch(e) {
    showToast('❌ '+e.message);
  }
});

randomBtn.addEventListener('click', ()=>{
  for(let i=0;i<41;i++) document.getElementById('f'+i).value = (Math.random()*10).toFixed(2);
});

// ============================================================
// Modal / Upgrade
// ============================================================
function closeModal(){ modal.classList.remove('active'); }
function upgradeTo(plan) {
  if(confirm('Upgrade to '+state.limits[plan].name+'?')){
    const token = prompt('Enter payment token (demo_payment for test):');
    if(token === 'demo_payment'){
      const suffix = Math.random().toString(36).substring(2,6);
      const newKey = plan+'_key_'+suffix;
      state.apiKey = newKey;
      updateUI(plan);
      showToast('✅ Upgraded to '+state.limits[plan].name+'! New key: '+newKey);
      closeModal();
      reqBadge.textContent = '∞ req left';
    } else {
      showToast('❌ Invalid token');
    }
  }
}
modal.addEventListener('click', e=>{ if(e.target===modal) closeModal(); });

</script>
</body>
</html>
"""