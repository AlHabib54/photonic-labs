# -*- coding: utf-8 -*-
"""
NeoAMONA Enterprise Server - النسخة النهائية المحسّنة
- معالج بيانات ذكي يتكيف مع أي ملف
- معالجة الدفعات (Chunking) للملفات الكبيرة
- رسائل خطأ واضحة للمستخدم
- نظام تسجيل (Logging) لتتبع الأداء
"""

import pickle
import numpy as np
import pandas as pd
import io
import os
import time
import logging
from typing import List, Optional
from fastapi import FastAPI, UploadFile, File, HTTPException, Header
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from sklearn.preprocessing import LabelEncoder
import uvicorn
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 1. إعداد نظام التسجيل (Logging)
# ============================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("neoamona.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("NeoAMONA")

# ============================================================
# 2. استيراد الخوارزمية الأساسية
# ============================================================
try:
    from neoamona_core import NeoAMONACore
    logger.info("✅ تم استيراد neoamona_core بنجاح")
except ImportError:
    logger.error("⚠️  neoamona_core.py غير موجود. تأكد من وجوده في نفس المجلد.")
    exit(1)

# ============================================================
# 3. نظام الاشتراكات والتراخيص
# ============================================================
TIER_LIMITS = {
    "free": {"max_rows": 1000, "name": "Freemium", "color": "#94a3b8"},
    "pro": {"max_rows": 100000, "name": "Professional", "color": "#818cf8"},
    "enterprise": {"max_rows": float('inf'), "name": "Enterprise", "color": "#fbbf24"}
}

# مفاتيح API الثابتة (للاختبار) - سيتم استبدالها بنظام ديناميكي لاحقاً
MOCK_API_KEYS = {
    "free_key_123": "free",
    "pro_key_789": "pro",
    "enterprise_key_000": "enterprise"
}

app = FastAPI(title="NeoAMONA Enterprise")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

MODEL_PATH = "models/neoamona_core_model.pkl"
model = None

# ============================================================
# 4. تحميل النموذج
# ============================================================
@app.on_event("startup")
async def load_model():
    global model
    if os.path.exists(MODEL_PATH):
        try:
            model = NeoAMONACore.load(MODEL_PATH)
            logger.info(f"✅ تم تحميل النموذج من {MODEL_PATH}")
            logger.info(f"   - العقد النشطة: {model.active_nodes}")
            logger.info(f"   - العتبة: {model.best_threshold:.3f}")
        except Exception as e:
            logger.error(f"❌ فشل تحميل النموذج: {e}")
    else:
        logger.warning(f"⚠️  النموذج غير موجود في {MODEL_PATH}")

# ============================================================
# 5. دوال معالجة البيانات الذكية (المحسّنة)
# ============================================================

def validate_key(api_key: str) -> str:
    """التحقق من صحة المفتاح وإرجاع المستوى"""
    if api_key not in MOCK_API_KEYS:
        raise HTTPException(401, detail="❌ مفتاح API غير صالح. يرجى التحقق منه.")
    return MOCK_API_KEYS[api_key]

def adapt_to_41_features(X: np.ndarray) -> np.ndarray:
    """
    تحويل أي مصفوفة إلى 41 عموداً بالضبط (حشو أو اقتصاص)
    هذه هي الوظيفة السحرية التي تمنع خطأ "expecting 41 features"
    """
    target_features = 41
    current_features = X.shape[1]
    
    if current_features < target_features:
        # حشو بالأصفار
        pad_width = target_features - current_features
        X_padded = np.pad(X, ((0, 0), (0, pad_width)), 'constant', constant_values=0)
        logger.info(f"✅ تم حشو المصفوفة من {current_features} إلى {target_features} ميزة")
        return X_padded
    elif current_features > target_features:
        # اقتصاص: خذ أول 41 ميزة (أو يمكن اختيار الأكثر تبايناً)
        logger.info(f"✅ تم اقتصاص المصفوفة من {current_features} إلى {target_features} ميزة (تم أخذ أول 41 عموداً)")
        return X_raw[:, :target_features]
    else:
        return X

def clean_data_smart(df: pd.DataFrame, target_col: Optional[str] = None):
    """
    تنظيف البيانات بشكل ذكي:
    - تحويل الأعمدة النصية إلى أرقام
    - معالجة القيم المفقودة
    - تكييف الأبعاد إلى 41 ميزة
    """
    logger.info("🔄 بدء تنظيف البيانات...")
    start_time = time.time()
    
    # 1. معالجة العمود الهدف
    y = None
    if target_col and target_col in df.columns:
        y_raw = df[target_col].values
        try:
            y = np.array([0 if str(v).strip().upper() in ['BENIGN', 'NORMAL', '0'] or v == 0 else 1 for v in y_raw])
        except:
            y = np.array([0 if str(v).strip() in ['normal', 'benign'] else 1 for v in y_raw])
        X_raw = df.drop(columns=[target_col])
        logger.info(f"✅ تم تحديد العمود الهدف: {target_col}")
    else:
        X_raw = df.copy()
        logger.info("ℹ️  لم يتم تحديد عمود هدف. سيتم استخدام جميع الأعمدة كميزات.")

    # 2. تنظيف الأعمدة
    X_clean = []
    skipped_cols = []
    for col_name in X_raw.columns:
        col = X_raw[col_name]
        
        # 2a. معالجة الأعمدة النصية
        if col.dtype == 'object' or col.dtype.name == 'category':
            try:
                le = LabelEncoder()
                col_filled = col.fillna('missing').astype(str)
                col_encoded = le.fit_transform(col_filled)
                X_clean.append(col_encoded.astype(float))
                continue
            except Exception as e:
                logger.warning(f"⚠️  تخطي العمود النصي {col_name}: {str(e)}")
                skipped_cols.append(col_name)
                continue

        # 2b. تحويل إلى أرقام
        try:
            col_numeric = pd.to_numeric(col, errors='coerce')
        except:
            logger.warning(f"⚠️  تخطي العمود {col_name} (فشل التحويل)")
            skipped_cols.append(col_name)
            continue

        # 2c. معالجة القيم المفقودة
        mean_val = np.nanmean(col_numeric)
        if np.isnan(mean_val):
            mean_val = 0.0
        col_filled = np.nan_to_num(col_numeric, nan=mean_val)
        
        # 2d. إزالة القيم اللانهائية
        col_filled = np.clip(col_filled, -1e6, 1e6)
        X_clean.append(col_filled.astype(float))

    if len(X_clean) == 0:
        raise ValueError("❌ لم يتم العثور على أعمدة صالحة في الملف. يرجى التأكد من أن الملف يحتوي على بيانات رقمية.")

    # 3. تجميع المصفوفة
    X_final = np.column_stack(X_clean)
    logger.info(f"✅ تم تنظيف {X_final.shape[1]} ميزة من أصل {len(X_raw.columns)} عمود")
    if skipped_cols:
        logger.info(f"⚠️  تم تخطي الأعمدة التالية: {skipped_cols}")

    # 4. تكييف الأبعاد إلى 41 ميزة (الوظيفة السحرية)
    X_final = adapt_to_41_features(X_final)

    # 5. معالجة أي قيم NaN متبقية
    X_final = np.nan_to_num(X_final, nan=0.0)
    
    logger.info(f"✅ اكتمل تنظيف البيانات في {time.time() - start_time:.2f} ثانية")
    return X_final, y

# ============================================================
# 6. معالجة الملفات الكبيرة (Chunking)
# ============================================================
def process_large_file_chunked(file_content: bytes, target_col: Optional[str] = None, chunk_size: int = 50000):
    """
    معالجة الملفات الكبيرة على دفعات لتجنب نفاد الذاكرة
    """
    logger.info(f"🔄 بدء معالجة الملف على دفعات (حجم الدفعة: {chunk_size} صف)")
    start_time = time.time()
    
    # قراءة الملف على دفعات
    df_iter = pd.read_csv(io.BytesIO(file_content), chunksize=chunk_size)
    
    all_proba = []
    total_rows = 0
    total_attacks = 0
    
    for i, chunk in enumerate(df_iter):
        logger.info(f"   - معالجة الدفعة {i+1} (عدد الصفوف: {len(chunk)})")
        try:
            X_chunk, _ = clean_data_smart(chunk, target_col)
            proba_chunk = model.predict_proba(X_chunk)
            y_pred_chunk = (proba_chunk >= model.best_threshold).astype(int)
            
            total_rows += len(X_chunk)
            total_attacks += int(np.sum(y_pred_chunk))
            all_proba.append(proba_chunk)
            
        except Exception as e:
            logger.error(f"❌ خطأ في الدفعة {i+1}: {str(e)}")
            raise HTTPException(400, detail=f"خطأ في معالجة الدفعة {i+1}: {str(e)}")
    
    # دمج النتائج
    final_proba = np.vstack(all_proba) if all_proba else np.array([])
    logger.info(f"✅ اكتملت معالجة الملف في {time.time() - start_time:.2f} ثانية")
    logger.info(f"   - إجمالي الصفوف: {total_rows}")
    logger.info(f"   - إجمالي الهجمات المكتشفة: {total_attacks}")
    
    return final_proba, total_rows, total_attacks

# ============================================================
# 7. HTML (واجهة المستخدم)
# ============================================================
HTML_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>NeoAMONA Enterprise</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #0f172a; color: #e2e8f0; padding: 20px; margin: 0; }
        .container { max-width: 1100px; margin: 0 auto; }
        .card { background: #1e293b; border-radius: 16px; padding: 24px; margin: 16px 0; }
        .upload-zone { border: 2px dashed #334155; border-radius: 16px; padding: 40px; text-align: center; cursor: pointer; transition: 0.3s; }
        .upload-zone.dragover { border-color: #818cf8; }
        .btn { background: #818cf8; border: none; color: #0f172a; padding: 10px 24px; border-radius: 8px; cursor: pointer; }
        .feature-grid { display: grid; grid-template-columns: repeat(10, 1fr); gap: 4px; margin: 12px 0; }
        .feature-grid input { width: 100%; padding: 4px; text-align: center; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; border-radius: 4px; }
        .log { background: #0f172a; padding: 12px; border-radius: 8px; max-height: 200px; overflow-y: auto; }
        .stat { display: inline-block; background: #0f172a; padding: 8px 20px; border-radius: 8px; margin: 4px; }
        .stat .num { font-size: 24px; font-weight: bold; }
        .toast { position: fixed; bottom: 20px; right: 20px; background: #1e293b; padding: 12px 24px; border-radius: 12px; border-left: 4px solid #818cf8; }
        .toast.error { border-left-color: #ef4444; }
        .toast.success { border-left-color: #22c55e; }
        .key-selector { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; margin-bottom: 16px; }
        select { padding: 8px; border-radius: 8px; background: #0f172a; color: #e2e8f0; border: 1px solid #334155; }
        .badge { background: #334155; padding: 4px 14px; border-radius: 50px; font-size: 13px; }
        .badge-pro { background: rgba(99,102,241,0.2); color: #818cf8; }
        .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); justify-content: center; align-items: center; z-index: 1000; }
        .modal-overlay.active { display: flex; }
        .modal { background: #1e293b; padding: 32px; border-radius: 16px; max-width: 450px; width: 90%; }
        input[type="text"] { padding: 8px; border-radius: 8px; border: 1px solid #334155; background: #0f172a; color: #e2e8f0; width: 100%; }
    </style>
</head>
<body>
<div class="container">
    <!-- Header -->
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <h1 style="color:#818cf8;">🛡️ NeoAMONA</h1>
        <div>
            <span class="badge" id="tierBadge">🔓 Freemium</span>
            <span class="badge" id="reqBadge" style="margin-left:8px;">Requests: 10</span>
        </div>
    </div>

    <!-- API Key Selector -->
    <div class="card">
        <div class="key-selector">
            <div style="flex:1;">
                <label style="color:#94a3b8;">🔑 API Key</label>
                <select id="apiKeySelect">
                    <option value="free_key_123">Free Key (Freemium)</option>
                    <option value="pro_key_789">Pro Key (Professional)</option>
                    <option value="enterprise_key_000">Enterprise Key</option>
                </select>
            </div>
            <button class="btn" onclick="openUpgradeModal()" style="background:#f59e0b;">⬆️ Upgrade</button>
        </div>
        <div style="font-size:13px; color:#94a3b8; margin-top:8px;">
            Current plan: <span id="currentPlanDisplay">Freemium</span> · Max rows: <span id="maxRowsDisplay">1,000</span>
        </div>
    </div>

    <!-- Stats -->
    <div style="margin:16px 0;">
        <div class="stat"><div class="num" id="statTotal">0</div><div style="color:#94a3b8;">Rows</div></div>
        <div class="stat"><div class="num" style="color:#ef4444;" id="statAttacks">0</div><div style="color:#94a3b8;">Attacks</div></div>
        <div class="stat"><div class="num" style="color:#22c55e;" id="statNormal">0</div><div style="color:#94a3b8;">Normal</div></div>
        <div class="stat"><div class="num" style="color:#f59e0b;" id="statRatio">0%</div><div style="color:#94a3b8;">Attack Ratio</div></div>
    </div>

    <!-- Upload -->
    <div class="card">
        <h3>📤 Upload CSV</h3>
        <div class="upload-zone" id="uploadZone">
            <p><strong>Drop CSV here</strong> or click to browse</p>
            <p style="color:#94a3b8;">Max rows: <span id="maxRowsDisplay2">1,000</span></p>
            <input type="file" id="fileInput" accept=".csv" style="display:none;">
            <div style="margin-top:10px;">
                <input type="text" id="targetCol" placeholder="Target column (optional)" style="width:200px; display:inline-block;">
            </div>
        </div>
        <div id="uploadResult" style="margin-top:10px;"></div>
    </div>

    <!-- Predict -->
    <div class="card">
        <h3>⚡ Predict</h3>
        <div class="feature-grid" id="featureGrid"></div>
        <button class="btn" id="predictBtn">Predict</button>
        <button class="btn" style="background:transparent; border:1px solid #334155;" id="randomBtn">🎲 Random</button>
        <div id="predictResult" style="margin-top:10px;"></div>
    </div>

    <!-- Log -->
    <div class="card">
        <h3>📋 Log</h3>
        <div class="log" id="logContainer"><div style="color:#94a3b8;">Ready.</div></div>
    </div>
</div>

<!-- Upgrade Modal -->
<div class="modal-overlay" id="upgradeModal">
    <div class="modal">
        <h2>⬆️ Upgrade</h2>
        <p>Enter payment token:</p>
        <input type="text" id="paymentToken" value="demo_payment">
        <div style="margin-top:12px; display:flex; gap:12px;">
            <button class="btn" onclick="confirmUpgrade()">Confirm</button>
            <button class="btn" style="background:transparent; border:1px solid #334155;" onclick="closeModal()">Cancel</button>
        </div>
    </div>
</div>

<script>
// ============================================================
// Simple reliable JS
// ============================================================
let state = { apiKey: 'free_key_123', tier: 'free', limits: { free: 1000, pro: 100000, enterprise: Infinity } };

const tierBadge = document.getElementById('tierBadge');
const reqBadge = document.getElementById('reqBadge');
const maxRowsDisplay = document.getElementById('maxRowsDisplay');
const maxRowsDisplay2 = document.getElementById('maxRowsDisplay2');
const currentPlanDisplay = document.getElementById('currentPlanDisplay');
const apiKeySelect = document.getElementById('apiKeySelect');
const uploadZone = document.getElementById('uploadZone');
const fileInput = document.getElementById('fileInput');
const targetCol = document.getElementById('targetCol');
const uploadResult = document.getElementById('uploadResult');
const featureGrid = document.getElementById('featureGrid');
const predictBtn = document.getElementById('predictBtn');
const randomBtn = document.getElementById('randomBtn');
const predictResult = document.getElementById('predictResult');
const logContainer = document.getElementById('logContainer');
const upgradeModal = document.getElementById('upgradeModal');
const paymentToken = document.getElementById('paymentToken');

// Create 41 fields
for (let i=0; i<41; i++) {
    let inp = document.createElement('input');
    inp.type = 'number'; inp.value = '0'; inp.step = 'any'; inp.id='f'+i; inp.placeholder=i;
    featureGrid.appendChild(inp);
}

function updateTier(tier) {
    state.tier = tier;
    const names = { free:'Freemium', pro:'Professional', enterprise:'Enterprise' };
    tierBadge.textContent = '🔓 ' + names[tier];
    currentPlanDisplay.textContent = names[tier];
    const limit = state.limits[tier];
    maxRowsDisplay.textContent = limit===Infinity?'∞':limit;
    maxRowsDisplay2.textContent = limit===Infinity?'∞':limit;
    const reqs = tier==='free'?10:tier==='pro'?1000:'∞';
    reqBadge.textContent = 'Requests: '+reqs;
    if (tier==='pro') { apiKeySelect.value='pro_key_789'; state.apiKey='pro_key_789'; }
    else if (tier==='enterprise') { apiKeySelect.value='enterprise_key_000'; state.apiKey='enterprise_key_000'; }
    else { apiKeySelect.value='free_key_123'; state.apiKey='free_key_123'; }
}

function toast(msg,type='info') {
    let d=document.createElement('div');
    d.className='toast '+(type==='error'?'error':type==='success'?'success':'');
    d.textContent=msg;
    document.body.appendChild(d);
    setTimeout(()=>{d.style.opacity='0'; setTimeout(()=>d.remove(),300);},4000);
}

function addLog(msg) {
    let ph=logContainer.querySelector('div[style*="color:#94a3b8;"]');
    if(ph) ph.remove();
    let d=document.createElement('div');
    let t=new Date().toLocaleTimeString();
    d.innerHTML='<span style="color:#94a3b8;">['+t+']</span> '+msg;
    logContainer.prepend(d);
}

function updateStats(data) {
    document.getElementById('statTotal').textContent=data.total_rows||0;
    document.getElementById('statAttacks').textContent=data.attacks_detected||0;
    document.getElementById('statNormal').textContent=data.normal_count||0;
    document.getElementById('statRatio').textContent=data.attack_ratio||'0%';
}

apiKeySelect.addEventListener('change', function() {
    state.apiKey=this.value;
    const tier=this.value==='free_key_123'?'free':this.value==='pro_key_789'?'pro':'enterprise';
    updateTier(tier);
    toast('🔑 Switched to '+state.tier);
    addLog('🔑 API key changed to '+tier);
});

// Upload
async function uploadFile(file) {
    if(!file) return;
    let reader=new FileReader();
    reader.onload=async function(e) {
        let lines=e.target.result.split('\\n').filter(l=>l.trim()!=='');
        let rows=lines.length-1;
        let limit=state.limits[state.tier];
        if(rows>limit && limit!==Infinity) { toast('❌ Your tier allows only '+limit+' rows. Upgrade.','error'); return; }
        let formData=new FormData();
        formData.append('file',file);
        let tc=targetCol.value.trim(); if(tc) formData.append('target_column',tc);
        try {
            let resp=await fetch('/api/upload',{method:'POST',headers:{'x-api-key':state.apiKey},body:formData});
            let data=await resp.json();
            if(!resp.ok){ toast('❌ '+(data.detail||'Upload failed'),'error'); return; }
            updateStats(data);
            addLog('✅ Uploaded '+file.name+': '+data.attacks_detected+' attacks, '+data.normal_count+' normal');
            toast('✅ Success!','success');
            uploadResult.innerHTML='<div style="background:rgba(34,197,94,0.1);padding:12px;border-radius:8px;"><strong>'+data.total_rows+'</strong> rows · <strong>'+data.attacks_detected+'</strong> attacks · <strong>'+data.normal_count+'</strong> normal</div>';
            if(data.remaining_requests!==undefined) reqBadge.textContent='Requests: '+data.remaining_requests;
        } catch(err){ toast('❌ Connection error','error'); }
    };
    reader.readAsText(file);
}

uploadZone.addEventListener('dragover', e=>{e.preventDefault(); uploadZone.classList.add('dragover');});
uploadZone.addEventListener('dragleave', ()=>uploadZone.classList.remove('dragover'));
uploadZone.addEventListener('drop', e=>{e.preventDefault(); uploadZone.classList.remove('dragover'); if(e.dataTransfer.files.length) uploadFile(e.dataTransfer.files[0]);});
uploadZone.addEventListener('click', ()=>fileInput.click());
fileInput.addEventListener('change', ()=>{ if(fileInput.files.length) uploadFile(fileInput.files[0]); });

// Predict
predictBtn.addEventListener('click', async function() {
    let feats=[]; for(let i=0;i<41;i++){ let v=parseFloat(document.getElementById('f'+i).value); feats.push(isNaN(v)?0:v); }
    try {
        let resp=await fetch('/api/predict',{method:'POST',headers:{'Content-Type':'application/json','x-api-key':state.apiKey},body:JSON.stringify({features:feats})});
        let data=await resp.json();
        if(!resp.ok){ toast('❌ '+(data.detail||'Prediction failed'),'error'); return; }
        let cls=data.prediction==='Attack'?'danger':'success';
        predictResult.innerHTML='<div class="result-box '+cls+'"><strong>'+data.prediction+'</strong> · '+(data.probability*100).toFixed(2)+'%<br><span style="color:#94a3b8;">Threshold: '+data.threshold_used+'</span></div>';
        addLog('🔮 Prediction: '+data.prediction+' ('+(data.probability*100).toFixed(2)+'%)');
        if(data.remaining_requests!==undefined) reqBadge.textContent='Requests: '+data.remaining_requests;
    } catch(err){ toast('❌ Connection error','error'); }
});
randomBtn.addEventListener('click', ()=>{ for(let i=0;i<41;i++) document.getElementById('f'+i).value=(Math.random()*10).toFixed(2); });

// Upgrade
function openUpgradeModal(){ upgradeModal.classList.add('active'); }
function closeModal(){ upgradeModal.classList.remove('active'); }
function confirmUpgrade(){
    let token=paymentToken.value.trim();
    if(token==='demo_payment'){ state.apiKey='pro_key_789'; updateTier('pro'); toast('✅ Upgraded to Professional!','success'); addLog('⬆️ Upgraded to Pro'); closeModal(); reqBadge.textContent='Requests: ∞'; apiKeySelect.value='pro_key_789'; }
    else { toast('❌ Invalid token','error'); }
}
upgradeModal.addEventListener('click', e=>{ if(e.target===upgradeModal) closeModal(); });

updateTier('free');
addLog('🚀 NeoAMONA ready');
</script>
</body>
</html>
"""

# ============================================================
# 8. نقاط النهاية API (مع تحسين رسائل الخطأ)
# ============================================================

@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """معالج الأخطاء العالمي لعرض رسائل مفهومة"""
    logger.error(f"❌ خطأ غير متوقع: {str(exc)}")
    return JSONResponse(
        status_code=400,
        content={"detail": f"❌ حدث خطأ: {str(exc)}. يرجى التحقق من صيغة الملف أو الاتصال بالدعم."}
    )

@app.get("/", response_class=HTMLResponse)
async def root():
    return HTML_PAGE

@app.get("/health")
async def health():
    return {"status": "ok", "model_loaded": model is not None}

@app.post("/api/predict")
async def predict(
    features: List[float],
    threshold: Optional[float] = None,
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(503, detail="❌ النموذج غير محمّل. يرجى تشغيل التدريب أولاً.")
    
    try:
        tier = validate_key(x_api_key)
        th = threshold if threshold is not None else model.best_threshold
        X = np.array(features).reshape(1, -1)
        # تطبيق التحويل الذكي على الميزات (لضمان 41 عموداً)
        X = adapt_to_41_features(X)
        proba = model.predict_proba(X)[0]
        pred = int(proba >= th)
        return {
            "prediction": "Attack" if pred else "Normal",
            "probability": float(proba),
            "threshold_used": float(th),
            "tier": tier,
            "remaining_requests": 999
        }
    except Exception as e:
        logger.error(f"❌ خطأ في التنبؤ: {str(e)}")
        raise HTTPException(400, detail=f"❌ فشل التنبؤ: {str(e)}")

@app.post("/api/upload")
async def upload_file(
    file: UploadFile = File(...),
    target_column: Optional[str] = None,
    x_api_key: str = Header(...)
):
    if model is None:
        raise HTTPException(503, detail="❌ النموذج غير محمّل. يرجى تشغيل التدريب أولاً.")
    
    try:
        tier = validate_key(x_api_key)
        contents = await file.read()
        
        # محاولة قراءة الملف
        try:
            df = pd.read_csv(io.BytesIO(contents))
        except Exception as e:
            raise HTTPException(400, detail=f"❌ الملف ليس بصيغة CSV صالحة: {str(e)}")
        
        if df.empty:
            raise HTTPException(400, detail="❌ الملف فارغ.")
        
        limit = TIER_LIMITS[tier]["max_rows"]
        if df.shape[0] > limit:
            raise HTTPException(403, detail=f"❌ يتجاوز الملف الحد المسموح به ({limit} صف). قم بترقية اشتراكك.")
        
        # معالجة البيانات (مع الدعم التلقائي للدفعات الكبيرة)
        # إذا كان الملف كبيراً (> 100,000 صف)، استخدم المعالجة على دفعات
        if df.shape[0] > 100000:
            logger.info("📦 الملف كبير، سيتم استخدام المعالجة على دفعات")
            # تحويل الملف إلى bytes مرة أخرى لاستخدام chunking
            file_bytes = contents
            proba, total_rows, total_attacks = process_large_file_chunked(file_bytes, target_column)
        else:
            # معالجة مباشرة
            X, y_true = clean_data_smart(df, target_column)
            proba = model.predict_proba(X)
            y_pred = (proba >= model.best_threshold).astype(int)
            total_rows = X.shape[0]
            total_attacks = int(np.sum(y_pred))
        
        normal = total_rows - total_attacks
        attack_ratio = f"{total_attacks/total_rows*100:.2f}%" if total_rows > 0 else "0%"
        
        return {
            "status": "success",
            "tier": tier,
            "total_rows": total_rows,
            "attacks_detected": total_attacks,
            "normal_count": normal,
            "attack_ratio": attack_ratio,
            "remaining_requests": 999,
            "download_url": None
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ خطأ في رفع الملف: {str(e)}")
        raise HTTPException(400, detail=f"❌ فشل معالجة الملف: {str(e)}")

# ============================================================
# 9. تشغيل الخادم
# ============================================================
if __name__ == "__main__":
    print("="*50)
    print("🚀 NeoAMONA Server v5.0 (محسّن بالكامل)")
    print("="*50)
    print("✅ معالج بيانات ذكي يتكيف مع أي ملف")
    print("✅ معالجة الدفعات للملفات الكبيرة")
    print("✅ رسائل خطأ واضحة للمستخدم")
    print("✅ نظام تسجيل متقدم")
    print("="*50)
    uvicorn.run("neoamona_server:app", host="0.0.0.0", port=8080, reload=False)